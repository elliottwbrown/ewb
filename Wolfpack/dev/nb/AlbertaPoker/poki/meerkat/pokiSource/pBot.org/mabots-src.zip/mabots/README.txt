

INTRODUCTION
------------

This package contains versions of the poker bots from Turbo Texas
Holdem ('TTH') wrapped up in the Meerkat Poker API, which lets them be
plugged into Poki's Poker Academy ('PPA').  It also contains the 'Low
Limit Holdem Strategy & Tactics advisor' (www.lowlomitholdem.com)
which is a TTH-style bot supposed to represent a good strategy to play
at a very loose table.

TTH (www.wilsonsoftware.com) is a holdem trainer which aims to provide
a wide range of opponents reflecting the idiosyncracies of typical
poker players.  One nice feature of TTH is that it allows simulations
to be performed against the bots using a user-definable profile to
specify how each decision during the play of the hand should be made.

PPA (www.poki-poker.com) is similar, but based on research from the
University of Alberta (http://www.cs.ualberta.ca/~games/poker/).  At
full ring games, the best PPA bots are generally considered stronger
players than the best of the TTH bots, but are less varied in their
style of play.  They are also considerably slower than the TTH bots.

The code in this package implements the TTH bots as plug-ins for PPA.
It is based on the documentation from the freely downloadable demo
version of TTH.  Apart from some small approximations related to
actions which depend on pot-odds, and parts of the'General Rules'
section of TTH profile not being implemented, these bots should make
the same decsions as the TTH bots almost all the time.

Details of the peculiarities of the various TTH bots' behaviour can be
found in the documentation that comes with the TTH demo.


INSTALLATION
------------

To install the binary package, just use the TTHClone-1.0.exe installer.
To install the source package, see the next section.


RECOMPILING 
-----------

You need MSVC 6.0 and a reasonably recent version of the Java SDK.
Edit makefile.vc to set the location of the Java SDK and
meerkat-api.jar then type

	nmake -f makefile.vc

This will build mabots.dll, which contains the bulk of the code, and
mabots.jar which contain some trivial code to interface with the DLL.

To make the installer, you need the installer generator (from
nsis.sourceforge.net), edit makefile.vc to set the path to makensis
and do 'nmake -f makefile.vc installer'.

To install the files by hand, look at the bottom of the installer
script tthbots.nsi to see where to put everything.


KNOWN BUGS
----------

If the bot seems to be folding without looking at its cards, it's
probably crashed.  Look at bot.error in the data directory.  If it has
crashed, please send me the details of the hand it crashed on (just
copy the hand log from the PPA window), together with bot.error and
bot.output .

Long standing internal bug with split pots in holdem.cc: odd amount
goes to the player to the left of the button, even if they folded.

Pot odd calculations in tth.cc:consider_pot_odds() are rather approximate.

Some 'bet variables' may be defined incorrectly due to gaps in the TTH
documentation (how we play if the board has a full house or quads, or
what does X2 mean if we're not heads-up?).

Some of the 'General Rules' parts of the profile aren't respected.

Other bug reports/fixes welcome.


LICENSE
-------

All the code here is released under the terms of the GNU General
Public license, see LICENSE.txt for details.


ACKNOWLEDGEMENTS
----------------

This package contains code from the pokersource library, available from
http://pokersource.sourceforge.net/.

Aaron Davidson of BioTools created the installer & modified the code
to work with PPA-1.2.0 .



Marv (marv742@netscape.net)
9 June, 2004

