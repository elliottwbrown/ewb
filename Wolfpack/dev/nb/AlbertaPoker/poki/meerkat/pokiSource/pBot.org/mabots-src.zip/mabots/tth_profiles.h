#ifndef TTH_PROFILES_H
#define TTH_PROFILES_H

struct Tth_profile;

extern Tth_profile tth_bret;
extern Tth_profile tth_conan;

extern Tth_profile tth_profile_3;
extern Tth_profile tth_profile_4;
extern Tth_profile tth_profile_5;
extern Tth_profile tth_profile_6;
extern Tth_profile tth_profile_7;
extern Tth_profile tth_profile_8;
extern Tth_profile tth_profile_9;
extern Tth_profile tth_profile_10;
extern Tth_profile tth_profile_11;
extern Tth_profile tth_profile_12;
extern Tth_profile tth_profile_13;
extern Tth_profile tth_profile_14;
extern Tth_profile tth_profile_15;
extern Tth_profile tth_profile_16;
extern Tth_profile tth_profile_17;
extern Tth_profile tth_profile_18;
extern Tth_profile tth_profile_19;
extern Tth_profile tth_profile_20;
extern Tth_profile tth_profile_21;
extern Tth_profile tth_profile_22;
extern Tth_profile tth_profile_23;
extern Tth_profile tth_profile_24;
extern Tth_profile tth_profile_25;
extern Tth_profile tth_profile_26;
extern Tth_profile tth_profile_27;
extern Tth_profile tth_profile_28;
extern Tth_profile tth_profile_29;
extern Tth_profile tth_profile_30;
extern Tth_profile tth_profile_31;
extern Tth_profile tth_profile_32;
extern Tth_profile tth_profile_33;
extern Tth_profile tth_profile_34;
extern Tth_profile tth_profile_35;
extern Tth_profile tth_profile_36;
extern Tth_profile tth_profile_37;
extern Tth_profile tth_profile_38;

extern Tth_profile tth_adv_7; // 39
extern Tth_profile tth_adv_6;
extern Tth_profile tth_adv_5;
extern Tth_profile tth_adv_4;
extern Tth_profile tth_adv_3;
extern Tth_profile tth_adv_2; // 44

extern Tth_profile llhsat;

extern Tth_profile tth_profile_80;
extern Tth_profile tth_profile_81;
extern Tth_profile tth_profile_82;
extern Tth_profile tth_profile_83;
extern Tth_profile tth_profile_84;
extern Tth_profile tth_profile_85;
extern Tth_profile tth_profile_86;
extern Tth_profile tth_profile_87;
extern Tth_profile tth_profile_88;
extern Tth_profile tth_profile_89;
extern Tth_profile tth_profile_90;
extern Tth_profile tth_profile_91;
extern Tth_profile tth_profile_92;

extern Tth_profile tth_test;

#endif
