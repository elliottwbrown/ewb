/*
 *  Define all the TTH profiles.
 *  This file is about 2M compiled.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#include "tth_misc.h"
#include "tth_profile.h"

#include "tth_bret.h"
#include "tth_conan.h"
#include "profile-3.h"
#include "profile-4.h"
#include "profile-5.h"
#include "profile-6.h"
#include "profile-7.h"
#include "profile-8.h"
#include "profile-9.h"
#include "profile-10.h"
#include "profile-11.h"
#include "profile-12.h"
#include "profile-13.h"
#include "profile-14.h"
#include "profile-15.h"
#include "profile-16.h"
#include "profile-17.h"
#include "profile-18.h"
#include "profile-19.h"
#include "profile-20.h"
#include "profile-21.h"
#include "profile-22.h"
#include "profile-23.h"
#include "profile-24.h"
#include "profile-25.h"
#include "profile-26.h"
#include "profile-27.h"
#include "profile-28.h"
#include "profile-29.h"
#include "profile-30.h"
#include "profile-31.h"
#include "profile-32.h"
#include "profile-33.h"
#include "profile-34.h"
#include "profile-35.h"
#include "profile-36.h"
#include "profile-37.h"
#include "profile-38.h"
#include "profile-39.h"
#include "profile-40.h"
#include "profile-41.h"
#include "profile-42.h"
#include "profile-43.h"
#include "profile-44.h"

#include "llhsat.h"

#include "profile-80.h"
#include "profile-81.h"
#include "profile-82.h"
#include "profile-83.h"
#include "profile-84.h"
#include "profile-85.h"
#include "profile-86.h"
#include "profile-87.h"
#include "profile-88.h"
#include "profile-89.h"
#include "profile-90.h"
#include "profile-91.h"
#include "profile-92.h"

#include "profile.h"
