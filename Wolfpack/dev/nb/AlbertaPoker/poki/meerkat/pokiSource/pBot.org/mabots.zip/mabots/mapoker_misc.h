
#ifndef MAPOKER_MISC_H
#define MAPOKER_MISC_H

#include "misc.h"

/*
 *  THROW was to for catchable things,
 *  but uncaught exceptions are impossible to debug.
 *
 *  THROW2((fmt, ... )) 
 */

#ifndef MIN
#define MIN(a,b) ((a) < (b) ? (a) : (b))
#endif

#ifndef MIN
#define MAX(x,y) ((x) > (y) ? (x) : (y))
#endif

#define THROW(x)  die(x)
#define THROW2(x) die(stringit x)
#define ASSERT(x) assert(x)


#endif
