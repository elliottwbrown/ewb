
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_adv7 extends wrapper implements Player
{
    public tth_adv7() 
    { 
	super("tth:adv7"); 
    }
}
