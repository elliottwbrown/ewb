// -*- c++ -*-
/*
 *  Class representing an unordered pair of cards, or the special
 *  value 'unknown'.  
 *  The Hole class is more useful in many respects.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#ifndef HAND_H
#define HAND_H

//  A set of two cards or 'unknown'
//  The 'hole' class is more useful.
struct MAPOKERATTR Hand 
{
  Hand(const char* c);
  Hand(Card const & c1, Card const & c2)        
  { 
    known_ = c1.known() && c2.known();
    CardMask_RESET(cm); 
    CardMask_SET(cm, c1.c); 
    CardMask_SET(cm, c2.c); 
  }
  
  Hand()                                        { CardMask_RESET(cm); known_ = 0; }

  bool known() const                            { return known_; }
  void set_unknown()                            { known_ = false; }
  
  char* to_str() const; // return static data, string will be 5 chars long
  void print() const; // write exactly 5 chars

  //  FIXME: hideously slow
  Card card(int i /* 0 or 1 */) const; 

  bool operator==(Hand const & h) const         { assert(known() && h.known()); return cm.cards_n == h.cm.cards_n; }

  CardMask cm;
  bool known_;
};

#endif
