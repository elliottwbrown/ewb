// -*- c++ -*-

#ifndef DEALER_H
#define DEALER_H

#define DLR_MAX_PLAYERS 15

#include "mapoker.h"

//  construct, set players/dealer/hands, deal, run

struct MAPOKERATTR Dealer 
{
public:
  
  //  assume 10-20 limit holdem.  If 2 players then use heads-up blind structure:
  //  UTG posts a big blind, dealer posts a small blind, dealer acts first preflop.
  Dealer(int nseats);

  ~Dealer();

  //  Dealer tracks how may chips a player has & handles all-in issues
  Dealer &       add_player(Player*, chip_t starting_chips = 0);
  void           remove_all_players();
  void           set_players(vector<Player*> const &);
  vector<chip_t> get_chips();
  chip_t         get_chips(unsigned d) { return chips[d]; }
  void           set_chips(vector<chip_t> const &);

  Dealer & set_dealer(unsigned d)           { dealer = d; return *this; }
  int      get_nseats() const               { return players.size(); }

  void     reset_hands();
  void     set_hands(vector<Hand> hands);

  void     reset_flop();
  void     set_flop(Card const flop[3]);
  void     set_turn(Card c);
  void     set_river(Card c);

  void     set_debug(int);

  //  called by players/observers, to make run() terminate immediately after other player's pre/post updates are called
  void     abort() { aborting = true; }

  void deal();
  void run();
  void dump_hand();
  void dump();

  void seed(unsigned u) { p.seed(u, "dealer.h"); }

  Holdem const & state() const { return H; }
  Holdem const & get_state() const { return H; }

  unsigned get_dealer() const { return dealer; }

private:
  prng p;
  //  prng_fast p;
  Holdem H;
  vector<Hand>    preset_hands;
  Card            preset_flop[3];
  Card            preset_turn;
  Card            preset_river;
  bool            have_preset_flop;
  bool            have_preset_turn;
  bool            have_preset_river;

  vector<Player*> players;
  vector<chip_t>  chips;
  int nseats;
  chip_t smallblind;
  chip_t bigblind;
  chip_t smallbet;
  chip_t bigbet;
  Card_mask deck;
  vector<Hole> holes;
  unsigned dealer;
  Card cards[5];
  int ncards;
  bool aborting;

  void deal_hole_cards();
  void do_setstructure();
  void do_predeal();
  bool do_round(int holdem_state);
  void deal_flop();
  void deal_cards(int n_to_deal);
  void premathandend();
  void process_payouts();
  void remove_known_cards();
};

#endif
