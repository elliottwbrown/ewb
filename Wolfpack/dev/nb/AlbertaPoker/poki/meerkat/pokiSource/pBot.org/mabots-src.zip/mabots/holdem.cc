/* -*- c++ -*-
 *
 *  Holdem game class 
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */

#include "mapoker.h"

static int debug_showdown = 0;

Holdem::Holdem()
  : ante(0), small_blind(0), small_bet(0), big_bet(0),
    players(), starting_chips(), dealer(0), blinds(), hands(),
    nplayers(0),
    state(PREDEAL)
{
}

Holdem & Holdem::set_structure(int ante_, 
			       int small_blind_, int big_blind_,
			       int small_bet_, int big_bet_, double rake_, int max_rake_, bool headsup_)
{
  ante = ante_;
  small_blind = small_blind_;
  big_blind = big_blind_;
  small_bet = small_bet_;
  big_bet = big_bet_;
  rake = rake_;
  max_rake = max_rake_;
  state = PREDEAL;
  headsup = headsup_;

  return *this;
}

Holdem & Holdem::store_action(unsigned player, Action const & act)
{
  if (!(player >= 0 && player < nplayers))
    THROW("player invalid");

  int& na = nactions[player][state];

  //  need to store this to know how has had a change to act this round
  //  ASSERT(na < MAX_ACTIONS);
  na++;
  //  actions[player][state][na++] = a;
  
  if (!(nacted[state] < MAX_PLAYERS*MAX_ACTIONS))
    THROW("too many actions");

  actions[state][nacted[state]].player = player;
  actions[state][nacted[state]].act = act;
  actions[state][nacted[state]].was_a_raise = 0;
  actions[state][nacted[state]].can_raise = (normal_state() ? get_can_raise() : false);
  nacted[state]++;

  return *this;
}

Holdem & Holdem::set_predeal(vector<string> const & players_,
			     vector<int> const & starting_chips_,
			     vector<int> const & allin_,
			     unsigned dealer_,
			     vector<int> blinds_,
			     vector<int> dead_blinds_,
			     vector<Hand> hands_,
			     int nblinds_)
{
  unsigned u;
  int i;

  if (state == HANDEND)
    state = PREDEAL;

  if (!(state == PREDEAL))
    THROW("state != PREDEAL");

  players = players_;
  starting_chips = starting_chips_;
  dealer = dealer_;
  blinds = blinds_;
  dead_blinds = dead_blinds_;
  hands = hands_;
  nblinds = nblinds_;
  
  nplayers = players.size();

  if (headsup)
    ASSERT(nplayers == 2);

  ASSERT(nplayers > 0);
  ASSERT(nplayers == starting_chips.size());
  ASSERT(dealer >= 0 && dealer < nplayers);
  ASSERT(nplayers == hands.size());

  memset(nactions, 0, sizeof(nactions));
  memset(nacted, 0, sizeof(nacted));
  history_string="";
  //  ncalls_this_round = 0;

  for (i=0; i<5; i++)
    board[i].set_unknown();

  // state done later
  pot = 0;
  // on done later
  bet_this_round = blinds;
  max_bet_this_round = 0;
  chips = starting_chips;
  player_state.resize(nplayers);
  total_contrib.resize(nplayers);
  payout.resize(nplayers);
  final_handval.resize(nplayers);
  saw_flop.resize(nplayers);

  for (u=0; u<nplayers; u++) {
    player_state[u] = waits;
    total_contrib[u] = 0;
    payout[u] = 0;
    final_handval[u] = HandVal_NOTHING;
    saw_flop[u] = 0;
  }

  for (u=0; u<nplayers; u++) {
    Action a;
    a.type = Action::blind;
    a.amount = blinds[u];
    store_action(u, a);

    //  FIXME blinds allin
    if (blinds[u] > 0)
      history_string.append("B");

    pot += blinds[u];
    
    bet_this_round[u] = blinds[u];
    total_contrib[u] += blinds[u];
    
    chips[u] -= blinds[u];
    //  some games allow -ve chips
    //    ASSERT(chips[u] >= 0);

    player_state[u] = (allin_[u] ? allin : waits);
  }

  //  whatever people actually blinded, the 'live' bet is the bigblind.
  //  FIXME fails if the bigblinder went allin for less???
  max_bet_this_round = big_blind;
  
  /*
   *  Figure out who acts firsts preflop.
   *  General rule (includes headsup): first person after the big blind acts first.
   */
  state = PREFLOP;

   int first_to_act;

   if (!headsup)
     on = (dealer+nblinds) % nplayers;  // big blind
   else
     on = 1-dealer; // big blind

   first_to_act = next_on();
   
   if (first_to_act == -1)
     //  blinds put everyone all in so there'll be no pre-flop action
     state = PREFLOPEND;
   else {
     state = PREFLOP;
     on = first_to_act;
   }
  
  //  the bigblind counts as a raise (? no limit)
  //  nraises_this_round = 1;
  return *this;
}

void Holdem::whats_next() const
{
  switch (state) {
  case PREDEAL:
    printf("Setting of pre-deal info\n");
    break;
  case PREFLOP:
    printf("Preflop: %s to act (%i to them)\n", players[on].c_str(), to_call());
    break;
  case PREFLOPEND:
    printf("Dealing flop\n");
    break;
  case FLOPEND:
    printf("Dealing turn\n");
    break;
  case FLOP:
    printf("Flop: %s to act (%i to them)\n", players[on].c_str(), to_call());
    break;
  case TURN:
    printf("Turn: %s to act (%i to them)\n", players[on].c_str(), to_call());
    break;
  case TURNEND:
    printf("Dealing river\n");
    break;
  case RIVER:
    printf("River: %s to act (%i to them)\n", players[on].c_str(), to_call());
    break;
  case SHOWDOWN:
    printf("Showdown: %s to show or muck\n", players[on].c_str());
    break;
  case HANDEND:
    printf("Hand is ended\n");
    break;
  case PREMATHANDEND:
    printf("Hand ended prematurely, %s to show or not\n", players[on].c_str());
    break;
  default:
    THROW("Internal error");
  }
}

int Holdem::next_stillin(unsigned c) const
{
  unsigned i = c;
  
  do {
    if (++i == nplayers)
      i = 0;
  } while (player_state[i] != waits && i != c);
    
  return i;
}

/*
 *  return -1 if the betting round is ended.
 */
int Holdem::next_on()
{
  unsigned next = on;

  int nwaits = 0;
  for (unsigned u=0; u < nplayers; u++)
    if (player_state[u] == waits)
      nwaits++;

  for (;;) {
    if (++next == nplayers)
      next = 0;

    if (next == on)
      // no-one else can act
      return -1;

    //  Guy doesn't get to act if he's all-in or out
    if (player_state[next] == out
	|| player_state[next] == allin)
      continue;

    //  If you've not had a chance to act this round you can do so,
    //  but not if you're the only one waiting
    if (bet_this_round[next] < max_bet_this_round
	|| (bet_this_round[next] == max_bet_this_round
	    && nactions[next][state] == 0
	    && nwaits >= 2))
      return next;
  }
}

void Holdem::whos_in_showdown(vector<int> & in)
{
  ASSERT(state == SHOWDOWN);
  in.resize(nplayers);
  
  for (unsigned u = 0; u < nplayers; u++)
    in[u] = (player_state[u] != out);
}

void Holdem::do_showdown(vector<Hand> const & hands_)
{
  ASSERT(state == SHOWDOWN || state == PREMATHANDEND);

  /*  If we're in PREMATUREHANDEND we need to know who won in case they don't show
   *  since were about to change their state to 'out' */
  int player = 0;
  unsigned u;

  for (u=0; u<nplayers; u++)
    if (player_state[u] != out)
      player = u;

  for (u=0; u<nplayers; u++)
    if (hands_[u].known()) {
      player_state[u] = showed;
      hands[u] = hands_[u];
    }

  if (state == SHOWDOWN)
    end_of_hand();
  else
    payout[player] = pot + sum_penalties();
    //    dump();
  
  state = HANDEND;
}

Holdem & Holdem::premature_handend(unsigned player, Action const & action)
{
  switch (action.type) {
  case Holdem::Action::show:
    hands[player] = action.hand;
    break;
  case Holdem::Action::noshow:
    break;
  default:
    THROW("Unexpected action, expected show or noshow\n");
  }

  //  we do similar to this in so_showdown()
  payout[player] = pot + sum_penalties();
  state = HANDEND;
  //  dump();

  return *this;
}

Holdem & Holdem::act(unsigned player, Action const & action)
{
  last_action = action;

  ASSERT(state != PREDEAL);
  ASSERT(state != PREFLOPEND);
  ASSERT(state != FLOPEND);
  ASSERT(state != TURNEND);
  ASSERT(state != HANDEND);

  ASSERT(player == on);

  store_action(player, action);
  
  if (state < SHOWDOWN)
    return betting_round_act(player, action);

  if (state == PREMATHANDEND)
    return premature_handend(player, action);

  ASSERT(state == SHOWDOWN);

  //  we do similar to this in do_showdown()
  switch (action.type) {
  case Action::show:
    hands[on] = action.hand;
    player_state[on] = showed;
    break;
  case Action::muck:
  case Action::noshow: // I guess
    player_state[on] = out;
    break;

  case Action::undef:
  case Action::blind:
  case Action::fold:
  case Action::bet:
  case Action::betsallin:
    ASSERT(!"Unexpected action in showdown");
  }
  
  unsigned next = (on+1) % nplayers;
  for ( ; next != on; next = (next+1) % nplayers)
    if (player_state[next] != out && player_state[next] != showed)
      break;

  //  FIXME if there's only one person not out an they haven't shown
  //  we move to state PREMATHANDEND and given them the change to show/noshow
    
  if (next == on) {
    //  showdown is over & someone showed their hand in the showdown
    end_of_hand();
    state = HANDEND;
    //    dump();
  } else
    on = next;

  return *this;
}

Holdem & Holdem::betting_round_act(unsigned player, Action const & action)
{
  int ai = 0; // did the guy just go (or was allowed to go all in)
  unsigned u;

  switch (action.type) {
  case Action::fold:
    player_state[player] = out;
    history_string.append("f");
    break;
    
  case Action::betsallin:
    //  allow to go all in
    ai = 1;
  case Action::bet:
    
    if (!ai) {
      /*
       *    Arrrh.
       *
       *    A player may post big+small blind,
       *    but players before that guy only have to call the big blind on the first round.
       */

      if (bet_this_round[player] + action.amount < max_bet_this_round)
      	THROW("Bet not large enough\n");
      
      if ((state == PREFLOP || state == FLOP) 
	  && (bet_this_round[player] + action.amount > max_bet_this_round)
	  && (bet_this_round[player] + action.amount - max_bet_this_round != small_bet))
	THROW("Raise not equal to a small bet\n");
      
      if ((state == TURN || state == RIVER) 
	  && (bet_this_round[player] + action.amount > max_bet_this_round)
	  && (bet_this_round[player] + action.amount - max_bet_this_round != big_bet))
	THROW("Raise not equal to a large bet\n");
    }
    
    pot += action.amount;
    chips[player] -= action.amount;

    //
    //    ASSERT(chips[player] >= 0);
    //    if (chips[player] == 0 || ai)
    if (ai) {
      player_state[player] = allin;
      history_string.append("a");
    }
    
    bet_this_round[player] += action.amount;
    total_contrib[player] += action.amount;

    if (max_bet_this_round < bet_this_round[player]) {
      //      if (max_bet_this_round > 0)
      actions[state][nacted[state]-1].was_a_raise = 1;
      //      nraises_this_round++;
      max_bet_this_round = bet_this_round[player];

      if (max_bet_this_round == 0)
	history_string.append("b");
      else
	history_string.append("r");
    } else {
      if (action.amount > 0) {
	history_string.append("c");
	//	ncalls_this_round++;
      } else
	history_string.append("k");
    }

    /*
     *  player may be on the right of a player who posted both blinds.
     */
    ASSERT(player_state[player] == allin
	   || bet_this_round[player] == max_bet_this_round);

    break;
    
  default:
    THROW("Invalid pre-flop action");
  }
  
  int next = next_on();

  if (next >= 0) {
    on = next;
    return *this;
  }

  history_string.append("/");

  /*     
   *  End of betting round. 
   */
  unsigned who_put_in_max = 0;
  int nwho_put_in_max = 0;
  int nstillin = 0;
  
  for (u=0; u<nplayers; u++)
    if (player_state[u] != out) {
      if (bet_this_round[u] == max_bet_this_round) {
	nwho_put_in_max++;
	who_put_in_max = u;
      }
      nstillin++;
    }
  
  if (state == PREFLOP)
    for (u=0; u<nplayers; u++)
      if(player_state[u] == allin || player_state[u] == waits)
	saw_flop[u] = 1;

  //  printf("nstillin=%i\n", nstillin);

  /*
   *  If only one guy put in the max that guy takes back the extra
   *  over the amount put in by the second guy.   He may be the only
   *  guy left in the pot, or there may be others.
   */
  if (nwho_put_in_max == 1) {
      int second_largest = 0;
      for (u=0; u<nplayers; u++)
	if (u != who_put_in_max
	    && total_contrib[u] > second_largest)
	  second_largest = total_contrib[u];
      
      int takesback = total_contrib[who_put_in_max] - second_largest;
      //      printf("%s takesback %i\n", players[who_put_in_max].c_str(), takesback);
      chips[who_put_in_max] += takesback;
      total_contrib[who_put_in_max] -= takesback;
      bet_this_round[who_put_in_max] -= takesback;
      max_bet_this_round -= takesback;
      pot -= takesback;
  }
  
  if (nstillin == 1) {
    //  we move to state PREMATHANDEND and given them the change show/noshow
    //    printf("premathandend\n");
    state = PREMATHANDEND;
    on = who_put_in_max;
    return *this;
  } 
  
  //  Assuming there are 2+ people left ...
  ASSERT(nstillin >= 2);
  state++;
  ASSERT(state != HANDEND);

  if (state == SHOWDOWN) {
    /*
     *  I'm not sure about the rule for who shows first in a showdown.
     *
     *  1 CHK 2 bet 1 call is on 2
     *  1 bet 2 raise 1 call is on 2
     *
     *  Find the person who put in the last raise.
     *
     *  If the last round was checked, we look at the prev. round.
     *  CHECKME: If there were no raises at any point, I'll just take
     *  the first person who acted on the river and made it to the
     *  showdown.
     */
    for (int c=3; c>=0; c--) {
      int stte = PREFLOP + 2*c;
      for (int c = nacted[stte]-1; c >= 0; c--) {
	int p = actions[stte][c].player;
	if (player_state[p] != out 
	    && actions[stte][c].was_a_raise) {
	  on = p;
	  //	  printf("%i to showdown first\n", p);
	  goto ok;
	}
      }
    }
    
    //  Workout who acted first on the river and was in the showdown.
    for (u = 0; u < nacted[RIVER]; u++) {
      int p = actions[RIVER][u].player;
      if (player_state[p] != out) {
	on = p;
	break;
      }
    }
  ok:;
  } else {
    //  start of FLOP/TURN/RIVER, first to act is guy after dealer
    on = dealer;
    on = next_on();
    ASSERT(on >= 0);
  }
  
  return *this;
}

int Holdem::to_call() const
{
  ASSERT(state == PREFLOP
	 || state == FLOP
	 || state == TURN
	 || state == RIVER);
  
  return max_bet_this_round - bet_this_round[on];
}

void Holdem::dump() const
{
  unsigned u;

  if (nplayers == 0)
    return;

  int k;
  vector<int> offset(nplayers);

  printf("\n");
  printf("Gameid %i, Structure: %i/%i Limit, %i ante, %i/%i blinds\n", gameid, small_bet, big_bet, ante, small_blind, big_blind);
  printf("%i blinds\n", nblinds);

  int last_normal_state = (state <= SHOWDOWN ? state : SHOWDOWN);

  for (int st=0; st <= last_normal_state; st++) {
    
    switch (st) {
    case PREDEAL: 
      {
	//	printf("predeal\n");
	int c = 0;
	for (unsigned i=0; i < nplayers; i++) {
	  char buf[100];
	  sprintf(buf, "%.11s", players[i].c_str());
	  offset[i] = c;
	  //	  printf("%s   %n", players[i].c_str(), &k);
	  printf("%s   %n",buf, &k);
	  c += k;
	}
	printf("\n");
	c = 0;
	for (u=0; u<nplayers; u++){
	  printf("%*s%i%n", offset[u] - c, "", starting_chips[u], &k);
	  c += k;
	}
	printf("\n");
	printf("%*sD\n", offset[dealer], "");
	printf("\n");

	c = 0;
	for (u=0; u<nplayers; u++){
	  printf("%*s%s%n", offset[u] - c, "", hands[u].to_str(), &k);
	  c += k;
	}
	printf("\nDead/Live posts:\n");

	c = 0;
	for (u=0; u<nplayers; u++){
	  printf("%*s%i%n", offset[u] - c, "", dead_blinds[u], &k);
	  c += k;
	}

	printf("\n");
	break;
      }
      
    case PREFLOP: 
      printf("\nPreflop:\n"); 
      break;
    case PREFLOPEND: 
      //      printf("preflopend\n"); 
      break;
    case FLOP:
      printf("Flop: ");
      board[0].print();
      printf(" ");
      board[1].print();
      printf(" ");
      board[2].print();
      printf("\n");
      break;
    case FLOPEND: 
      //      printf("flopend\n"); 
      break;
    case TURN:
      printf("Turn: ");
      board[0].print();
      printf(" ");
      board[1].print();
      printf(" ");
      board[2].print();
      printf(" ");
      board[3].print();
      printf("\n");
      break;
    case TURNEND: 
      //      printf("turnend\n"); 
      break;
    case RIVER:
      printf("River: ");
      board[0].print();
      printf(" ");
      board[1].print();
      printf(" ");
      board[2].print();
      printf(" ");
      board[3].print();
      printf(" ");
      board[4].print();
      printf("\n");
      break;
    case SHOWDOWN: 
      {
	int ofs = 0;
	printf("\nShowdown:\n");
	for (u=0; u<nplayers; u++) {
	  printf("%*s%s%n", offset[u] - ofs, "", hands[u].to_str(), &k);
	  ofs += k;
	}
      }
      printf("\n");
      break;
    case PREMATHANDEND: 
    case HANDEND: 
      ASSERT(!"Internal error. (1)");
      break;
    }
    
    if (st != SHOWDOWN) {
      int last_act = -1;
      int ofs = 0;
      for (unsigned a = 0; a < nacted[st]; a++) {
	Holdem::Action act = actions[st][a].act;
	int p = actions[st][a].player;
	
	if (p < last_act){ 
	  printf("\n");
	  ofs = 0;
	}
	last_act = p;
	
	printf("%*s%n", offset[p] - ofs, "", &k);
	ofs += k;
	
	int ai = 0;
	switch (act.type) {
	case Holdem::Action::undef:
	  printf("?%n", &k);
	  ofs += k;
	  break;
	case Holdem::Action::blind:
	  printf("%i %n", act.amount, &k);
	  ofs += k;
	  break;
	case Holdem::Action::fold:
	  printf("FLD%n", &k);
	  ofs += k;
	  break;
	case Holdem::Action::betsallin:
	  ai = 1;
	case Holdem::Action::bet:
	  if (act.amount == 0)
	    if (!ai)
	      printf("CHK%n", &k);
	    else
	      printf("CHK-allin%n", &k);
	  else {
	    if (!ai)
	      printf("%i %n", act.amount, &k);
	    else 
	      printf("%i-allin %n", act.amount, &k);
	  }
	  ofs += k;
	  break;
	case Holdem::Action::show:
	  hands[p].print();
	  ofs += 5;
	  break;
	case Holdem::Action::muck:
	  printf("MCK");
	  ofs += 3;
	  break;
	case Holdem::Action::noshow:
	  printf("NSH");
	  ofs += 3;
	  break;
	default:
	  printf("#!?%n", &k);
	  ofs += k;
	  break;
	}
      }
      printf("\n");
    }
  }
  
  if (state == PREMATHANDEND) {
    printf("premature hand end\n");
  } else if (state == HANDEND) {
    printf("\n");
    for (u=0; u<nplayers; u++)
      if (payout[u] > 0) {
	printf("%s wins %i", players[u].c_str(), payout[u]);
	if (final_handval[u] != HandVal_NOTHING) {
	  printf(" with ");
	  HandVal_print(final_handval[u]);
	}
	printf("\n");
      }
    
    {
      printf("Net changes:\n");
      vector<int> ch;
      get_net_change(ch);
      int ofs = 0;
      for (u=0; u<nplayers; u++) {
	printf("%*s%i%n", offset[u] - ofs, "", ch[u], &k);
	ofs += k;
      }
      printf("\n");
    }
  } else {
    printf("Pot %i\n", get_pot());
  }
}

Holdem & Holdem::set_flop(Card const flop[3])
{
  ASSERT(state == PREFLOPEND);

  for (int i=0; i<3; i++) {
    board[i] = flop[i];
    ASSERT(board[i].known());
  }

  state = FLOP;
  init_round();
  return *this;
}
 
Holdem & Holdem::set_card(Card const c, int is_river)
{
  ASSERT(state == FLOPEND + 2*is_river);

  ASSERT(c.known());
  board[3+is_river] = c;
  state = TURN + 2*is_river;
  init_round();
  return *this;
}
 
//  Findout who is first to bet at the start of a round.
//  state is FLOP/TURN/RIVER
Holdem & Holdem::init_round()
{ 
  ASSERT(state == FLOP || state == TURN || state == RIVER);
  //  ncalls_this_round = 0;
  unsigned nout_or_allin = 0;

  for (unsigned u=0; u<nplayers; u++)
    if (player_state[u] == out
	|| player_state[u] == allin)
      nout_or_allin++;
  
  if (nout_or_allin >= nplayers-1)
    state++;
  else {
    for (unsigned u=0; u<nplayers; u++)
      bet_this_round[u] = 0;
    max_bet_this_round = 0;

    on = dealer;  
    unsigned first_to_act = next_on();
    //  there must be at least 2 players with stuff to do
    //  so the dealer can't be the first to act
    ASSERT(first_to_act != dealer);
    on = first_to_act;
  }

  //  nraises_this_round = 0;

  return *this;
}

void Holdem::end_of_hand()
{
  payout.resize(nplayers);
  CardMask board_cm;
  unsigned u;

  HandVal hvs[MAX_PLAYERS];
  unsigned contrib[MAX_PLAYERS];

  ASSERT(state == SHOWDOWN);

  CardMask_RESET(board_cm);
  for (u=0; u<5; u++) {
    ASSERT(board[u].known());
    CardMask_SET(board_cm, board[u].c);
  }
  
  for (u=0; u<nplayers; u++) {
    HandVal hv;
    
    if (player_state[u] == showed) {
      CardMask cm;
      CardMask_OR (cm, board_cm, hands[u].cm);
      hv = Hand_EVAL_N(cm, 7);
    } else 
      /*
       *  players who didn't show have an infintely bad hand.
       *  We must include them in case their contribution is split
       *  between different players.  This leads to almost nplayers
       *  separate pots per hand, but I reckon we're pretty fast anyway.
       */
      hv = HandVal_NOTHING;
    
    final_handval[u] = hv;
    hvs[u] = hv;
    contrib[u] = total_contrib[u];
  }

  /*
    unsigned rake_off = (int) MIN(rake*pot, max_rake);
    unsigned thepot = pot - rake_off;
  */

  /*
   *  Pot dividing, handling split pots (maybe fast path for non-split pots)
   *
   *  Copy total_contrib[] into contribs[].
   *  Mark all showed players as 'in'.
   *  Take smallest contrib
   *  {
   *   This pot has size number_in * contrib.
   *   Find the best 'in' player.
   *   Don't worry about chip splitting.
   *   decrease all contribs by this amount marking people whos contrib is now zero as 'out'
   *     update number_in
   *   Find smallest >0 contrib.
   *  }
   */

  int by_hv[MAX_PLAYERS]; // best first 
  int by_contrib[MAX_PLAYERS]; // lowest first
  int in[MAX_PLAYERS];

  for (u=0; u<nplayers; u++) {
    by_hv[u] = by_contrib[u] = u;
    in[u] = 1;
  }
  
  sort(by_hv, by_hv+nplayers, compare<HandVal>(hvs, false));
  sort(by_contrib, by_contrib+nplayers, compare<unsigned>(contrib));
  
  /*
    for (u=0; u<nplayers; u++) {
    int p = by_hv[u];
    printf("%s ends with ", players[p].c_str());
    HandVal_print(hvs[p]);
    printf(" & contributed %i\n", contrib[p]);
    }
  */

  //  by_hv[best_remaining] is the guy with the best hand still in
  unsigned best_remaining = 0;
  
  //  number of players no longer with any claim on the pot
  unsigned done = 0;

  int penalty = sum_penalties();

  //  Remaining chips that have to go somewhere (debugging)
  double thepot = pot + penalty;

  double pay[MAX_PLAYERS];
  int last_winner = -1;

  for (u=0; u < nplayers; u++)
    pay[u] = 0.0;

  while (done < nplayers) {
    
    if (debug_showdown) {
      printf("done=%u best_remaining=%u\n", done, best_remaining);
      for (u=0; u<nplayers; u++)
	printf("%s ", players[by_hv[u]].c_str());
      printf("\n");
      for (u=0; u<nplayers; u++)
	printf("%s ", players[by_contrib[u]].c_str());
      printf("\n");
      for (u=0; u<nplayers; u++)
	printf("%u ", contrib[by_contrib[u]]);
      printf("\n");
    }

    ASSERT(done < nplayers);
    unsigned pen = (done == 0 ? penalty : 0);
    unsigned contr = contrib[by_contrib[done]];
    unsigned subpot = contr * (nplayers - done) + pen;

    if (debug_showdown)
      printf("Subpot of size %i form %i contributors of size %i (+penalty of %i)\n", 
	     subpot, (nplayers - done), contr, pen);
    
    ASSERT(best_remaining < nplayers);
    ASSERT(in[by_hv[best_remaining]]);
    last_winner = best_remaining;

    //  who had the best hand, bearing in mind the possibility of a tie?
    unsigned u; 
    unsigned nwinners = 0;
    for (u = best_remaining; u < nplayers && hvs[by_hv[u]] == hvs[by_hv[best_remaining]]; u++)
      if (in[by_hv[u]]) 
	nwinners++;
    
    thepot -= subpot;

    ASSERT(nwinners > 0);

    double share = subpot/(double)nwinners;
    for (u = best_remaining; u < nplayers && hvs[by_hv[u]] == hvs[by_hv[best_remaining]]; u++)
      if (in[by_hv[u]]) {
	if (debug_showdown)
	  printf("%s wins %f\n", players[by_hv[u]].c_str(), share);
	pay[by_hv[u]] += share;
      }
    
    for (unsigned d=done; d<nplayers; d++)
      contrib[by_contrib[d]] -= contr;

    while (done < nplayers && !contrib[by_contrib[done]]) {
      in[by_contrib[done]] = 0;
      done++;
    }

    while (best_remaining < nplayers && !in[by_hv[best_remaining]])
      best_remaining++;
  }
  ASSERT(best_remaining == nplayers);
  ASSERT(done == nplayers);
  ASSERT(thepot == 0);

  unsigned p = pot + penalty;
  for (u=0; u<nplayers; u++) {
    payout[u] = (unsigned)pay[u];
    p -= payout[u];
  }

  if (p) {
    //  FIXME should give excess to person left in highest position
    ASSERT(last_winner >= 0 && last_winner < (int)nplayers);
    payout[last_winner] += p;
  }

  if (debug_showdown) 
    for (u=0; u<nplayers; u++)
      printf("%s wins %i\n", players[u].c_str(), payout[u]);
}

void Holdem::get_stillin(vector<int> & res) const
{
  res.resize(nplayers);
  for (unsigned c=0; c<nplayers; c++)
    res[c] = !(player_state[c] == out);
}

int Holdem::get_nstillin() const
{
  int res = 0;
  for (unsigned c=0; c<nplayers; c++)
    res += !(player_state[c] == out);
  return res;
}

int Holdem::get_nactive() const
{
  int res = 0;
  for (unsigned c=0; c<nplayers; c++)
    res += (player_state[c] == waits);
  return res;
}

void Holdem::get_board(Card card[5]) const
{
  for (int c=0; c<5; c++)
    card[c] = board[c];
}

int Holdem::get_nseen() const
{
  for (int u=0; u<5; u++)
    if (!board[u].known())
      return u;
  
  return 5;
}

vector<int> & Holdem::get_net_change(vector<int> & a) const
{
  a.resize(nplayers);
  int s=0;

  for (unsigned c=0; c<nplayers; c++) {
    a[c] = payout[c] - total_contrib[c] - dead_blinds[c];
    s += a[c];
  }
  
  ASSERT(!s);
  return a;
}

int Holdem::sum_penalties() const
{
  int s=0;
  for (unsigned u=0; u<nplayers; u++)
    s += dead_blinds[u];
  return s;
}


int Holdem::get_ntoact() const 
{
  int n=0;
  
  for (unsigned c=0; c<nplayers; c++)
    if (bet_this_round[c] < max_bet_this_round
	|| nactions[c][state] == 0)
      n++;

  return n;
}

int Holdem::get_nunacted() const 
{
  int n=0;
  
  for (unsigned c=0; c<nplayers; c++)
    if (nactions[c][state] == 0
	&& player_state[c] == waits)
      n++;

  return n;
}

int Holdem::raised_this_round(int p) const
{
  ASSERT(p>=0 && p<(int)nplayers);
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].player == p
	&& actions[state][a].was_a_raise)
      return 1;

  return 0;
}

int Holdem::called_this_round(int p) const
{
  ASSERT(p>=0 && p<(int)nplayers);
  for (unsigned a=0; a<nacted[state]; a++) {
    if (actions[state][a].player == p
	&& (actions[state][a].act.type == Action::bet
	    || actions[state][a].act.type == Action::betsallin)
	&& !actions[state][a].was_a_raise)
      return 1;
  }

  return 0;
}

int Holdem::get_last_to_act() const
{
  ASSERT(state <= RIVER && state != PREDEAL);

  unsigned i = dealer;
  for (;;) {
    if (player_state[i] == waits)
      return i;
    i = (i-1 + nplayers) % nplayers;
    if (i == dealer)
      break;
  } 

  //  someone must be in the hand
  ASSERT(!"Internal error (2)");
  return 0;
}

int Holdem::get_raised_preflop(int p) const
{
  for (unsigned a=0; a<nacted[PREFLOP]; a++)
    if (actions[PREFLOP][a].player == p
	&& actions[PREFLOP][a].was_a_raise)
      return 1;
  
  return 0;
}

void Holdem::get_preflop_info(struct preflop_info* p) const
{
  int s = 0;
  unsigned i = whose_on();
  unsigned j = next_stillin(i);
  
  ASSERT(state == PREFLOP);

  p->nraisers = 0;
  p->ncallers = 0;
  p->early_position_raiser=0;
  p->early_position_caller=0;
  p->mid_position_raiser=0;
  p->mid_position_caller=0;
  p->late_position_raiser=0;
  p->late_position_caller=0;
  p->blind_position_raiser=0;
  p->blind_position_caller=0;
  p->potential_reraise = 0;
  p->last_raiser = -1;

  while (i != j) {
    if ((get_bet_this_round(j) < get_max_bet_this_round()
	 || !nactions[j][state])
	&& s == 0)
      s = 1;
    
    if (j == get_small_blind_seat() || j == get_big_blind_seat()) {
      if (raised_this_round(j))
	p->blind_position_raiser = 1;
      else if (called_this_round(j))
	p->blind_position_caller = 1;
    } else {
      
      if (get_position(j) >= 5) {
	if (raised_this_round(j))
	  p->early_position_raiser = 1;
	else if (called_this_round(j))
	  p->early_position_caller = 1;
      }
      
      if (get_position(j) >= 2) {
	if (raised_this_round(j))
	  p->mid_position_raiser = 1;
	else if (called_this_round(j))
	  p->mid_position_caller = 1;
      }
      
      if (get_position(j) < 2) {
	if (raised_this_round(j))
	  p->late_position_raiser = 1;
	else if (called_this_round(j))
	  p->late_position_caller = 1;
      }
    }
    
    if (raised_this_round(j)) {
      p->nraisers++;
    }
    
    if (get_bet_this_round(j) == get_max_bet_this_round())
      if (p->last_raiser == -1)
	p->last_raiser = j;
      else
	p->last_raiser = -2;
    
    if (called_this_round(j))
      p->ncallers++;
    
    j = next_stillin(j);
  }
  p->potential_reraise = (s == 1 && p->nraisers>0);
}

// 0 first 1 last 2 other
int Holdem::get_simple_positioncode(unsigned on) const
{
  if (on == (unsigned)next_stillin(dealer))
    return 0;

  if (on == (unsigned)get_last_to_act())
    return 1;

  return 2;
}

int Holdem::get_ncalls_this_round_by(unsigned p) const
{
  int count = 0;
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].player == (int)p
	&& actions[state][a].act.type == Action::bet
	&& actions[state][a].act.amount > 0
	&& !actions[state][a].was_a_raise)
      count++;
  return count;
}

int Holdem::get_nchecks_this_round_by(unsigned p) const
{
  int count = 0;
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].player == (int)p 
	&& actions[state][a].act.type == Action::bet
	&& actions[state][a].act.amount == 0
	&& !actions[state][a].was_a_raise)
      count++;
  return count;
}

int Holdem::get_nraises_this_round_by(unsigned p) const
{
  int count = 0;
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].player == (int)p
	&& actions[state][a].was_a_raise)
      count++;
  return count;
}

const char* Holdem::preflop_info::to_str() const
{
  static char buf[100];

  sprintf(buf, 
	  "nraisers=%i ncallers=%i "
	  "early_position_raiser=%i mid_position_raiser=%i late_position_raiser=%i blind_position_raiser=%i "
	  "early_position_caller=%i mid_position_caller=%i late_position_raiser=%i blind_position_caller=%i "
	  "potential_reraise=%i ",
	  nraisers, ncallers, 
	  early_position_raiser, mid_position_raiser, late_position_raiser, blind_position_raiser,
	  early_position_caller, mid_position_caller, late_position_raiser, blind_position_caller,
	  potential_reraise);

  return buf;
}

string Holdem::get_game_string() const
{
  char buf[1000];
  
  buf[0] = 0;
  int k = 0;
  int l = 0;
  int c;

  int np = get_nplayers();
  
  sprintf(buf+k, "%i %n", dealer, &l);
  k += l;

  for (c=0; c<np; c++) {
    sprintf(buf+k, "%s %n", get_hand(c).to_str(), &l);
    k += l;
  }
  
  sprintf(buf+k, "%s %n", get_history_string().c_str(), &l);
  k += l;
  
  int ncards = get_nseen();
  for (c=0; c<ncards; c++) {
    sprintf(buf+k, "%s %n", get_board_card(c).to_str(), &l);
    k += l;
  }
  
  sprintf(buf+k, "| %n", &l);
  k += l;
  
  for (c=0; c<np; c++) {
    sprintf(buf+k, "%i %n", get_net_change(c), &l);
    k += l;
  }

  return string(buf);
}

int Holdem::get_potential_reraise() const
{
  unsigned i = whose_on();
  unsigned j = next_stillin(i);

  while (i != j) {
    if (get_bet_this_round(j) < get_max_bet_this_round()
	|| nactions[j][state] == 0)
      return 1;
    
    j = next_stillin(j);
  }
  
  return 0;
}

int Holdem::get_last_raiser() const
{
  for (int s = state; s >= 0; s--)
    for (int a = nacted[s]; a >= 0; a--)
      if (actions[s][a].was_a_raise)
	return actions[s][a].player;
  
  return -1;
}

int Holdem::get_nchecks_by(unsigned p) const
{
  int count = 0;
  for (int s = 0; s <= state; s++)
    for (unsigned a=0; a<nacted[s]; a++)
      if (actions[s][a].player == (int)p 
	  && actions[s][a].act.type == Action::bet
	  && actions[s][a].act.amount == 0
	  && !actions[s][a].was_a_raise)
	count++;
  return count;
}

int Holdem::get_ncalls_by(unsigned p) const
{
  int count = 0;
  for (int s = 0; s <= state; s++)
    for (unsigned a=0; a<nacted[s]; a++)
      if (actions[s][a].player == (int)p 
	  && actions[s][a].act.type == Action::bet
	  && actions[s][a].act.amount > 0
	  && !actions[s][a].was_a_raise)
	count++;
  return count;
}

int Holdem::get_nraises_by(unsigned p) const
{
  int count = 0;
  for (int s = 0; s <= state; s++)
    for (unsigned a=0; a<nacted[s]; a++)
      if (actions[s][a].player == (int)p
	  && actions[s][a].was_a_raise)
	count++;
  return count;
}


int Holdem::get_nbets_this_round() const
{
  int nbets = 0;
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].was_a_raise)
      nbets++;
  return nbets;
}

int Holdem::get_ncalls_this_round() const
{
  int n = 0;
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].act.type == Action::bet
	&& actions[state][a].act.amount > 0
	&& !actions[state][a].was_a_raise)
      n++;
  return n;
}

int Holdem::get_nchecks_this_round() const
{
  int n = 0;
  for (unsigned a=0; a<nacted[state]; a++)
    if (actions[state][a].act.type == Action::bet
	&& actions[state][a].act.amount == 0
	&& !actions[state][a].was_a_raise)
      n++;
  return n;
}

int Holdem::get_preflop_positioncode(unsigned p) const
{
  if (p == get_big_blind_seat())
    return -2;

  if (p == get_small_blind_seat())
    return -1;

  if (get_position() < 2)
    return get_position();

  if (get_position() < 5)
    return 2;

  return 3;
}

string Holdem::get_board_str() const
{
  string s;
  char buf2[10];

  for (int i=0; i<get_nseen(); i++) {
    sprintf(buf2, "%s ", board[i].to_str());
    s.append(buf2);
  }

  return s;
}


void Holdem::check()  
{ 
  ASSERT(to_call() == 0); 
  Action a(Action::bet); 
  a.amount = 0;
  act(a); 
}

int Holdem::raise_this_round() const
{    
  switch (state) {
  case PREFLOP: case FLOP:
    return small_bet;
  case TURN: case RIVER:
    return big_bet;
  default:
    ASSERT(!"Internal error, illegal state in raise_this_round");
  }
  
  return -1;
}

vector<int> & Holdem::get_payouts(vector<int> & a) const   
{ 
  ASSERT(state == HANDEND); 
  a = payout; 
  return a; 
}

int Holdem::get_net_change(unsigned p) const
{ 
  ASSERT(p<nplayers); 
  vector<int> nc; 
  return get_net_change(nc)[p]; 
}

string const & Holdem::get_player(unsigned p) const 
{ 
  ASSERT(p<nplayers); 
  return players[p]; 
}

Card Holdem::get_board_card(int i) const
{ 
  ASSERT(i<get_nseen()); 
  return board[i]; 
}

int Holdem::get_round() const
{
  int r[HOLDEM_NSTATES] = {-1, 0, -1, 1, -1, 2, -1, 3, -1, -1, -1};
  ASSERT(r[state] >= 0);
  return r[state];
}

void Holdem::check_round() const 
{ 
  ASSERT(state == PREFLOP || state == FLOP || state == TURN || state == RIVER); 
}

int Holdem::get_saw_flop(unsigned p) const 
{ 
  ASSERT(p>=0 && p<nplayers); 
  return saw_flop[p]; 
}

string Holdem::get_player_summary() const
{
  string res;
  char buf[1000];

  for (unsigned c=0; c<get_nplayers(); c++) {
    sprintf(buf, "%i %i %s\n", starting_chips[c], blinds[c], players[c].c_str());
    res.append(buf);
  }

  return res;
}

unsigned Holdem::get_effective_nplayers() const
{
  unsigned enp = get_nplayers();
  
  for (unsigned a = 0; a < nacted[PREFLOP]; a++)
    if (actions[PREFLOP][a].act.type == Action::fold)
      enp--;
    else
      break;

  return enp;
}

void Holdem::set_hand(unsigned p, Hand h)
{
  assert(p<nplayers);
  hands[p] = h;
}

int Holdem::get_first_to_act() const
{
  ASSERT(state <= RIVER && state != PREDEAL);

  unsigned i = dealer;
  for (;;) {
    i = (i+1) % nplayers;
    if (i == dealer)
      break;
    if (player_state[i] == waits)
      return i;
  } 

  //  someone must be in the hand
  ASSERT(!"Internal error (2)");
  return 0;
}

int Holdem::get_nraises_on_round(int r) const
{
  assert(r>=0 && r<4);
  int states[4] = { PREFLOP, FLOP, TURN, RIVER };
  int s = states[r];
  int count=0;
  for (unsigned a=0; a<nacted[s]; a++)
    if (actions[s][a].was_a_raise)
      count++;
  return count;
}

int Holdem::get_leader() const
{
  if (state < PREFLOP)
    return -1;
  
  int s;
  for (s = state; s > PREFLOPEND; s--)
    for (int a = nacted[s]-1; a >= 0; a--)
      if (actions[s][a].was_a_raise)
	return actions[s][a].player;
  
  int leader = -1;
  
  assert(s == PREFLOP || s == PREFLOPEND);

  for (int a = nacted[PREFLOP]-1; a >= 0; a--)
    if (actions[PREFLOP][a].act.type == Action::bet) {
      if (actions[PREFLOP][a].was_a_raise)
	return actions[PREFLOP][a].player;
      if (actions[PREFLOP][a].act.amount > 0)
	leader = actions[PREFLOP][a].player;
    }
  return leader;  
}

bool Holdem::get_leader_surrendered() const
{
  int l = get_leader();
  
  if (l == -1)
    return false;

  for (int s = state; s >= PREFLOP; s--)
    for (int a = nacted[s]-1; a >= 0; a--)
      if (actions[s][a].player == l)
	return actions[s][a].can_raise && !actions[s][a].was_a_raise;
  
  die("Internal error: leader didn't act");
  return true;
}
    
