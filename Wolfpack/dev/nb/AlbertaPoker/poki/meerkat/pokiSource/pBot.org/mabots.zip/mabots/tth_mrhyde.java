
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_mrhyde extends wrapper implements Player
{
    public tth_mrhyde() 
    { 
	super("tth:mrhyde"); 
    }
}
