
#include "drand48.h"

#define PRNG_Ahi32 0x5DEEC
#define PRNG_Alo16 0xE66D
#define PRNG_C   0xB

static struct prng_state {
  unsigned short lo16;
  unsigned int hi32;
} prng_state = {0, 0};

void srand48(long int seedval)
{
  prng_state.lo16 = 0x330E;
  prng_state.hi32 = seedval;
}

double drand48(void)
{
  unsigned int i;
  unsigned int j;

  /* this can't overflow */
  i = prng_state.lo16 * PRNG_Alo16 + PRNG_C;
  
  /* we don't care if j overflows */
  j = (i>>16)
    + PRNG_Alo16*prng_state.hi32
    + PRNG_Ahi32*prng_state.lo16
    + (PRNG_Ahi32*prng_state.hi32 << 16);
  

  prng_state.lo16 = i & 0xFFFF;
  prng_state.hi32 = j;

  return (j + prng_state.lo16/65536.0)/4294967296.0;
}
