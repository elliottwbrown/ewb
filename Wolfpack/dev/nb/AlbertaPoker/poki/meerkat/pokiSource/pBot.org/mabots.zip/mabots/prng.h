//  -*- c++ -*-
#ifndef PRNG_H
#define PRNG_H

extern struct prng* prng_current;

void prng_init(unsigned seed = 0);

//  Fails birthday spacings test in diehard.
//  low 8 & low 16 streams pass.
static inline unsigned prng_sample_sub(long* l, int* inext, int* inextp, unsigned* ma)
{
  unsigned mj,mk;
  int i,ii,k;
  
  if (*l < 0) {
    mj=161803398 + *l; // don't want to be too much smaller than this
    ma[55]=mj;
    mk=1;
    for (i=1;i<=54;i++) {
      ii=(21*i) % 55;
      ma[ii]=mk;
      mk=mj-mk;
      mj=ma[ii];
    }
    for (k=1;k<=25;k++)
      for (i=1;i<=55;i++) {
	ma[i] -= ma[1+(i+30) % 55];
      }
    *inext=0;
    *inextp=31;  // magic. don't change
    *l=1;
  }
  if (++*inext == 56) *inext=1;
  if (++*inextp == 56) *inextp=1;
  mj=ma[*inext]-ma[*inextp];
  ma[*inext]=mj;

  /*
  for (int i=0; i<56; i++)
    printf("%i ", ma[i]);
  printf("\n");
  */

  return mj;
}

inline unsigned prng_hash(const char* t)
{
  unsigned int value = 0;
  unsigned int shift = 5;
  unsigned int c;
  
  while ((c = *t++)) {
    c -= ' ';
    value ^= c << (shift & 0xf);
    shift ^= c;
  }
  
  return value ^ (value >> 16);
}

struct prng 
{ 
  prng() { seed(0xdeadbeef); }

  void seed(unsigned seed) {
    //  This isn't very many bits of seed.
    l = -(1 + (seed & 0xffffff));
  }

  void seed(unsigned seedu, const char* seed_str) { 
    seed(prng_hash(seed_str) + seedu); 
  }

  unsigned sample() {
    unsigned u =  prng_sample_sub(&l, &inext, &inextp, ma);
    //    printf("%x\n", u);
    return u;
  }
  
  double sample_u() {
    return sample()/(1+(double)UINT_MAX);
  }
  
  double u() {
    return sample_u();
  }
  
private:
  long l;
  int inext, inextp;
  unsigned ma[56];
};

struct prng_state 
{
  prng_state(prng & p) { old = prng_current; prng_current = &p; }
  ~prng_state()        { prng_current = old; }

  prng * old;
};

static inline unsigned prng_sample()
{
  return prng_current->sample();
}

static inline double prng_sample_u()
{
  return prng_current->sample_u();
}


//  This is the simple, very fast, prng from NR.
//  Fails diehard, even after the adjustment.
//  Only use if speed is crucial and poor randomness isn't a problem.
struct prng_fast
{ 
  prng_fast() { seed(0xdeadbeef); }

  void seed(unsigned seed) {
    state = seed;
  }

  void seed(unsigned seedu, const char* seed_str) { 
    seed(prng_hash(seed_str) + seedu); 
  }

  unsigned sample() {
    state = state*1664525 + 1013904223;
    //  make the low bits a bit more random since we're bound to do sample() % 100 or something
    return state ^ (state >> 24);
  }
  
  double sample_u() {
    return sample()/(1+(double)UINT_MAX);
  }
  
  double u() {
    return sample_u();
  }
  
private:
  unsigned state;
};




  
#endif
