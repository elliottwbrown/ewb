
#ifndef MISC_H
#define MISC_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>

#include "memcheck.h"

void debug_(const char* file,int line, const char* f,const char* msg);
void stub_(const char* file,int line, const char* f,const char* msg);
void warn_(const char* file,int line, const char* f,const char* msg);
void die(const char* fmt,...);
void vdie(const char* fmt, va_list ap);
char* stringit(const char* fmt,...);       
void* xmalloc(size_t size);   
void* xcalloc(size_t nmemb, size_t size);
void* xrealloc(void* ptr, size_t size);

#define WARN_ONCE(x) { static int i; if (!i) { i=1; WARN((x)); } }
#ifdef _MSC_VER
#define DEBUGREAL(x) debug_(__FILE__, __LINE__,__FUNCTION__,stringit x)
#else
#define DEBUGREAL(x) debug_(__FILE__, __LINE__,__PRETTY_FUNCTION__,stringit x)
#endif

#define xDEBUGREAL(x)
#define xDEBUG(x)
#define DEBUG(x) DEBUGREAL(x)
#ifdef _MSC_VER
#define STUB(x) stub_(__FILE__, __LINE__,__FUNCTION__,stringit x)
#define WARN(x) warn_(__FILE__, __LINE__,__FUNCTION__,stringit x)
#else
#define STUB(x) stub_(__FILE__, __LINE__,__PRETTY_FUNCTION__,stringit x)
#define WARN(x) warn_(__FILE__, __LINE__,__PRETTY_FUNCTION__,stringit x)
#endif

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus

#include <string>

#endif

#endif
