import java.awt.event.*;

import javax.swing.*;

import poker.Player;
import poker.util.Preferences;

public class TTHPlayer extends wrapper implements Player {
	
	public static String[] profiles = {
	  "advisor",
	  "adv2", "adv3", "adv4", "adv5", "adv6", "adv7",
	  "bereftbart", "bretmaverick", "bufordmuldoon", 
	  "bulletsmcgee", "cecilycinch", "colonelcapp", "conan",
	  "crustyjack", "drjekyll", "drstrangelove", "edmundwood",
	  "elsworthtooey", "eunicefarthing", "gajoe", "gomerlarue",
	  "gypsyrose", "happyhowie", "harrythehorse", "igorina",
	  "igorinc", "janedoe", "jerryjackpot", "johndoe", "jovialjoe",
	  "judiciousjammer", "lamontcranston", "lanceyhoward", 
	  "larsonwhipsnade", "lashlarue", "llhsat", "lollielarue",
	  "mannythemooch", "mickey", "moemalarkey", "mrhyde",
	  "myopicmike", "mzkangaroo", "nathandetroit", "nicelyjohnson",
	  "omarpotmaker", "paulpennysaver", "redteller", "regularrube",
	  "renfield", "senatorsnort", "simplesimon", "skymasterson",
	  "smilinmack", "sylvia", "tinytim", "trickydickie",
	  "welcomewaldo"
	};
	
	private JComboBox profMenu = new JComboBox(profiles);
	
   public TTHPlayer() {     	
   }
   
   public void init(Preferences prefs) {
   	super.init(prefs);
   	String name = getPreferences().getPreference("TTH_PROFILE", profiles[0]);
    	init("tth:"+name); 
   }
   
	public JPanel getSettingsPanel() {
		JPanel jp = new JPanel();
		String name = getPreferences().getPreference("TTH_PROFILE", profiles[0]);
		
		profMenu.setSelectedItem(name);
		
		profMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getPreferences().setPreference("TTH_PROFILE", (String)profMenu.getSelectedItem());
			}
		});
		
		jp.add(new JLabel("TTH Profile:"));
		jp.add(profMenu);
		
		return jp;
	}
	
}
