// -*- c++ -*-
#ifndef HAND_H
#define HAND_H

//  A set of two cards or 'unknown'
//  The 'hole' class is more useful.
struct MAPOKERATTR Hand 
{
  Hand(const char* c);
  Hand(Card const & c1, Card const & c2)        
  { 
    known_ = c1.known() && c2.known();
    CardMask_RESET(cm); 
    CardMask_SET(cm, c1.c); 
    CardMask_SET(cm, c2.c); 
  }
  
  Hand()                                        { CardMask_RESET(cm); known_ = 0; }

  bool known() const                            { return known_; }
  void set_unknown()                            { known_ = false; }
  
  char* to_str() const; // return static data, string will be 5 chars long
  void print() const; // write exactly 5 chars

  //  FIXME: hideously slow
  Card card(int i /* 0 or 1 */) const; 

  bool operator==(Hand const & h) const         { assert(known() && h.known()); return cm.cards_n == h.cm.cards_n; }

  CardMask cm;
  bool known_;
};

#endif
