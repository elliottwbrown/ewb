#ifndef TTH_MISC_H
#define TTH_MISC_H

//  Number of preflop position codes
#define NPREFLOPPOSITIONS 7

//  preflop pot status codes
#define NPOTSTATUSES 6

#define NPOSTFLOPNOPAIRHANDS  60
#define NPOSTFLOPONEPAIRHANDS 35
#define NPOSTFLOPTWOPAIRHANDS 15
#define NPOSTFLOPTRIPSHANDS   15
#define NPOSTFLOPHANDTYPES    60

//  postflop rounds: 0=flop 1=turn 2=river
#define NPOSTFLOPROUNDS        3

//  posflop position codes
#define NPOSTFLOPPOSNS         3

//  postflop tabs
#define NPOSTFLOPTABS 4

//  Styles for bet variables
#define BV_P_ 0
#define BV_b_ 1
#define BV_B_ 2
#define BV_r_ 3
#define BV_R_ 4
#define BV_s_ 5
#define BV_S_ 6
#define BV_a_ 7
#define BV_A_ 8

//  Special styles which have no max_commit field
#define BV_X1 9
#define BV_x1 10
#define BV_X2 11
#define BV_x2 12

#define BV_CR 13
#define BV_CA 14
#define BV_CC 15
#define BV_CX 16

#define BV_DR 17
#define BV_HU 18

#define BV_PN 19 
#define BV_BN 20
#define BV_RN 21
#define BV_bn 22
#define BV_rn 23

//  an undefined BV
#define BV_UN -1

//  postflop bet variable
struct Tth_bet_variable
{
  static Tth_bet_variable make(const char*);
  const char* to_str() const;

  int style;
  int max_commit;
};

//  preflop action
struct Tth_preflop_strat
{
  //  double p;
  unsigned p; // prob*100
  int normal;
  int alt;
};

struct Tth_profile
{  
  const char* name;

  struct {
    Tth_preflop_strat pair[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_0gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_1gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_2gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_3gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_0gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_1gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_2gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_3gap[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_ace_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_king_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_queen_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_jack_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_ten_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_nine_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_eight_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat suited_seven_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_ace_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_king_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_queen_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_jack_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_ten_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_nine_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_eight_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
    Tth_preflop_strat unsuited_seven_x[NPOTSTATUSES*2*NPREFLOPPOSITIONS];
  } preflop;

  //  postflop tables
  Tth_bet_variable nopair[NPOSTFLOPNOPAIRHANDS][NPOSTFLOPROUNDS][NPOSTFLOPPOSNS];
  Tth_bet_variable onepair[NPOSTFLOPONEPAIRHANDS][NPOSTFLOPROUNDS][NPOSTFLOPPOSNS];
  Tth_bet_variable twopair[NPOSTFLOPTWOPAIRHANDS][NPOSTFLOPROUNDS][NPOSTFLOPPOSNS];
  Tth_bet_variable trips[NPOSTFLOPTRIPSHANDS][NPOSTFLOPROUNDS][NPOSTFLOPPOSNS];

  //  general rules
  //  The only sensible choices seem to be false for everything except consider_pot_odds, which should be true.
  //  I ignore all but consider_pot_odds.
  bool dealer_always_completes_blind;
  bool always_raise_preflop_if_unraised;
  bool consider_pot_odds;
  bool always_see_flop;
  bool always_see_turn;
  bool always_see_river;
  bool never_fold_on_river;
  
  int flush_w1_draw_thresh[NPOSTFLOPROUNDS]; // defined for flop, turn, but not river
  int flush_w1_made_thresh[NPOSTFLOPROUNDS]; // defined for turn, and river but not flop
  int flush_w2_draw_thresh[NPOSTFLOPROUNDS]; // defined for flop, turn, but not river
  int flush_w2_made_thresh[NPOSTFLOPROUNDS]; // defined for all
  int flush_4card_thresh[NPOSTFLOPROUNDS];   // defined for turn, and river but not flop
  int trips_strong_kicker[NPOSTFLOPROUNDS];

  void dump_as_C();
  void dump_as_csv();
  void dump_prefloptable_as_C(const char* tablename, Tth_preflop_strat*);
  void dump_postfloptable_as_C(Tth_bet_variable bv[][NPOSTFLOPROUNDS][NPOSTFLOPPOSNS], int nhandtypes, int tabindex);
  void dump_general_list_as_C(int thres[NPOSTFLOPROUNDS]);
};

void parse_bv(Tth_bet_variable& bv, const char* str);

#endif
