
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_llhsat extends wrapper implements Player
{
    public tth_llhsat() 
    { 
	super("tth:llhsat"); 
    }
}
