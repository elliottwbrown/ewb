/*
 *  poker hand evaluator
 *
 *  Cards in a Std Deck are stored as an integer in the range 0..51 (2h..Ah 2d..2c..2s..As).
 *  Hands are stored as a CardMask (a 64 bit type with one bit for each of the 52 cards).
 *  HandVal is a 32 bit integer allowing comparison of poker hands easy.
 *
 *  Useful routines are:
 *
 *    StdDeck_MAKE_CARD(rank, suit) // suits are 0123 for hdcs, rank is 0..12 for 2..A
 *    CardMask_RESET(cm)            // clear all bits in a CardMask
 *    CardMask_CARD_IS_SET(cm, c)   // test bit
 *    CardMask_SET(cm, card)        // set bit    
 *    Hand_EVAL_N(cm, ncards)       // find value of best 5 card hand using cards
 *
 */
#ifndef POKER_H
#define POKER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "poker/poker_defs.h"
#include "poker/inlines/eval.h"
#if 0
#include "poker/combinations.h"
#include "poker/config.h"
#include "poker/deck.h"
#include "poker/md5c.h"
#include "poker/deck_std.h"
#include "poker/enumdefs.h"
#include "poker/enumerate.h"

  /*
    These redefine CardMask_... macros
  
    #include "poker/deck_undef.h"
    #include "poker/deck_astud.h"
    #include "poker/deck_joker.h"
  */

#include "poker/game_std.h"

  /*
    Redefines Hand_EVAL_...
    
    #include "poker/game_astud.h"
  */
  
  
#include "poker/handval.h"
#include "poker/handval_low.h"
#include "poker/inlines/eval.h"
#include "poker/inlines/eval_low.h"
#include "poker/inlines/eval_low8.h"

  /*
    Note sure if these lead to other macro redefs
  
    #include "poker/inlines/eval_astud.h"
    #include "poker/inlines/eval_joker.h"
    #include "poker/inlines/eval_joker_low.h"
    #include "poker/inlines/eval_joker_low8.h"
    #include "poker/inlines/eval_omaha.h"
    #include "poker/inlines/eval_type.h"
    
  */

  /*
    These lead to '#define c clubs'!
  
    #include "poker/evx_defs.h"
    #include "poker/inlines/evx5.h"
    #include "poker/inlines/evx7.h"
    #include "poker/inlines/evx_inlines.h"
    
  */

#include "poker/rules_std.h"

  /*
    Redefine HandType macros
    
    #include "poker/rules_undef.h"
    #include "poker/rules_astud.h"
    #include "poker/rules_joker.h"
    #include "poker/game_joker.h"
  */
#endif

#ifdef __cplusplus
}
#endif

#endif
