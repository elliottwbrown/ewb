// -*- c++ -*-
/*
 *  Prototypes for the TTH hand/board classification code.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA. 
 */
#ifndef TTH_H
#define TTH_H

//  preflop position codes
#define TTH_SmB 0
#define TTH_BgB 1
#define TTH_UnG 2
#define TTH_Ear 3
#define TTH_Mid 4
#define TTH_Lat 5
#define TTH_But 6

//  preflop potstatuses
#define TTH_BLINDS_ONLY 0
#define TTH_CALLED_POT  1
#define TTH_2TOCALL     2
#define TTH_3TOCALL     3
#define TTH_AGN_1TOCALL 4
#define TTH_AGN_2TOCALL 5

//  postflop positions
#define TTH_First 0
#define TTH_Midl  1
#define TTH_Last  2

void set_tth_verbose(bool);

/*
 *  This is computed at the beginning of each round.  It has the Bet
 *  Variables and draw information for the str draw (which is the
 *  strflush draw if we have one), the flush draw and the made hand
 *  (for which outs and pwin are ignored).  
 */
struct Tth_strategy
{
  Tth_strategy() : flags(0) { }

  void dump();
  const char* to_str();

#define TTH_HAVE_STR_DR   1
#define TTH_HAVE_FL_DR    2

  int flags;
  int tabindex;
  int position;
  int noppo;
  int round;

  struct subs {
    Tth_bet_variable bv;
    int outs;
    double pwin;
    const char* desc;
    int htype;
  } str, fl, made;
};

struct Tth : public Seedable_fast, public Player
{
  Tth(Tth_profile* p = 0) : Seedable_fast(__FILE__), profile(p)  { }

  const char* get_name() const   { return profile->name; }
  void set_seed(unsigned u) { Seedable_fast::set_seed(u); }

  int  get_action(Holdem const &);
  void start_game(Holdem const &, int seat);
  void pre_update (Holdem const &, int who, int action);

  void set_profile(Tth_profile* p) { profile = p; }
  Tth_profile* get_profile()        { return profile; }

  //private:
public:
  Tth_profile* profile;

  //  leader is only guaranteed to be defined post-flop
  int leader;
  bool leader_surrendered; // if the leader checks

  //  Setup at the start of each round.
  Tth_strategy strat;
  
  static const char* decode_htype(int tabindex, int htype);

  //  Get the 'best' profile to at this moment for judging kicker strength
  static Tth_profile* get_best_profile(Holdem const &);

  static int get_preflop_pot_status(const Holdem & h);
  static int get_preflop_position(const Holdem & h);
  int get_preflop_action(Holdem const & h);

  int Tth::get_preflop_action2(Hole hole, int pot, int posn);

  //  NB this only makes sense if we haven't acted yet this round
  static int get_postflop_position(Holdem const & h);

  static int get_action2(Holdem const & h, int & which_action, Tth_strategy &, int leader, bool leader_surrendered, bool consider_pot_odds);
  static int get_action(Holdem const & h, Tth_bet_variable const & bv, int leader, bool leader_surrendered);

  static int consider_pot_odds(Holdem const &, Tth_strategy const &, int action);
  static bool check_raise_ok(Holdem const &, int leader, bool leader_surrendered); // for smart check-raising
  
  static void get_postflop_strat(Hole h, Card const * board, int round /* 0 = flop */, 
				 Tth_profile const* profile, int postflop_positioncode, int noppo,
				 Tth_strategy & strat);

  static void get_postflop_strat(Holdem const & h, Tth_profile const* profile /* need to judge kicker value */, Tth_strategy & strat);

  //  round=0 on flop
  static void do_straights(Card const board[5], int ncards, Hole hole, Straight_info*);

  //  profile may be null if any flush is good enough
  static void do_flushes(Card const board[5], int ncards, Hole hole, Flush_info* fi, int round, Tth_profile const *);

  static void do_strflushes(Card const  board[5], int ncards, Hole hole, Strflush_info* sfi, Flush_info const * fi);
  static void flush_threats(Card const board[5], int ncards, int present[4], int order[4], int topabsent[4], int present2[4][13]);

  static void do_quads(Tth_strategy &, Card const board[5], int ncards, Hole hole, int noppo);

  //  hole_ranks[i] can be -1 if that hole card is to be ignored
  static void do_straights(Card const board[5], int ncards, int hole_ranks[2], Straight_info* strinfo);
  
  static const char* nopair_str(int i);
  static void do_nopair(Tth_strategy &, Card const board[5], int ncards, Hole hole,
			int round, int pos, int noppo, Tth_profile const *);

  static int nopair_made_type(Card const board[5], int ncards, Hole hole, 
			      Strflush_info const & sfi,
			      Straight_info const & si,
			      Flush_info const & fi,
			      Rank_info const & ri);

  static const char* onepair_str(int i);  
  static void do_onepair(Tth_strategy &, Card const board[5], int ncards, Hole hole,
		      int round, int pos, int noppo, Tth_profile const *);
  static int onepair_made_type(Card const board[5], int ncards, int round, Hole hole, 
			       Strflush_info const & sfi,
			       Straight_info const & si,
			       Flush_info const & fi,
			       Rank_info const & ri,
			       int trips_strong_kicker);

  static const char* twopair_str(int i);
  static void do_twopair(Tth_strategy &, Card const board[5], int ncards, Hole hole,
			 int round, int pos, int noppo, Tth_profile const *);
  static int twopair_made_type(Card const board[5], int ncards, int round, Hole hole, 
			       Strflush_info const & sfi,
			       Straight_info const & si,
			       Flush_info const & fi,
			       Rank_info const & ri);
  
  static const char* trips_str(int i);
  static void do_trips(Tth_strategy &, Card const board[5], int ncards, Hole hole,
		       int round, int pos, int noppo, Tth_profile const *);
  static int trips_made_type(Card const board[5], int ncards, int round, Hole hole, 
			     Strflush_info const & sfi,
			     Straight_info const & si,
			     Flush_info const & fi,
			     Rank_info const & ri);

  bool made_flush_good_enough(Flush_info const & fi, int round, Tth_profile const * p);
  bool flush_draw_good_enough(Flush_info const & fi, int round, Tth_profile const * p);
};

//  A Player which uses whichever advisor is appropriate for the number of players dealt in
struct Tth_advisor : public Player
{
  const char* get_name() const                             { return "TTH advisor"; }
  void set_seed(unsigned u)                                { tth.set_seed(u); }
  int  get_action(Holdem const & h)                        { return tth.get_action(h); }
  void start_game(Holdem const &, int seat);
  void pre_update (Holdem const & h, int w, int a)         { tth.pre_update(h, w, a); }

  static Tth_profile* const profiles[8];

private:
  Tth tth;
};

//  FIXME: this doesn't hand preflop states
struct Tth_state 
{
  Tth_state(Hole h, Card const * board, int round /* 0=preflop .. 3=river */);
  
  Tth_state(int round, int tab /* 4 = quads */, int str_type, int fl_type, int made_type) 
  {
    //  1=flop, 2=turn, 3=river
    assert(round >= 1 && round < 4);
    assert(tab >= 0 && tab < 5);
    assert(str_type >= -1 && str_type < 64);
    assert(fl_type >= -1 && fl_type < 64);
    assert(made_type >= 0 && made_type < 64);

    str_type++;
    fl_type++;

    i = round + 4*(tab + 5*(str_type + 65*(fl_type + 65*made_type)));
  }

  int round()     const { return i % 4;           }
  int tab()       const { return (i/4) % 5;       }
  int str_type()  const { return (i/4/5) % 65;    }
  int fl_type()   const { return (i/4/5/65) % 65; }
  int made_type() const { return (i/4/5/65/65);   }

  bool operator==(const Tth_state & s) const {
    return s.i == i;
  }

  struct hashfn {
    unsigned operator()(const Tth_state & s) const {
      return s.i;
    }
  };

  const char *to_str() const 
  {
    static char str[1024];

    unsigned rd = round();
    unsigned tb = tab();
    unsigned mt = made_type();
    unsigned ft = fl_type();
    unsigned st = str_type();
    
    assert(rd > 0 && rd <4);
    assert(tb < 5);
    assert(st < 65);
    assert(ft < 65);
    assert(mt < 64);
    
    char* s = str;
    s += sprintf(s, "round %i, tab %i, ", rd, tb);
    
    if (tb == 0)
      s += sprintf(s, "%s %s %s", 
		   (st ? Tth::nopair_str(st) : " "),
		   (ft ? Tth::nopair_str(ft) : " "), 
		   Tth::nopair_str(mt));
    else if (tb == 1)
      s += sprintf(s, "%s %s %s", 
		   (st ? Tth::onepair_str(st) : " "),
		   (ft ? Tth::onepair_str(ft) : " "), 
		   Tth::onepair_str(mt));
    else if (tb == 2)
      s += sprintf(s, "%s %s %s", 
		   (st ? Tth::twopair_str(st) : " "),
		   (ft ? Tth::twopair_str(ft) : " "), 
		   Tth::twopair_str(mt));
    else if (tb == 3)
      s += sprintf(s, "%s %s %s", 
		   (st ? Tth::trips_str(st) : " "),
		   (ft ? Tth::trips_str(ft) : " "), 
		   Tth::trips_str(mt));
    else if (tb == 4)
      s += sprintf(s, "Quads");

    return str;
  }


  unsigned i;
};

extern const char* prefloppositionnames[NPREFLOPPOSITIONS];
extern const char* prefloppotstatusnames[NPOTSTATUSES];
extern const char* postfloproundnames[3];
extern const char* postfloppositionnames[3];
extern const char* tth_type_names[5]; // tabindex names

#endif
