// -*- c++ -*-
/*
 *  Defines for TTH profiles.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#ifndef TTH_PROFILE_H
#define TTH_PROFILE_H

//  rank thresholds for preflop tables
#define U 0 /* undefined */
#define T 10
#define J 11
#define Q 12
#define K 13
#define A 14
#define X 15 /* i.e. never */ 

//  preflop position codes
#define SmB 0
#define BgB 1
#define UnG 2
#define Ear 3
#define Mid 4
#define Lat 5
#define But 6

//  postflop position codes
#define postflop_First 0
#define postflop_Mid   1
#define postflop_Last  2

#if 0
// an 'always fold' preflop table
strat_t empty[NPOTSTATUSES*2*NPREFLOPPOSITIONS] =

{{1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X},
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X},

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X},
 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}};
#endif

#endif
