// -*- c++ -*-
/*
 *  'human' implementation of the Player interface
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#include "mapoker.h"

int Human::get_action(Holdem const & h)
{
  h.dump();
  printf("Action (pot=%i, %i to call): ", h.get_pot(), h.to_call());

  int c;

 again:
  do {
    c = getchar();
  } while (isspace(c));
  printf("action=%c\n", c);

  if (c == 'c')
    return 1;
  if (c == 'b')
    return 2;
  if (c == 'r')
    return 2;
  if (c == 'f')
    return 0;
  
  if (h.to_call() != 0) {
    fprintf(stderr, "Error: its %i to call\n", h.to_call());
    goto again;
  }
  return 1;
}

void Human::end_of_game(Holdem const & h, vector<chip_t> const & stacks)
{
  printf("\n\n");
  printf("*********************************************\n");
  printf("**************** END OF GAME ****************\n");
  printf("*********************************************\n");
  h.dump();

  //  printf(h.get_history_string().c_str());

  int c;
  do {
    c = getchar();
  } while (c != 'n');
}
