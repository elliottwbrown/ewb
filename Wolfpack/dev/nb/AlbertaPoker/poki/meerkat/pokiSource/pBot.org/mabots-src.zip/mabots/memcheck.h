#ifndef MEMCHECK_H
#define MEMCHECK_H

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <time.h>

#ifdef __unix
#include <unistd.h>
#else
/* assume windows */
#include <windows.h>
#endif

/*
  Change default behaviour so that you get plain normal memory allocation behaviour.
  Use MEMCHECKINIT and MEMCHECK explicitly if you want it.

  #if !defined(NDEBUG) && !defined(NMEMCHECKINIT)
  #define MEMCHECKINIT */
#ifndef _MSC_VER
#ifdef __cplusplus
#include <new.h>
#endif
#endif
/*#endif*/

#ifdef __cplusplus
extern "C" {
#endif

void* memcheck_mallocfill(size_t sz);

#ifdef __cplusplus
}
#endif

  /*
   *  Like MALLOC but always bypasses the clever macros.
   *  Use on things we deliberately let leak.
   */
#define LEAKYMALLOC(x) malloc(x)
#define LEAKYFREE(x)   free(x)

static void* memcheck_obj;
static size_t memcheck_size;
static size_t memcheck_nmemb;

static void memcheck_supress_warnings()
{
  memcheck_obj = 0;
  memcheck_size = 0;
  memcheck_nmemb = 0;
  memcheck_supress_warnings();
}


  /*  Macros defined in terms of other macros */
#define STRDUP(x) strcpy((char*)MALLOC(strlen(x)+1), (x))
#define XSTRDUP(x) strcpy((char*)XMALLOC(strlen(x)+1), (x))

#define XNEW(type)  ((memcheck_obj=NEW(type)) ? (type*)memcheck_obj : (die("Out of memory"), (type*)0))
#define XNEWO(type) XNEW(type)
/*#define XNEWA2(type,rest,size) ((memcheck_obj = NEWA2(type,rest,size)) ? (type (*)rest) memcheck_obj : (die("Out of memory"), (type (*)rest) memcheck_obj)) */
#define XNEWA(type,size) ((memcheck_obj = NEWA(type,size)) ? (type*)memcheck_obj : (die("Out of memory"), (type*)0))
#define XNEWC(type,args) ((memcheck_obj = NEWC(type,args)) ? (type*)memcheck_obj : (die("Out of memory"), (type*)0))
#define XREALLOC(x,c) ((memcheck_obj = REALLOC(x,c)) || !(c) ? memcheck_obj : (die("Out of memory"), (void*)0))
#define XCALLOC(x,c) ((memcheck_obj = CALLOC(x,c)) ? memcheck_obj : (die("Out of memory"), (void*)0))
#define XMALLOC(x) ((memcheck_obj = MALLOC(x)) ? memcheck_obj : (die("Out of memory"), (void*)0))

#define DELETEO_REFCNT(object) if (object) { \
  assert(object->refcnt > 0); \
  if (!--object->refcnt) DELETEO(object); \
}

#define DUP(o) ((o ? ++o->refcnt : 0), o)


#ifndef MEMCHECK
#ifndef MEMCHECKINIT

/*  the no suprises case */

#define NEW(type) new type
#define NEWO(type) new type
#define NEWA(type,size) new type[size]
/*#define NEWA2(type,rest,size) new type[size]rest*/
#define NEWC(type,args) new type args
#define DELETEO(object) delete object
#define DELETEA(object) delete[] object
#define FREE(x) free((void*)x)
#define MALLOC(x) malloc(x)
#define CALLOC(x, y) calloc((x), (y))
#define REALLOC(x,c) realloc(x,c)

#else 

/* MEMCHECKINIT: initialize memory to deadbeef */

#define NEW(type) (type*)(\
 memcheck_obj = memcheck_mallocfill(sizeof(type)), \
 memcheck_obj = new (memcheck_obj) type)

#define NEWC(type,args) (type*)(\
 memcheck_obj = memcheck_mallocfill(sizeof(type)), \
 memcheck_obj = new (memcheck_obj) type args)


/*  This didn't seem to allocate enough memory without the +1, so I binned
 *  memcheck_mallocfill for new[]
#define NEWA(type,size) (type*)(\
 memcheck_size=(size),\
 memcheck_obj = memcheck_mallocfill(memcheck_size*sizeof(type)+1), \
 memcheck_obj = new (memcheck_obj) type[size])
 */
#define NEWA(type,size) (type*)(new type[size])


#define DELETEO(object) delete object
#define DELETEA(object) delete[] object
#define FREE(x) free((void*)x)

#define MALLOC(size) (void*)(\
 memcheck_obj = memcheck_mallocfill(size))

  /* calloc() sets the memory to zero anyway */
#define CALLOC(x, y) calloc((x), (y))

/*  We don't know how large the original block of memory was,
 *  so this is probably a vain attempt.
 */
#define REALLOC(ptr, size) (void*)(\
 memcheck_size = (size),\
 memcheck_obj = memcheck_mallocfill(memcheck_size), \
 free(memcheck_obj), \
 realloc(ptr, memcheck_size))

#endif /* MEMCHECKINIT */

#else /* MEMCHECK */

#define NEW(type) (type*)(\
 memcheck_obj=new type,\
 fprintf(stderr,"NEW(%s) at %s:%i returns %p\n",#type,__FILE__,__LINE__,memcheck_obj),\
 fflush(0), \
 memcheck_obj)
 
#define NEWC(type,args) (type*)(\
 memcheck_obj=new type args,\
 fprintf(stderr,"NEWC(%s,%s) at %s:%i returns %p\n",#type,#args,__FILE__,__LINE__,memcheck_obj),\
 fflush(0), \
 memcheck_obj)
 
#define NEWA(type,size) (type*)(\
 memcheck_size=(size),\
 memcheck_obj=new type[memcheck_size],\
 fprintf(stderr,"NEWA(%s,%u) at %s:%i returns %p\n",\
  #type,memcheck_size,__FILE__,__LINE__,memcheck_obj),\
 fflush(0), \
 memcheck_obj)

/*
#define NEWA2(type,rest,size) (type*)(\
 memcheck_size=(sizeof(type[size]rest),\
 memcheck_obj=new type[memcheck_size]rest,\
 fprintf(stderr,"NEWA(%s,%u) at %s:%i returns %p\n",\
  #type,memcheck_size,__FILE__,__LINE__,memcheck_obj),\
 fflush(0), \
 memcheck_obj)
*/

#define DELETEO(object) (void)(\
 fprintf(stderr,"DELETEO() at %s:%i with %p\n",__FILE__,__LINE__,object),\
 fflush(0), \
 delete object)

#define DELETEA(object)  (void)(\
 fprintf(stderr,"DELETEA() at %s:%i with %p\n",__FILE__,__LINE__,object),\
 fflush(0), \
 delete[] object)

#define FREE(object) (void)(\
 fprintf(stderr,"FREE() at %s:%i with %p\n",__FILE__,__LINE__,object),\
 fflush(0), \
 free(object))

#define MALLOC(size) (void*)(\
 memcheck_size=(size),\
 memcheck_obj=malloc(memcheck_size),\
 fprintf(stderr,"MALLOC(%u) at %s:%i returns %p\n",\
  memcheck_size,__FILE__,__LINE__,memcheck_obj),\
 fflush(0), \
 memcheck_obj)

#define CALLOC(nmemb, size) (void*)(\
 memcheck_size=(size),\
 memcheck_nmemb=(nmemb),\
 memcheck_obj=calloc(memcheck_nmemb, memcheck_size),\
 fprintf(stderr,"CALLOC(%s) at %s:%i returns %p\n",\
  #size "*" #nmemb,__FILE__,__LINE__,memcheck_obj),\
 fflush(0), \
 memcheck_obj)

#define REALLOC(ptr,size) (void*)(\
 memcheck_size=(size),\
 memcheck_obj=realloc(ptr,memcheck_size),\
 fprintf(stderr,"REALLOC(%p,%u) at %s:%i %p %p\n",\
  ptr,memcheck_size,__FILE__,__LINE__,ptr,memcheck_obj),\
 fflush(0), \
 memcheck_obj)

#endif

#endif
