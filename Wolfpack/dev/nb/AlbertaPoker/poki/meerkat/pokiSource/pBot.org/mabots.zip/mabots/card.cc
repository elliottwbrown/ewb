// -*- c++ -*-
/*
 *  Card class definition.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */

#include "mapoker.h"

Card::Card(const char* a)
  : c(-1)
{
  if (!a || a[0] == '?')
    return;

  while (*a && isspace(*a))
    a++;

  if (strlen(a) < 2)
    THROW("Invalid argument to Card constructor");

  int rank = 0;

  switch (toupper(a[0])) {
  case 'A': rank = 12; break; 
  case 'K': rank = 11; break;  
  case 'Q': rank = 10; break;  
  case 'J': rank = 9; break;  
  case 'T': rank = 8; break;  
  case '9': rank = 7; break;  
  case '8': rank = 6; break;  
  case '7': rank = 5; break;  
  case '6': rank = 4; break;  
  case '5': rank = 3; break; 
  case '4': rank = 2; break;  
  case '3': rank = 1; break;  
  case '2': rank = 0; break; 
  default:
    THROW("Invalid argument to Card constructor");
  }
  
  int suit = 0;
  
  switch (tolower(a[1])) {
  case 'h': suit = 0; break;
  case 'd': suit = 1; break;
  case 'c': suit = 2; break;
  case 's': suit = 3; break;
  default:
    THROW("Invalid argument to Card");
  }

  c = suit*13 + rank;
}

void Card::print() const
{
  printf("%s", to_str());
}

char* Card::to_str() const
{
  char* ranks = "23456789TJQKA";
  char* suits = "hdcs";
  static char buf[3];
  
  memset(buf, 0, sizeof(buf));

  if (c == -1)
    strcpy(buf, "??");
  else
    sprintf(buf, "%c%c", ranks[c % 13], suits[c / 13]);

  return buf;
}
