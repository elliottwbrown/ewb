
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_trickydickie extends wrapper implements Player
{
    public tth_trickydickie() 
    { 
	super("tth:trickydickie"); 
    }
}
