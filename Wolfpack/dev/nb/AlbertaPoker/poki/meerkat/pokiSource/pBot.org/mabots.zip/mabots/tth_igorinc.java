
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_igorinc extends wrapper implements Player
{
    public tth_igorinc() 
    { 
	super("tth:igorinc"); 
    }
}
