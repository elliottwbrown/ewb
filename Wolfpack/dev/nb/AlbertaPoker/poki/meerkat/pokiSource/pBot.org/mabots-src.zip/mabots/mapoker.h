#ifndef MAPOKER_H
#define MAPOKER_H

#ifdef _MSC_VER
#include "msvc.h"
#endif

#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <errno.h>
#include <stdio.h>
#include <math.h>
#ifndef NOHASHMAP
#include <hash_map>
#endif
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <list>
#include <map>
#include <set>
#include <assert.h>
#include <ctype.h>

#ifdef unix
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#define MKDIR(path,mode) mkdir((path),(mode))
#define MAPOKERATTR
#endif

#ifdef __MINGW32__
#include "mingw.h"
#endif

//  pokersource library
#include "poker.h"

#ifndef uint64
#define uint64 unsigned long long
#endif

#include "mapoker_misc.h"
#include "card.h"
#include "hand.h"
#include "holdem.h"
#include "prng.h"
#include "hole.h"
#include "types.h"
#include "misc.h"
#include "player.h"
#include "card_mask.h"

#ifndef BUILD_MAPOKER
#include "extra_bots.h"
#endif

#include "human.h"
#include "bot_manager.h"
#include "utils.h"
#include "tth_misc.h"
#include "seedable.h"

#include "tth_misc.h"
#include "tth_types.h"
#include "tth_profiles.h"
#include "tth.h"
#include "strategy.h"

#include "reporter.h"

#include "dealer.h"

#endif
