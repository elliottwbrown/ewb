
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_judiciousjammer extends wrapper implements Player
{
    public tth_judiciousjammer() 
    { 
	super("tth:judiciousjammer"); 
    }
}
