/* -*- c++ -*-
 *
 *  Holdem game state class.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#ifndef HOLDEM_H
#define HOLDEM_H

using namespace std;

#define MAX_PLAYERS 20
#define MAX_ACTIONS 8

//  values returned by Holdem::get_round()
#define HOLDEM_PREFLOP 0
#define HOLDEM_FLOP    1
#define HOLDEM_TURN    2
#define HOLDEM_RIVER   3

#define PREDEAL       0  // just waiting for the predeal info to be provided
#define PREFLOP       1
#define PREFLOPEND    2  // just waiting for the flop to be revealed
#define FLOP          3
#define FLOPEND       4  // just waiting for the turn to be revealed
#define TURN          5
#define TURNEND       6  // just waiting for the river to be revealed
#define RIVER         7
#define SHOWDOWN      8
#define HANDEND       9  // allows retrieving of hand status
#define PREMATHANDEND 10 // just one player left, he can 'show' or 'noshow'
#define HOLDEM_NSTATES 11

class MAPOKERATTR Holdem {
public:
  struct Action {
    typedef enum { undef, blind, fold, bet /* covers check, bet, call, raise */, betsallin, show, noshow, muck } type_t;
    Action()             { type = undef; }
    Action(type_t a)     { type = a; }
    Action(type_t a, int amt) { type = a; amount = amt; }
    type_t type;

    //  number of chips the guy puts in the pot (so check = bet 0, call = bet to_call())
    int amount;
    Hand hand;  // used for 'show' actions
  };
  
  Holdem();

  //  state mustn't be predeal or handend
  Holdem & act(unsigned player, Action const &);
  Holdem & act(Action const & a)                   { act(whose_on(), a); return *this; }

  void fold() { act(Action(Action::fold)); }
  void call() { Action a(Action::bet); a.amount=to_call(); act(a); }

  //  I'm not sure what 'raise' really means if to_call() is a partial bet from an all-in guy.
  void raise(){ Action a(Action::bet); a.amount=to_call()+raise_this_round(); act(a); }

  //  Guy puts <amount> into the pot and is allin from now on
  void goallin(int am) {
    Action a(Action::betsallin);
    a.amount = am;
    act(a);
  }

  void bet()  
  { 
    //  If previous guy betsall in for less than a full bet,
    //  people can 'bet' even though to_call is > 0 (on PartyPoker at least)
    //    assert(to_call() == 0);
    Action a(Action::bet); 
    a.amount = raise_this_round(); 
    act(a); 
  }
  
  void bet(int amt)  
  { 
    Action a(Action::bet); 
    a.amount = amt;
    act(a); 
  }

  void check();

  //  return -1 if filename didn't contain even a partial hand
  int load(const char* filename);
  int load(FILE* fp);

  //  moves state to PREDEAL
  //  The whole rake idea needs to be redone properly
  //  headups means nplayers == 2 and use reverse blinds.
  Holdem & set_structure(int ante_, int small_blind_, int big_blind_, int small_bet_, int big_bet_, 
			 double rake_ = 0.1, int max_rake_ = 3, bool headsup = false);

  Holdem & set_gameid(int g)  { gameid = g; return *this; }
  int      get_gameid() const { return gameid; }

  //  moves state to PREFLOP
  Holdem & set_predeal(vector<string> const & players_,
		       vector<int> const & starting_chips_,
		       vector<int> const & allin_,    // you can be all-in even if you have chips (e.g. disconnected)
		       unsigned dealer_,
		       vector<int> live_blinds_,      // live part
		       vector<int> dead_blinds_,      // dead part
		       vector<Hand> hands_,
		       int nblinds = 2);              // just used to workout who starts the betting pre-flop

  //  state must be PREFLOPEND/FLOPEND/TURNEND etc.
  Holdem & set_flop(Card const flop[3]);
  Holdem & set_flop(vector<Card> v)             { Card flop[3] = { v[0], v[1], v[2] }; set_flop(flop); return *this; }
  Holdem & set_turn(Card const & c)             { set_card(c, 0); return *this; }
  Holdem & set_river(Card const & c)            { set_card(c, 1); return *this; }

  void set_hand(unsigned player, Hand h);

  int get_state() const                         { return state; }

  int raise_this_round() const;

  int get_raise_this_round() const { return raise_this_round(); } 

  //  FIXME assume cap at 4 bets per round
  int get_can_bet()   const { return get_max_bet_this_round() < get_raise_this_round(); }
  int get_can_raise() const { return get_max_bet_this_round() < cap(); }
  int get_can_check() const { return to_call() == 0; }

  int cap() const { return 4*get_raise_this_round(); }

  int get_potential_reraise() const;

  unsigned whose_on() const
  {
    assert(state != PREDEAL
	   && state != PREFLOPEND
	   && state != FLOPEND
	   && state != TURNEND
	   && state != SHOWDOWN
	   && state != HANDEND);
    
    return on;
  }
  
  //  prints info about what will happen next
  void whats_next() const;

  //  assume state is PREFLOP/FLOP/TURN/RIVER, how much does the next guy have to contribute to call?
  int to_call() const;

  //  How much does a player have to put in to raise?
  //  If he puts in less than this, he ought to be going allin.
  int to_raise() const
  {
    if (get_bet_this_round(whose_on()) + to_call() + get_raise_this_round() < cap())
      return to_call() + get_raise_this_round();
    else 
      return cap() - get_bet_this_round(whose_on());
  }

  /*
   *  leader = index of the last raiser.
   *  If no-one has raised yet, it's the index of the first caller (excluding
   *  peopl who are able to check preflop).
   *  If this is the preflop round an on-one has called yet, leader() returns -1.
   *
   *  If the leader's last action was a fold or check, he has 'surrendered'.
   */
  int  get_leader() const;
  bool get_leader_surrendered() const;

  double get_nbetstocall() const { return to_call()/(double)raise_this_round(); }

  int has_acted(int p) const { return nactions[p][state] > 0; }
  int has_acted() const { return has_acted(whose_on()); }

  vector<int> & get_payouts(vector<int> & a) const;

  int  get_payout(unsigned p) const { assert(p < nplayers); return payout[p]; }

  vector<int> & get_net_change(vector<int> & a) const;
  int get_net_change(unsigned p) const;

  //  must be in state SHOWDOWN or PREMATHANDEND for both of these
  //  after do_showdown() we get moved into state HANDEND
  void whos_in_showdown(vector<int> & a);
  void do_showdown(vector<Hand> const & hands); // undef for mucked hands
 
  void dump() const;

  //  return the number of player yet to make any action this round.
  int get_ntoact() const;

  int            get_ante()           const { return ante; }
  int            get_small_blind()    const { return small_blind; }
  int            get_big_blind()      const { return big_blind; }
  double         get_rake()           const { return rake; }
  int            get_max_rake()       const { return max_rake; }

  int            get_small_bet()      const { return small_blind; }
  int            get_big_bet()        const { return big_bet; }

  Action         get_last_action()    const { return last_action; }

  int            get_nblinds()        const { return nblinds; }
  unsigned       get_nplayers()       const { return nplayers; }

  //  effective nplayers = nplayers - number of folds before the first preflop call/raise.
  //  If we're still in the preflop round and no-one has called/raised, it will be
  //  nplayers - number of folds so far.
  unsigned       get_effective_nplayers() const;

  vector<string> get_players()        const { return players; }
  string const & get_player(unsigned p) const;
  vector<int>    get_starting_chips() const { return starting_chips; }
  int            get_starting_chips(unsigned p) const { assert(p < nplayers); return starting_chips[p]; }
  unsigned       get_dealer()         const { return dealer; }
  int            get_blind(int c)     const { return blinds[c]; }
  vector<int>    get_blinds()         const { return blinds; }
  vector<int>    get_dead_blinds()    const { return dead_blinds; }
  vector<Hand>   get_hands()          const { return hands; }
  Hand           get_hand(int c)      const { return hands[c]; }
  Hand           get_hand()           const { return get_hand(whose_on()); }

  //  finds the next player who is waiting (i.e. skips allin players)
  int            next_stillin(unsigned i) const;

  //  Players who are waiting (i.e. like nstillin() but ignores allin players)
  int            get_nactive() const;

  //  Return 1 for people who are not 'out' (so players are waiting or allin)
  int            stillin(int c) const { return player_state[c] == waits || player_state[c] == allin; }
  void           get_stillin(vector<int>&) const ;
  int            get_nstillin() const ;

  //  Number of waiting players (ignores allin)
  int            get_nunacted() const ;

  //  Cards not yet dealt will be left unchanged
  void           get_board(Card cards[5]) const ;
  Card           get_board_card(int i) const;
  string         get_board_str() const;

  //  The number of board cards visible
  int            get_nseen() const ;

  int            get_pot()                  const { return pot; }
  int            get_bet_this_round(int p)  const { return bet_this_round[p]; }
  int            get_committment(int p)     const { return bet_this_round[p] - (state==PREFLOP)*blinds[p]; }
  int            get_committment()     const { return get_committment(whose_on()); }
  int            made_nonforced_bet(int p)  const { return bet_this_round[p] > (state==PREFLOP)*blinds[p]; }
  vector<int>    get_bets_this_round(int p) const { return bet_this_round; }
  int            get_max_bet_this_round()   const { return max_bet_this_round; }
  //  int            get_ncalls_this_round()    const { return ncalls_this_round; }
  
  unsigned       get_small_blind_seat()          const { return headsup ? dealer : (1+dealer) % nplayers; }
  unsigned       get_big_blind_seat()            const { return headsup ? 1-dealer : (2+dealer) % nplayers; }

  //  (About the person on) 0 is dealer, 1 is person before dealer ... 
  //  These counts are as if everyone was still in.
  int            get_position()             const { return (dealer - whose_on() + nplayers) % nplayers; } 
  int            get_position(int p)        const { return (dealer - p + nplayers) % nplayers; }

  //  -2 BB, -1 SB, 0 last, 1 2nd last 2, two-three-four, 3 other
  int            get_preflop_positioncode(unsigned p) const;

  int            raised_this_round(int p)   const;
  int            called_this_round(int p)   const;

  // 0 first 1 last 2 other
  int            get_simple_positioncode(unsigned p) const;

  //  raises or bets (ignores blinds)
  int            get_nbets_this_round() const;
  int            get_nraises_this_round()   const { return get_nbets_this_round(); }
  int            get_ncalls_this_round() const;
  int            get_nchecks_this_round() const;

  int            get_nraises_this_round_by(unsigned p) const;
  int            get_ncalls_this_round_by(unsigned p) const;
  int            get_nchecks_this_round_by(unsigned p) const;

  //  over all rounds
  int            get_nraises_by(unsigned p) const;
  int            get_ncalls_by(unsigned p) const;
  int            get_nchecks_by(unsigned p) const;

  // -1 if no-one has raised at all this hand
  // if the last raiser has folded, (very unusual) we end up returning the index of a folded player
  int get_last_raiser() const;
  
  //  Stuff useful to predicting preflop actions
  struct preflop_info {

    //  of the people stillin 
    int nraisers;
    int ncallers; // if they both called & raised, treat them as a raiser

    //  these int are really booleans
    int early_position_raiser;
    int mid_position_raiser;
    int late_position_raiser;
    int blind_position_raiser;

    int early_position_caller;
    int mid_position_caller;
    int late_position_caller;
    int blind_position_caller;

    int potential_reraise;

    //  -1 if there have been no raises.
    //  -2 if the last raiser has had callers.
    //  <raiser seat> otherwise
    int last_raiser;

    const char* to_str() const;
  };

  void get_preflop_info(struct preflop_info*) const;

  //  seat of player to act last next round if every called in the current one (i.e. dealer unless he folded)
  //  state must be <=RIVER and not PREDEAL
  int            get_last_to_act() const;

  int            get_first_to_act() const;
  int            get_nraises_on_round(int r) const;

  //  returns 0,1,2 or 3 for preflop/flop/turn/river, asserting we're in one of those states
  int            get_round() const;
  void           check_round() const;
  int            end_of_round() const 
  { 
    return state == PREFLOPEND || state == FLOPEND || state == TURNEND || state == SHOWDOWN || state == PREMATHANDEND;
  }

  int normal_state() const
  {
    return state == PREFLOP || state == FLOP || state == TURN || state == RIVER;
  }

  /*
   *  B(lind) b(et) rckf/ etc.
   *  'a' prefix means the rck is allin.
   *  player_summary()
   *  <schips> <live post/blind> <name>\n
   *  ...
   *  <prefix> <historystring>
   */
  string get_history_string() const { return history_string; }
  string get_player_summary() const;

  //  <historystring> <hands> <board> '|' <net changes>
  string get_game_string() const;

  //  has player p seen the flop?
  //  If everyone else folds preflop, the winner is treated as having 'seen' the flop.
  int get_saw_flop(unsigned p) const;

  int get_raised_preflop(int p) const;

  //  total number of chips a player has put in the pot excluding dead blinds but including live blinds
  int get_total_contrib(unsigned p) const {
    assert(p < nplayers);
    return total_contrib[p];
  }
  
private:

  /*
   *  Betting structure
   */
  int ante;
  int small_blind;
  int big_blind;
  int small_bet;
  int big_bet;
  double rake;
  int max_rake;

  int gameid;

  /*
   *  If the game is headsup, there must be 2 players.
   *  The dealer posts the small blind, other guy posts the big blind.
   *  Dealer acts first preflop.  If dealer calls, big blind may raise.
   */
  bool headsup;

  //  Initial state
  int nblinds;
  vector<string> players;
  vector<int> starting_chips;
  unsigned dealer;
  vector<int> blinds;   // includes posts, but only the live parts
  vector<int> dead_blinds;   // includes posts
  vector<Hand> hands;   // may be modified during showdown
  unsigned nplayers;

  //  mutable game state

  //  We really just need to know which players have acted in the current state
  int nactions[MAX_PLAYERS][HOLDEM_NSTATES];

  //  list of who acted in each state
  //  FIXME unlimited raising battles when heads up may give unbounded number of actions
  unsigned nacted[HOLDEM_NSTATES]; // number of actions.
  struct action_ {
    int player;
    int was_a_raise; // may need this to determine last player to 'show' strength for showdown order.  'bet' is a raise too
    bool can_raise;
    Action act;
  } actions[HOLDEM_NSTATES][MAX_ACTIONS*MAX_PLAYERS];

  string history_string;

  vector<int> saw_flop;

  Action last_action;

  //  number of chips put into pot by each player
  vector<int> total_contrib;

  int state;

  int pot;
  unsigned on;
  vector<int> bet_this_round;
  //  int ncalls_this_round;

  // this may be less than the max(bet_this_round) if someone went all-in posting a blind.
  int max_bet_this_round;
  //  int nraises_this_round;

  //  current number of chips
  vector<int> chips;

  //  A player may be treated as all-in even though they have chips - network timeouts.
  //  Out includes folds or mucks.
  typedef enum { out, allin, waits, showed } state_t;
  vector<state_t> player_state;

  Card board[5];





  /*
   *  Results of showdown
   *  Payout is less useful than 'net change'
   */
  vector<int>     payout;
  vector<HandVal> final_handval;

  //  internal routines

  Holdem & store_action(unsigned player, Action const &);
  Holdem & betting_round_act(unsigned player, Action const & action);
  Holdem & premature_handend(unsigned player, Action const & action);

  //  return -1 if the betting round has ended.
  int next_on();
  Holdem & init_round();
  Holdem & set_card(Card const c, int is_river);

  //  Called from act() at the end of the showdown and someone showed their hand.
  //  Sets up final_hand_rank and payout.
  void end_of_hand();

  int sum_penalties() const;
};


#endif

