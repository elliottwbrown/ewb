/***************************************************************************
   Copyright (c) 2000:
         University of Alberta,
         Deptartment of Computing Science
         Computer Poker Research Group

         See "Liscence.txt"
***************************************************************************/

package poker.util;

import java.io.*;

/**
 * Creates a lower triangular matrix for storing weights between the two axis.
 * Similar to a "Distance Map" -- you can store and look up the distance
 * from a to b or from b to a. 
 *
 * @author  Aaron Davidson
 * @version 1.0.3
 */

public class TriangularWeightTable implements Serializable {
	private double[] wt;
	private int	size;
	private double	gSum;
	private boolean dirty = true;

	/**
	 * Create a table of a given size
	 * @param size the size of the table or number of indexes
	 */
	public TriangularWeightTable(int size) {
		initTable(size,0);
	}


   public TriangularWeightTable(String fname) {
      try {
         RandomAccessFile f = new RandomAccessFile(fname,"r");
			size = f.readInt();
			initTable(size,0);
			int i=0;
         while (i < size)
            wt[i++] = f.readDouble();
         f.close();
      } catch (IOException ie) { ie.printStackTrace(); }

   }

   public void save(String fname) {
      try {
         RandomAccessFile f = new RandomAccessFile(fname,"rw");
			f.writeInt(size);
			int i=0;
         while (i < size)
            f.writeDouble(wt[i++]);
         f.close();
      } catch (IOException ie) { ie.printStackTrace(); }
   }



	/**
	 * Create a table of a given size and initialize elements to given value.
	 * @param size the size of the table or number of indexes
	 * @param initVal the initial value of table elements
	 */
	public TriangularWeightTable(int size, double initVal) {
		initTable(size,initVal);
	}

	/**
	 * create a table of size*size where all entries are initialized
	 * to val.
	 */
	protected void initTable(int size, double val) {
		this.size = size;
		wt = new double[((size*(size-1))/2)];
		for (int i=0;i<wt.length;i++)
			wt[i] = val;
		gSum = val*wt.length;
		dirty = false;
	}


	/**
	 * initialize all entries in the table to val.
	 */
	public void initTable(double val) {
		for (int i=0;i<wt.length;i++)
			wt[i] = val;
		gSum = val*wt.length;
		dirty = false;
	}


	/**
	 * Store a copy of a given table into this table.
	 * The tables must be of equivalent sizes
	 */
	public void copy(TriangularWeightTable t) {
		if (size != t.size) return;
		for (int i=0;i<wt.length;i++)
			wt[i] = t.wt[i];		
		gSum = t.gSum;
		dirty = t.dirty;
	}

	/**
	 * normalize the entries in the weight table to sum to 1.0
	 */
	public void normalize() {
		double s = sum();
		for (int i=0;i<wt.length;i++)
			wt[i] /= s;
		gSum = 1.0;
	}
	
	/**
	 * Scale all the entries up to a maximum value of 1.0
	 */
	public void scale() {
		double l = 1.0/getMax();
		for (int i=0;i<wt.length;i++) 
			wt[i] *= l;
		dirty = true;
	}
	
	/** 
	 * return the maximum value in the table 
	 */
	public double getMax() {
		double l = Double.MIN_VALUE;
		for (int i=0;i<wt.length;i++) 
			if (wt[i] > l) l = wt[i];
		return l;
	}

	/**
	 * Merge a table t into this table (50% mixture)
	 */
	public void merge(TriangularWeightTable t) {
		if (size != t.size) return;
		double s = sum();
		for (int i=0;i<wt.length;i++)
			wt[i] = wt[i]/s + t.wt[i]/t.sum();
		dirty = true;
	}

	/** 
	 * Obtain the sum of the weight table
	 */
	public double sum() {
		if (dirty) {
			gSum = 0;
			for (int i=0;i<wt.length;i++)
				gSum += wt[i];
		}
		return gSum;
	}

	/**
	 * Get the weight at the given index.
	 */
	public double getWeight(int index) {
		return wt[index];
	}

	/**
	 * set the weight at index to value
	 */
	protected void setWeight(int index, double val) {
		wt[index] = val;
		dirty = true;
	}

	/**
	 * The total number of entries in the table.
	 */
	public final int length() {
		return wt.length;
	}

	/**
	 * Get the actual offset into the array for a given pair.
	 */
	public final int getIndex(int x, int y) {
		if (x>y) return ((x*(x-1))/2+y);
		else if (x<y) return ((y*(y-1))/2+x);
		return -1;
	}

	/** 
	 * Obtain the value linking elements x and y
	 * @param x the first element 
	 * @param y the second element 
	 * @return the value of x,y
	 */
	public final double getCell(int x, int y) {
		// ** assert coordinates
		if (x>y) return wt[(x*(x-1))/2+y];
		else if (x<y) return wt[(y*(y-1))/2+x];
		return -1; // ** should throw exception	
	}

	/** 
	 * Set the value linking elements x and y
	 * @param x the first element 
	 * @param y the second element 
	 * @param val the value of x,y
	 */
	public final void setCell(int x, int y, double val) {
		// ** assert coordinates
		if (x>y) wt[(x*(x-1))/2+y] = val;
		else if (x<y) wt[(y*(y-1))/2+x] = val;
		else {}// ** should throw exception	?
		dirty = true;
	}

	/** 
	 * Mutliply the entry by a value
	 * @param x the first element 
	 * @param y the second element 
	 * @param val the value to reweight by
	 */
	public double reWeight(int x, int y, double val) {
		dirty = true;
		setCell(x, y, getCell(x,y) * val);
		return getCell(x,y);
	}

	/**
	 * Obtain a string representation of this object.
	 */
	public String toString() {
		StringBuffer s = new StringBuffer();

		for (int i=1;i<size;i++) {
			for (int j=0;j<i;j++) {
				s.append(" "+ getCell(i,j) + " ");
			}
			s.append("\n");
		}
		return s.toString();
	}



}

