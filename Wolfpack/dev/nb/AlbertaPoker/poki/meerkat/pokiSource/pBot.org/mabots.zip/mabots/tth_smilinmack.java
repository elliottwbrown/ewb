
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_smilinmack extends wrapper implements Player
{
    public tth_smilinmack() 
    { 
	super("tth:smilinmack"); 
    }
}
