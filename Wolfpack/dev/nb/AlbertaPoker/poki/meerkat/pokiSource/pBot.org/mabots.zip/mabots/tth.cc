/*
 *  Implementation of Turbo Texas Holdem's hand/board classification.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#include "mapoker.h"
#include "tth_profile.h"

static bool verbose;

//Tth_profile* const Tth_advisor::profiles[9] = {0, 0, &tth_adv_2, &tth_adv_3, &tth_adv_4, &tth_adv_5, &tth_adv_6, &tth_adv_7};
//  I think adv7 is better than adv6 in 6-handed games
Tth_profile* const Tth_advisor::profiles[9] = {0, 0, &tth_adv_2, &tth_adv_3, &tth_adv_4, &tth_adv_5, &tth_adv_7, &tth_adv_7};

const char* prefloppositionnames[NPREFLOPPOSITIONS] = { "SmB", "BgB", "UnG", "Ear", "Mid", "Lat", "But" };
const char* prefloppotstatusnames[NPOTSTATUSES] =
{ "Blinds only",
  "Called Pot",
  "tocall=2",
  "tocall=3",
  "again: tocall=1",
  "again: tocall=2" };

const char* postfloproundnames[3] = { "flop", "turn", "river" };
const char* postfloppositionnames[3] = { "1st", "Mid", "Last"} ;

void set_tth_verbose(bool b)
{
  verbose = b;
}

void Tth_advisor::start_game(Holdem const & h, int seat)
{
  if (h.get_nplayers() >= 7)
    tth.set_profile(&tth_adv_7);
  else
    tth.set_profile(profiles[h.get_nplayers()]);

  if (verbose) REPORT(stringit("Using profile %s", tth.get_profile()->name));

  tth.start_game(h, seat);
}

int Tth::get_preflop_action(Holdem const & h)
{
  Hole hole = h.get_hand();
  int  pot  = get_preflop_pot_status(h);
  int  posn = get_preflop_position(h);

  Tth_preflop_strat* c = 0;
  Tth_preflop_strat* r = 0;

  if (hole.suited()) {
    switch (hole.gap()) {
    case 0:
      if (verbose) REPORT("Suited gap 0");
      c =  &profile->preflop.suited_0gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_0gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;

    case 1:
      if (verbose) REPORT("Suited gap 1");
      c =  &profile->preflop.suited_1gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_1gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
  
    case 2:
      if (verbose) REPORT("Suited gap 2");
      c =  &profile->preflop.suited_2gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_2gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
  
    case 3:
      if (verbose) REPORT("Suited gap 3");
      c =  &profile->preflop.suited_3gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_3gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
    }

    switch (hole.toprank()+2) {
    case A:
      if (verbose) REPORT("Ax suited");
      c =  &profile->preflop.suited_ace_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_ace_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;

    case K:
      if (verbose) REPORT("Kx suited");
      c =  &profile->preflop.suited_king_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_king_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;

    case Q:
      if (verbose) REPORT("Qx suited");
      c =  &profile->preflop.suited_queen_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_queen_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case J:
      if (verbose) REPORT("Jx suited");
      c =  &profile->preflop.suited_jack_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_jack_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;

    case T:
      if (verbose) REPORT("Tx suited");
      c =  &profile->preflop.suited_ten_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_ten_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 9:
      if (verbose) REPORT("9x suited");
      c =  &profile->preflop.suited_nine_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_nine_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 8:
      if (verbose) REPORT("8x suited");
      c =  &profile->preflop.suited_eight_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_eight_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 7:
      if (verbose) REPORT("7x suited");
      c =  &profile->preflop.suited_seven_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.suited_seven_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
    }

    assert(!"Internal error");
  } else {
    //  unsuited
    
    switch (hole.gap()) {
    case -1:
      if (verbose) REPORT("Pair");
      c =  &profile->preflop.pair[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.pair[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;

    case 0:    
      if (verbose) REPORT("Unsuited gap 0");
      c =  &profile->preflop.unsuited_0gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_0gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
  
    case 1:
      if (verbose) REPORT("Unsuited gap 1");
      c =  &profile->preflop.unsuited_1gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_1gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 2:
      if (verbose) REPORT("Unsuited gap 2");
      c =  &profile->preflop.unsuited_2gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_2gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 3:
      if (verbose) REPORT("Unsuited gap 3");
      c =  &profile->preflop.unsuited_3gap[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_3gap[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
    }

    switch (hole.toprank()+2) {
    case A:
      if (verbose) REPORT("Ax unsuited");
      c =  &profile->preflop.unsuited_ace_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_ace_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;

    case K:
      if (verbose) REPORT("Kx unsuited");
      c =  &profile->preflop.unsuited_king_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_king_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case Q:
      if (verbose) REPORT("Qx unsuited");
      c =  &profile->preflop.unsuited_queen_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_queen_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case J:
      if (verbose) REPORT("Jx unsuited");
      c =  &profile->preflop.unsuited_jack_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_jack_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case T:
      if (verbose) REPORT("Tx unsuited");
      c =  &profile->preflop.unsuited_ten_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_ten_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 9:
      if (verbose) REPORT("9x unsuited");
      c =  &profile->preflop.unsuited_nine_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_nine_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 8:
      if (verbose) REPORT("8x unsuited");
      c =  &profile->preflop.unsuited_eight_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_eight_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
      
    case 7:
      if (verbose) REPORT("7x unsuited");
      c =  &profile->preflop.unsuited_seven_x[NPREFLOPPOSITIONS*(2*pot + 0) + posn];
      r =  &profile->preflop.unsuited_seven_x[NPREFLOPPOSITIONS*(2*pot + 1) + posn];
      goto done;
    }

    assert(!"Internal error");
  }

 done:
  
  if (verbose) REPORT(stringit("Call threshold on lo rank is %i/%i with prob %i", c->normal, c->alt, c->p/100.0));
  if (verbose) REPORT(stringit("Raise threshold on lo rank is %i/%i with prob %i", r->normal, r->alt, r->p/100.0));

  int cv = (p.sample() % 100) < c->p ? c->normal : c->alt;
  int rv = (p.sample() % 100) < r->p ? r->normal : r->alt;
  int val = hole.lorank() + 2;    
  
  //  If we're in the big blind and the pot is unraised, our call threshold is '15' according to the profiles
  if (posn == BgB && pot == 1)
    cv = 2;

  if (val >= rv)
    return 2;
  if (val >= cv)
    return 1;
  return 0;
}

void Tth::get_postflop_strat(Holdem const & h, Tth_profile const* profile, Tth_strategy & strat)
{
  int present[13];
  int rs[13];
  int i;
  
  Card board[5];
  Hole hole(h.get_hand());
  h.get_board(board);
  
  //  h.dump();

  int round = h.get_round()-1;
  int pos = get_postflop_position(h);
  int noppo = h.get_nstillin()-1;
  int nseen = h.get_nseen();
  
  for (i=0; i<13; i++)
    present[i] = 0;
  
  for (i=0; i<nseen; i++)
    present[board[i].rank()]++;
  
  //  sort into increasing order
  memcpy(rs, present, sizeof(int)*13);
  sort(rs, rs+13);
  
  strat.position = pos;
  strat.noppo = noppo;
  strat.round = h.get_round()-1;

  if (rs[12] == 1) {
    strat.tabindex = 0;
    do_nopair(strat, board, nseen, hole, round, pos, noppo, profile);
    
  } else if (rs[12] == 2 && rs[11] < 2) {
    strat.tabindex = 1;
    do_onepair(strat, board, nseen, hole, round, pos, noppo, profile);
    
  } else if (rs[12] == 2 && rs[11] == 2) {
    strat.tabindex = 2;
    do_twopair(strat, board, nseen, hole, round, pos, noppo, profile);
    
  } else if (rs[12] == 3) {
      //  assume board = Full House is handled in trips
    strat.tabindex = 3;
    do_trips(strat, board, nseen, hole, round, pos, noppo, profile);
    
  } else if (rs[12] == 4) {
    strat.tabindex = 4;
    do_quads(strat, board, nseen, hole, noppo);
    
  } else 
    assert(!"Internal error");

  if (verbose) REPORT(stringit("tabindex %i\n", strat.tabindex));
}

//  return action and mask depending on which rules applid str/fl/madehand rule
int Tth::get_action2(Holdem const & h, int & which_action, Tth_strategy & strat, int leader, bool leader_surrendered, bool consider_pot_odds)
{
  /*  strat now set up (or was setup at the start of the round).
   *  Figure out how to interpret the BV as a betting action.  
   *
   *  Sensitive profiles are handled by getting the 'normal' action
   *  and then 'weakening' it if the EV of the normal action is -ve.
   */
  strat.dump();

  int draw_action = 0;
  int made_action = 0;
  
  //  Get most aggessive action suggested by draws
  if (strat.flags & TTH_HAVE_STR_DR) {
    draw_action = get_action(h, strat.str.bv, leader, leader_surrendered);
    which_action = 0;
  }
  
  if (strat.flags & TTH_HAVE_FL_DR) {
    int action = get_action(h, strat.fl.bv, leader, leader_surrendered);
    
    if (action == draw_action) {
      //      which_action |= 2;
      which_action = 1;
    } else if (action > draw_action) {
      draw_action = action;
      //      which_action = 2;
      which_action = 1;
    }
  }
  
  //  reduce raise->call->fold to get maximum EV
  if (draw_action && consider_pot_odds)
    draw_action = Tth::consider_pot_odds(h, strat, draw_action);

  made_action = get_action(h, strat.made.bv, leader, leader_surrendered);
  
  int action = draw_action;

  if (made_action == draw_action) {
    //    which_action |= 4;
    which_action = 2;
  } else if (made_action > draw_action) {
    action = made_action;
    //    which_action = 4;
    which_action = 2;
  }

  return action;
}

int Tth::get_action(Holdem const & h)
{
  if (h.get_round() == HOLDEM_PREFLOP)
    return get_preflop_action(h);

  if (!h.has_acted()) {
    strat = Tth_strategy();
    get_postflop_strat(h, profile, strat);
  }

  int which_action;
  return get_action2(h, which_action, strat, leader, leader_surrendered, profile->consider_pot_odds);
}

int Tth::get_action(Holdem const & h, Tth_bet_variable const & bv, int leader, bool leader_surrendered)
{
  //  Required commitment to call
  int c = (h.get_committment() + h.to_call())/h.get_raise_this_round();

  //  togo in bets
  int t = h.get_max_bet_this_round()/h.get_raise_this_round();

  //  Are we being asked to call 2 bets at once?
  //  I guess this is what TTH means by 'cold-call 2 bets'
  int cc = h.get_nbetstocall() >= 2;

  //  Am I the leader?
  bool l = (int)h.whose_on() == leader;

  //  max commitment given by the Bet Variable, noting '3' means 'infinity'
  int mc = bv.max_commit <= 2 ? bv.max_commit : 999;

  //  Is it heads-up?
  int hu = h.get_nstillin() == 2;

#define CALL_OR_FOLD (c <= mc ? PLAYER_CALL : PLAYER_FOLD)
#define CHECK_OR_FOLD (h.get_can_check() ? PLAYER_CALL : PLAYER_FOLD)

  switch (bv.style) {
    /*
     *  Simple strategies
     */
  case BV_P_: return CALL_OR_FOLD;
  case BV_b_: if (!l) return CALL_OR_FOLD;
  case BV_B_: return t < 1 ? PLAYER_RAISE : CALL_OR_FOLD;
  case BV_r_: if (!l) return CALL_OR_FOLD;
  case BV_R_: return t < 2 ? PLAYER_RAISE : CALL_OR_FOLD;
  case BV_s_: if (!l) return CALL_OR_FOLD;
  case BV_S_: return t < 3 ? PLAYER_RAISE : CALL_OR_FOLD;
  case BV_a_: if (!l) return CALL_OR_FOLD;
  case BV_A_: return t < 4 ? PLAYER_RAISE : CALL_OR_FOLD;

    /*
     *  X1: If someone bets, fold. If checked to me, bet. If someone raises, fold.
     *  x1: is X1 unless we're not leader, when we check-fold.
     *  X2: If heads up and oppo bets, raise but fold if re-raised, or open and fold if raised.
     *  x2: is X2 or check-fold.
     *  If we're not heads-up I assume we just check-fold.
     *  I think X2 is only used in late position.
     */
  case BV_x1: if (!l) return CHECK_OR_FOLD;
  case BV_X1: return h.get_can_check() ? PLAYER_RAISE : PLAYER_FOLD;
  case BV_x2: if (!l) return CHECK_OR_FOLD;
  case BV_X2: if (!hu) return CHECK_OR_FOLD;
    return t <= 1 ? PLAYER_RAISE : CHECK_OR_FOLD;
    
    /*
     *  CR (smart check-raise) raise back if re-reraised & cap it if we can
     *  CC (smart check-raise) raise back if re-reraised, but don't cap it
     *  CA (always CR) raise back if re-reraised & cap it if we can
     *  CX (always CR) only if heads-up, fold if re-raised.
     *  If not heads up, use check-fold for CX
     */
  case BV_CR: return (h.get_can_check() && check_raise_ok(h, leader, leader_surrendered)) ? PLAYER_CALL : PLAYER_RAISE;
  case BV_CC: return (h.get_can_check() && check_raise_ok(h, leader, leader_surrendered)) ? PLAYER_CALL : 
    (t < 3 ? PLAYER_RAISE : PLAYER_CALL);
  case BV_CA: return h.get_can_check() ? PLAYER_CALL : PLAYER_RAISE;
  case BV_CX: if (!hu) return CHECK_OR_FOLD;
    return h.get_can_check() ? PLAYER_CALL : (t < 2 ? PLAYER_RAISE : PLAYER_FOLD);

    /*
     *  DR (delayed raise) If some-one bets to us and others are to act, call the first time.
     */
  case BV_DR: return (t == 1 && h.get_nunacted() >= 2) ? PLAYER_CALL : PLAYER_RAISE;

    /*
     *  HU: call one bet vs one oppo
     */
  case BV_HU: return hu && t == 1 ? PLAYER_CALL : PLAYER_FOLD;

    /*
     *  PN/BN/RN bn/rn. Play come what may but never call a double raise.
     */
  case BV_PN: return cc ? PLAYER_FOLD : PLAYER_CALL;
  case BV_bn: if (!l) return cc ? PLAYER_FOLD : PLAYER_CALL;
  case BV_BN: return cc ? PLAYER_FOLD : (t < 1 ? PLAYER_RAISE : PLAYER_CALL);
  case BV_rn: if (!l) return cc ? PLAYER_FOLD : PLAYER_CALL;
  case BV_RN: return cc ? PLAYER_FOLD : (t < 2 ? PLAYER_RAISE : PLAYER_CALL);
  }

  assert(!"Unknown bet variable");
  return -1;
}

bool Tth::check_raise_ok(Holdem const & h, int leader, bool leader_surrendered)
{
  /*
   *  If the leader is before us, false.
   *  If we're on the flop, we require the flop to have a high card.
   *  If we're on the turn/river we require the leader to come after us, 
   *  that he didn't surrender last round and the last board card not to match any other board cards.
   */
  assert(leader >= 0);
  assert(h.get_round() >= HOLDEM_FLOP);

  if (h.get_position(leader) >= h.get_position()) {
    if (verbose) REPORT("leader before me so false");
    return false;
  }
  
  Hole hole(h.get_hand(h.whose_on()));
  Card board[5];
  int nseen = h.get_nseen();
  h.get_board(board);
  
  if (h.get_round() == HOLDEM_FLOP) {
    Rank_info ri(board, nseen, hole);
    if (ri.btr >= QUEEN) {
      if (verbose) REPORT("flop has high card so true");
      return true;
    }
    if (verbose) REPORT("flop has no high card so false");
    return false;
  }
  
  if (leader_surrendered) {
    if (verbose) REPORT("leader has surrendered so false");
    return false;
  }

  Rank_info ri(board, nseen-1, hole);
  
  if (ri.counts_board(board[nseen-1].rank()) == 0) {
    if (verbose) REPORT("turn/river looks innocuous so true");
    return true;
  }

  if (verbose) REPORT("turn/river looks scary so false");
  return false;
}

int Tth::consider_pot_odds(Holdem const & h, Tth_strategy const & s, int action)
{
  // ??? why do we ignore pot odds when the game reduces to heads-up
  if (h.get_nactive() == 2)
    return action;

  /*
   *  Reduce action raise->call->fold to get max EV from the draw/draws.
   */
  double p1 = s.flags & TTH_HAVE_STR_DR ? s.str.outs/(50.0 - h.get_nseen())*s.str.pwin : 0.0;
  double p2 = s.flags & TTH_HAVE_FL_DR ? s.fl.outs/(50.0 - h.get_nseen())*s.fl.pwin : 0.0;

  double p = p1 + (1-p1)*p2;

  double EV_call = p*h.get_pot() - (1-p)*h.to_call();
  double EV_raise = p*(h.get_pot() + h.get_raise_this_round()) - (1-p)*h.to_raise();

  if (verbose) REPORT(stringit("Draw p(win): %g %g", p1, p2));
  if (verbose) REPORT(stringit("ptotal %g", p));
  if (verbose) REPORT(stringit("EV_call %g, EV_raise %g", EV_call, EV_raise));

  if (action == 2 && EV_raise < 0)
    action = 1;

  if (action == 1 && EV_call < 0)
    action = 0;

  return action;
}

int Tth::get_preflop_pot_status(const Holdem & h)
{
  if (h.get_big_blind_seat() == h.whose_on()) {

    if (h.get_nbetstocall() < 1) {
      if (verbose) REPORT("Big blind, unraised with callers");
      return 1;
    }

    if (h.get_nbetstocall() == 1) {
      if (verbose) REPORT("Big blind, raised");
      return 4;
    }

    if (verbose) REPORT("Big blind, reraised");
    return 5;
  }

  //  Allow 'blinds only' to cover pots with posts too
  if (h.get_ncalls_this_round() == 0
      && h.get_nraises_this_round() == 0) {
    if (verbose) REPORT("Just the blinds");
    return 0;
  }
  
  if (!h.has_acted(h.whose_on())) {
    if (h.get_ncalls_this_round() >= 1 
	&& h.get_nraises_this_round() == 0) {
      if (verbose) REPORT("Just limpers");
      return 1;
    }
  
    //  small blind doesn't count as a full bet
    if (h.get_nraises_this_round() == 1) {
      if (verbose) REPORT("Raised pot");
      return 2;
    }
    
    if (h.get_nraises_this_round() >= 2) {
      if (verbose) REPORT("Re-raised pot");
      return 3;
    }
  }

  assert(h.has_acted(h.whose_on()));
  
  if (h.get_nbetstocall() <= 1) {
    if (verbose) REPORT("Raised back");
    return 4;
  }
  
  if (verbose) REPORT("Re-raised back");
  return 5;
}

int Tth::get_preflop_position(Holdem const & h)
{
  if (h.get_small_blind_seat() == h.whose_on()) {
    if (verbose) REPORT("Small blind");
    return SmB;
  }
  
  if (h.get_big_blind_seat() == h.whose_on()) {
    if (verbose) REPORT("Big blind");
    return BgB;
  }

  if ((1+h.get_big_blind_seat()) % h.get_nplayers() == h.whose_on()) {
    if (verbose) REPORT("Under the gun");
    return UnG;
  }

  if (h.get_dealer() == h.whose_on()) {
    if (verbose) REPORT("Button");
    return But;
  }

  int p = h.get_position()-1;
  assert(p >= 0);

  int q = p/2;
  assert(q < 3);
  
  if (q == 0) {
    if (verbose) REPORT("Late");
    return Lat;
  }

  if (q == 1) {
    if (verbose) REPORT("Mid");
    return Mid;
  }

  if (verbose) REPORT("Early");
  return Ear;
}

int Tth::get_postflop_position(Holdem const & h)
{
  int nunacted = h.get_nunacted();
  int nactive  = h.get_nactive();
  int nacted   = nactive-nunacted;

  if (nunacted == nactive)
    return postflop_First;

  assert(nacted >= 1);

  if (nunacted == 1)
    return postflop_Last;

  if (h.to_call() == 0) {
    if (nacted == 1 && nactive < 5)
      return postflop_Mid;
    if (nacted == 2 && nactive >= 5 &&  nactive <= 8)
      return postflop_Mid;
    if (nacted == 3 && nactive > 8)
      return postflop_Mid;

    return postflop_First;
  }
  
  return postflop_Mid;
}

void Tth::start_game(Holdem const & h, int seat)
{
  leader = -1;
}

void Tth::pre_update(Holdem const & h, int who, int action)
{
  if (leader == (int)who)
    if (action == 0) {  // FIXME want action != 2 && h.get_can_raise()
      if (verbose) REPORT("leader surrenders");
      leader_surrendered = true;
    }
  
  if (action == 2
      || (leader == -1 && action == 1)) {
    leader = who;
    if (verbose) REPORT(stringit("leader now %i", leader));
  }
}

void Tth::do_quads(Tth_strategy & strat, Card board[5], int ncards, Hole hole, int noppo)
{
  strat.made.htype = 0;
  strat.made.desc = "Quads";
      
  if (hole.toprank() == ACE) {
    strat.made.bv = Tth_bet_variable::make("A3");
    return;
  }
  
  Rank_info ri(board, ncards, hole);

  int toc = ri.top_odd_card();
  int r = (ri.htr > toc ? ri.htr : toc);
  double p = pow(r/(double)ACE, 2*noppo);
  
  if (p >= 0.5 && r > toc)
    strat.made.bv = Tth_bet_variable::make("P3");
  else
    strat.made.bv = Tth_bet_variable::make("P1");

  return;
}

/*
 *  Returns number of cards occuring in each suit and return a
 *  permutation order[] s.t. present[order[i]] is non-decreasing in i.
 *  topabsent[i] is the rank of the highest card of the suit not on the board.
 */
void Tth::flush_threats(Card board[5], int ncards, int present[4], int order[4], int topabsent[4], int present2[4][13])
{
  assert(ncards <= 5);
  int i;

  memset(present, 0, 4*sizeof(int));
  memset(present2, 0, 4*13*sizeof(int));

  for (i=0; i<ncards; i++) {
    present[board[i].suit()]++;
    present2[board[i].suit()][board[i].rank()] = 1;
  }

  for (i=0; i<4; i++)
    order[i] = i;
  
  sort(order, order+4, compare<int>(present));

  for (i=0; i<4; i++)
    for (int j=12; j>=0; j--)
      if (!present2[i][j]) {
	topabsent[i] = j;
	break;
      }
}

void Tth::do_flushes(Card board[5], int ncards, Hole hole, Flush_info* fi, int round, Tth_profile const * p)
{
  int present2[4][13];
  int topabsent[4];
  
  assert(ncards <= 5);

  for (int i=0; i<4; i++)
    fi->suits[i] = 0;

  fi->suits[hole.card(0).suit()]++;
  fi->suits[hole.card(1).suit()]++;

  flush_threats(board, ncards, fi->present, fi->order, topabsent, present2);

  //  for (int i=0; i<4; i++)
  //    printf("suit %i present %i topabsent %i\n", i, fi->present[i], topabsent[i]);

  //  NB we can only have a made flush or flush draw in one suit
  int htr = hole.toprank();
  for (int s=0; s<4; s++)
    if ((fi->present[s] == 3 && fi->suits[s] == 1) // case 12 or 13
	|| (fi->present[s] == 2 && fi->suits[s] == 2)) { // case 14 or 16
      
      fi->rank = 0;
      for (int k = 12; k != htr; k--) 
	if (!present2[s][k]) {
	  fi->rank++;
	}

      //  check draw is good enough
      if ((fi->suits[s] == 1 && fi->rank > A - p->flush_w1_draw_thresh[round])
	  || (fi->suits[s] == 2 && fi->rank > A - p->flush_w2_draw_thresh[round]))
	continue;

      fi->suit = s;

      // 12 and 14 are the nut draws (when rank == 0)
      fi->info = (fi->suits[s] == 1 ? 12 : 14);
      if (fi->rank)
	fi->info++;

    } else if (fi->present[s] + fi->suits[s] >= 5) {
      fi->rank = 0;
      for (int k = 12; k != htr; k--) 
	if (!present2[s][k]) {
	  fi->rank++;
	}

      //  check made flush is good enough.
      if ((fi->present[s] + fi->suits[s] == 5
	   && (fi->suits[s] == 1 && fi->rank > A - p->flush_w1_made_thresh[round])
	   || (fi->suits[s] == 2 && fi->rank > A - p->flush_w2_made_thresh[round]))
	  
	  //  This occurs when we have a made flush and another flush card appears on the board
	  || (fi->present[s] + fi->suits[s] >= 6
	      && fi->rank > A - p->flush_4card_thresh[round]))
	continue;

      fi->suit = s;
      fi->made = true;
    }
}

void Tth::do_straights(Card board[5], int ncards, Hole hole, Straight_info* strinfo)
{
  int hole_ranks[2] = { hole.card(0).rank(), hole.card(1).rank() };
  do_straights(board, ncards, hole_ranks, strinfo);
}

/*
 *  This routine ignores all suits involved.
 */
void Tth::do_straights(Card board[5], int ncards, int hole_ranks[2], Straight_info* strinfo)
{
  assert(ncards <= 5);
  int i;

  bool made = false;

  //  These deal with straights/straight draws involving our hole cards
  int gap0 = 0;  //  number of cards in a made straight with 0 gaps
  int gap1 = 0;  //  number of cards in a made straight with 1 gap
  int hole0 = 0; //  number of hole cards used in the former
  int hole1 = 0; //  number of hole cards used in the latter

  //  Number of cards to a makeable straight given 0/1/2/3 extra cards
  int nut[4];
  nut[0] = nut[1] = nut[2] = nut[3] = 0;

  int nut_made = -1;
  int nut_draw = -1;
  int nut_made1 = -1;
  int made_rank = -1;

  int r1 = hole_ranks[0];
  int r2 = hole_ranks[1];

  /*
   *  We classify straight draws using 1 hole card into 3:
   *  1-way for which the resulting straight is the nuts ('top end')
   *  2-way for which one of the ways is top end (K9 876)
   *  2-way for which neither is top end (K6 987)
   */
  int hole1_nways = 0; // number of ways to form straight using 1 hole card & one draw
  int hole1_best = -1; // rank of best resulting straight

  /*
   *  Straight draws using 2 hole cards can be: 1/2 way.
   *  In the 1-way case, we want to know if one (or either)
   *  of the draws is to the best straight available with up to 3 cards.
   */
  int hole2_nways = 0; // number of ways to form straight using 2 hole card & one draw
  int hole2_best = -1; // rank of best resulting straight

  int present[13];
  for (i=0; i<13; i++)
    present[i] = 0;

  for (i=0; i<ncards; i++) 
    present[board[i].rank()]++;

  if (present[ACE]) {
    gap0 = 1;
    nut[0] = nut[1] = nut[2] = nut[3] = 1;
  } else {
    nut[3] = nut[2] = nut[1] = 1;
    if (r1 == ACE || r2 == ACE) {
      gap0 = 1;
      hole0 = 1;
    } else
      gap1 = 1;
  }

  for (int r=0; r<13; r++) {
    bool gap_incl_hole = false;
    bool gap = false;

    if (present[r]) {
      gap0++;
      gap1++;
      nut[0]++;
      nut[1]++;
      nut[2]++;
      nut[3]++;
    } else if (r1 == r || r2 == r) {
      gap0++;
      gap1++;
      hole0++;
      hole1++;
      gap = true;
    } else {
      gap = true;
      gap_incl_hole = true;
    }

    if (gap) {
      nut[3] = nut[2]+1;
      nut[2] = nut[1]+1;
      nut[1] = nut[0]+1;
      nut[0] = 0;
    }

    if (gap_incl_hole) {
      gap1 = gap0+1;
      hole1 = hole0;
      gap0 = 0;
      hole0 = 0;
    } 
    
    //    printf("r=%i gap=%i gap0=%i hole0=%i gap1=%i hole1=%i nut0=%i nut1=%i nut2=%i\n",
    //    	   r, gap, gap0, hole0, gap1, hole1, nut[0], nut[1], nut[2]);
    
    if (nut[3] >= 5)
      nut_draw = r;

    if (nut[2] >= 5)
      nut_made = r;

    if (nut[1] >= 5)
      nut_made1 = r;

    if (nut[0] >= 3)
      strinfo->three_str = true;

    if (nut[0] >= 4)
      strinfo->four_str = true;

    if (gap0 >= 5) {
      if (hole0 == 0) {
	//	printf("Board is made straight (%i)\n", r);
	made = true;
	made_rank = r;
      } else if (hole0 == 1) {
	//	printf("Made straight (%i) with one hole card\n", r);
	made = true;
	made_rank = r;
      } else if (hole0 == 2) {
	//	printf("Made straight (%i) with two hole cards\n", r);
	made = true;
	made_rank = r;
      }
    } else {
      if (gap1 >= 5) {
	if (hole1 == 0)
	  //	  printf("Board has 4 straight we can't fill\n");
	  ;
	
	else if (hole1 == 1) {
	  //	  printf("Straight (%i) draw with 1 hole card\n", r);
	  hole1_nways++;
	  hole1_best = r;

	  //  musn't allow the same draw for again (QJ AK9 counts KQJT9 and AKQJT)
	  gap1 = gap0;
	  
	} else if (hole1 == 2) {
	  //	  printf("Straight (%i) draw with 2 hole cards\n", r);
	  hole2_nways++;
	  hole2_best = r;
	  gap1 = gap0;
	}
      }
    }
  }

#if 0
  printf("Board: ");
  for (int i=0; i<ncards; i++)
    printf("%s ", board[i].to_str());
  printf("\nHole = %s\n", hole.to_str());

  printf("nut_made_rank %i nut_draw_rank %i\n", nut_made, nut_draw);
  printf("hole1_nways = %i hole1_best = %i\n", hole1_nways, hole1_best);
  printf("hole2_nways = %i hole2_best = %i\n", hole2_nways, hole2_best);  
#endif

  strinfo->made = made;
  strinfo->made_rank = made_rank;
  strinfo->nut_draw = nut_draw;
  strinfo->nut_made = nut_made;
  strinfo->nut_made1 = nut_made1;

  strinfo->info = 0;

  int nways_total = hole1_nways + hole2_nways;

  if (nways_total == 1) {
    if (hole1_nways == 1) {
      if (hole1_best == nut_made)
	strinfo->info = 1;
      else
	strinfo->info = 18;
    } else {
      if (hole2_best < nut_draw)
	strinfo->info = 2;
      else
	strinfo->info = 3;
    }
  }
  
  if (nways_total == 2) {
    if (hole2_nways == 0) {
      if (hole1_best == nut_made)
	strinfo->info = 5;
      else
	strinfo->info = 4;
    } else {
      if (hole2_best == nut_draw)
	strinfo->info = 7;
      else
	strinfo->info = 6;
    }
  }

  strinfo->our_rank = -1;
  if (hole1_best > strinfo->our_rank)
    strinfo->our_rank = hole1_best;
  if (hole2_best > strinfo->our_rank)
    strinfo->our_rank = hole2_best;
  }

void Tth::do_strflushes(Card board[5], int ncards, Hole hole, Strflush_info* sfi, Flush_info const * fi)
{
  assert(ncards <= 5);

  //  We can only have a flush draw to one suit.
  //  We're interested in setting up the si field for made straight flushes too
  if (fi->info == 0 && !fi->made)
    return;

  int suit = fi->suit;
  sfi->suit = suit;

  Card brd[5];
  int cnt = 0;

  for (int i=0; i<ncards; i++)
    if (board[i].suit() == suit) {
      brd[cnt] = board[i];
      cnt++;
    }

  int hole_ranks[2] = { (hole.card(0).suit() == suit ? hole.card(0).rank() : -1),
			(hole.card(1).suit() == suit ? hole.card(1).rank() : -1) };

  do_straights(brd, cnt, hole_ranks, &sfi->si);

  //  rest of this only concerns draws
  if (fi->made)
    return;

  /*
   *  I think TTH requires the straight draw to be 2-way (o/w we treat
   *  the hand as having independent straight and flush draws (which
   *  over counts the number of outs by 1).  I guess the straight draw
   *  won't be worth much anyway.  
   */
  switch (sfi->si.info) {
  case 0: case 18: case 1: case 2: case 3:
    break;
  case 4: case 5: 
    sfi->info = 19;
    break;
  case 6: case 7:
    sfi->info = 20;
    break;
  }
}

const char* Tth::nopair_str(int i)
{
  switch (i) {
    //  str draws
  case 1: return "1. An inside str draw w/1 card to top end-str (Q9 865)";
  case 2: return "2. An inside str draw w/2 card to mediocre str (65 Q98)";
  case 3: return "3. An inside str draw w/2 cards to a nut str (98 A65 or 86 A95)";
  case 4: return "4. A 2-way str draw w/1 card to a mediocre str (K6 987)";
  case 5: return "5. A 2-way str draw w/1 card to a top-end str (K9 876)";
  case 6: return "6. A 2-way str draw w/2 cards to a mediocre str (76 K98 or 42 865)";
  case 7: return "7. A 2-way str draw w/2 cards to a nut str (98 K76 or QJ AT8)";
  case 8: return "8. A 2-way str draw w/2 cards vs a 2-card flush (86 K97 w97s)";
  case 9: return "9. A str draw not 2-way w/2 cards vs a 2-card flush (K9 876 w76s)";
  case 10: return "10. A 2-way str draw w/2 cards vs a 3/4-card flush (98 K76 wK76s)";
  case 11: return "11. A str draw, not 2-way w/2 card vs a 3/4-card flush (K9 876 w876s)";
  case 18: return "18. An inside str draw w/1 card to a mediocre str (Q5 986)";

    //  flush draws
  case 12: return "12. A flush draw w/1 card, w/A (A9 J76 wAJ76s)";
  case 13: return "13. A flush draw w/1 card, wo/A (K9 J76 wKJ76s)";
  case 14: return "14. A flush draw w/2 cards, w/A (A9 J76 wA9J7s)";
  case 15: return "15. A flush draw w/2 cards, wo/A (K9 J76 wK976s)";
  case 16: return "16. A flush draw w/A vs a 3/4 str (A9 654)";
  case 17: return "17. A flush draw wo/A vs a 3/4 str (75 KJT)";

    //  strflush draws
  case 19: return "19. A str flush draw w/1 card (K6 987 w6987s)";
  case 20: return "20. A str flush draw w/2 cards (76 983 w7698s)";

    //  made hands
  case 21: return "21. 2 major overcards (AK, AQ, AJ or KQ)";
  case 22: return "22. 2 minor overcards w/rags on the board (Q9 863)";
  case 23: return "23. Ace overcard w/rags on the board (A8 963)";
  case 24: return "24  2 major overcards (AK, AQ, AJ or KQ) vs 3-str or 3-flush (AJ 986 w/986s)";
  case 25: return "25. 2 minor overcards or Ace overcard vs 3-str (K9 864)";
  case 26: return "26. Nothing (J8 T53 or J8 AK7)";

  case 27: return "27. A pair, not top pair w/kicker lower than board (J8 QJ4)";
  case 28: return "28. A pair, not top pair w/kicker higher than board (KJ QJ4)";
  case 29: return "29. A pair, not top pair vs a 3-str or flush (AJ QJ9)";
  case 30: return "30. A pair, not top pair vs a 4-str or flush (84 9876)";

  case 31: return "31. Top pair, Js or lower w/J or lower kicker (J8 J94)";
  case 32: return "32. Top pair, Js or lower w/Q or higher kicker (KJ J94)";
  case 33: return "33. Top pair, Qs or Ks w/J or lower kicker (Q8 Q94)";
  case 34: return "34. Top pair, Qs or Ks w/Q or higher kicker (KQ Q93)";
  case 35: return "35. Top pair, As w/9 or lower kicker (A8 A93)";
  case 36: return "36. Top pair, As w/T or J kicker (AJ A94)";
  case 37: return "37. Top pair, As w/Q or K kicker (AQ A94)";
  case 38: return "38. Top pair, w/poor kicker vs 3-card str or flush (K8 KQJ)";
  case 39: return "39. Top pair, w/better kicker vs 3-card str or flush (K9 986)";
  case 40: return "40. Top pair vs 4-card str or flush (AJ JT97)";

  case 41: return "41. Pocket overpair, As or Ks (KK Q85)";
  case 42: return "42. Pocket overpair, Ts, Js or Qs (JJ 974)";
  case 43: return "43. Pocket overpair lower than Ts (99 873)";
  case 44: return "44. Pocket overpair vs 3-str or flush (KK J98)";
  case 45: return "45. Pocket overpair vs 4-str or flush (QQ 8764)";
  case 46: return "46. Pocket underpair lower than 1 board overcard (99 K75)";
  case 47: return "47. Pocket underpair lower than 2+ board overcards (99 KQ5)";
  case 48: return "48. Pocket underpair vs 3-card str or flush (88 KQJ)";
  case 49: return "49. Pocket underpair vs 4-str or flush (88 KQJ9)";

  case 50: return "50. 2 pair not including top pair (J6 QJ6)";
  case 51: return "51. 2 pair, top pair and other pair (J3 J63)";
  case 52: return "52. 2 pair vs 3-card str or flush (J9 JT9)";
  case 53: return "53. 2 pair vs 4-card str of flush (J9 QJT9)";

  case 54: return "54. Set (77 QJ7)";
  case 55: return "55. Set vs 3-card str or flush (77 876)";
  case 56: return "56. Set vs 4-card str or flush (77 9876)";

  case 57: return "57. Non-nut straight or flush (84 756)";
  case 58: return "58. Nut straight, nut flush or any straight flush (98 765)";
  case 59: return "59. str vs 3-card flush (76 T98 w/T98s)";
  case 60: return "60. str vs 4-card flush (K8 9765 w/9765s)";
  }
  return "Unknown";
}

const char* Tth::onepair_str(int i)
{
  switch (i) {
    //  str draws
  case 1: return "1. An inside straight draw w/2 cards (98 655 or 65 988)";
  case 33: return "33. A straight draw w/1 card (K8 6554 or K9 8776)";
  case 2: return "2. A 2-way straight draw w/2 cards (98 776)";

    //  ??? str draw with 1 card vs 2 card flush
  case 3: return "3. A straight draw w/2 cards vs a flopped 2-card flush (98 776 or T9 776)";
  case 34: return "34. A straight draw w/1 card vs a 3-card flush (K8 6554 or K9 8776)";
  case 4: return "4. A straight draw w/2 cards vs a 3-card flush (98 7763 or T9 7763 w/763 suited)";

    //  flush draws
  case 5: return "5. A flush draw with an A (A9 J776 w/AJ76 suited)";
  case 6: return "6. A flush draw without an A (Q9 J776 w/QJ76 suited)";

    //  strflush draws
  case 7: return "7. A straight flush draw w/1 card (K6 9877)";
  case 8: return "8. A straight flush draw w/2 cards (76 988)";

    //  Made hands
  case 9: return "9. 2 major overcards (AK AQ AJ or KQ) w/rags on the board (AJ 9962)";
  case 10: return "10. 2 minor overcards w/rags on the board (Q9 8862)";
  case 11: return "11. Ace overcard w/rags on the board (A4 8873)";
  case 12: return "12. 2 major overcards (AK AQ AJ of KQ) vs 3-str or 3-flush (AJ 9986)";
  case 13: return "13. 2 minor overcards or Ace overcard vs 3-str (K9 8664)";

  case 14: return "14. 2 pair, pocket J's or better, no higher odd cards on board (JJ QQ9)";
  case 15: return "15. 2 pair, pocket T's or lower no higher odd cards on board (TT QQ9)";
  case 16: return "16. 2 pair, any pocket pair, 1 higher odd card on board (JJ KKQ or JJ KKQ2)";
  case 17: return "17. 2 pair, any pocket pair, 2 + higher odd cards on boad (66 QQJ7)";

  case 18: return "18. 2 pair, match top odd card on board, plus A or K kicker (A9 QQ9 or A9 QQ92)";
  case 19: return "19. 2 pair, match top odd card on board, no  A or K kicker (97 QQ9 or 97 QQ94)";
  case 20: return "20. 2 pair, match other than top odd card on board, any kicker (Q4 9974)";
  case 21: return "21. Better 2 pair vs 3,4-card straight or flush (TT QQ92 or A9 QQ92 or 97 QQ94)";
  case 22: return "22. Lesser 2 pair vs 3,4-card straight or flush (JJ KKQ2 or 66 QQJ7 or Q4 9974)";

  case 23: return "23. Trips w/weak kicker (7? 77Q)";
  case 24: return "24. Trips w/strong kicker (7? 77Q)";
  case 25: return "25. Trips vs 3-card straight or flush (K7 9877)";
  case 26: return "26. Trips vs 4-card straight or flush (K7 98776)";

  case 27: return "27. Non-nut straight or flush (84 7765)";
  case 28: return "28. Nut straight or flush (98 7765)";
  case 29: return "29. A straight vs a 3-card flush (98 T776 w/9765 suited)";
  case 30: return "30. A straight vs a 4-card flush (K8 99765 w/9765 suited)";
  case 31: return "31. Full house, other than top full house (KQ KQQ)";
  case 32: return "32. Top full house or better (KK KQQ or K9 KK9 or 44 443)";

  case 35: return "35. Nothing in the pocket (J8 993)";
  }
  return "Unknown";
}

const char* Tth::twopair_str(int i)
{
  switch (i) {
    //  draws
  case 1: return "1. A 2-way straight draw or a non-nut flush draw (98 7676)";
  case 2: return "2. A flush draw with an A (A9 7676)";
  case 3: return "3. A straight flush draw (76 9898)";

  case 4: return "4. Ace w/kicker higher than lower pair (A8 7755 or AJ 9933)";
  case 5: return "5. Ace w/kicker lower than lower pair (A6 QQ77)";
  case 6: return "6. King w/kicker higher than lower pair (KJ AA77 or KJ 9966)";
  case 7: return "7. Pocket overpair (JJ 9966) or match board overcard (KQ Q9966)";
  case 8: return "8. Pocket middle pair (88 9966) or match board middle card (QJ KK66Q)";
  case 9: return "9. Pocket underpair (55 9966)";

  case 10: return "10. A straight or flush (QJ AKTAK)";
  case 11: return "11. Full house, other than top full (QJ QQKK)";
  case 12: return "12. Top full house (QJ QQ99)";
  case 13: return "13. Over full house (KK QQ99K)";
  case 14: return "14. Four of a kind of better (44 4455)";

  case 15: return "15. Nothing (J8 9966 or K3 9966)";
  }
  return "Unknown";
}

const char* Tth::trips_str(int i)
{
  switch (i) {
    //  draws
  case 1: return "1. A 2-way straight draw or a non-nut flush draw (98 7677)";
  case 2: return "2. A flush draw with an A (A9 7677)";
  case 3: return "3. A straight flush draw (76 9899)";

  case 4: return "4. Big cards: AK, AQ, AJ, AT or KQ both higher than odd card(s) (AQ JKKK3)";
  case 5: return "5. Ace overcard (A9 JJJ2 or A2 KKK9)";
  case 6: return "6. 2 cards, 9 high or better, both higher than odd card(s) (QJ KKK8)";

  case 7: return "7. A straight or flush (QJ AKTAA)";
  case 8: return "8. Full house w/pocket Q's or better, no higher odd card(s) on board";
  case 9: return "9. Full house w/pocket 9's thru J's, no higher odd card(s) on board (99 JJJ8)";
  case 10: return "10. Full house w/pocket 2's thru 8's, no higher odd cards on board (66 7775)";
  case 11: return "11. Full house w/any pocket but higher odd card(s) on board (QQ 777K)";

  case 12: return "12. Full house w/match of high odd card on the board (KQ 777Q or KQ 777Q6)";
  case 13: return "13. Full house w/match of low odd card on the board (K6 7776Q)";
  case 14: return "14. Over full house, four of a kind or better (JJ J999 A9 J999)";

  case 15: return "15. Nothing (J8 999)";
  }
  return "Unknown";
}

Rank_info::Rank_info(Card board[5], int ncards, Hole hole)
{
  memset(rank_counts, 0, 13*sizeof(int));
  memset(rank_counts2, 0, 13*sizeof(int));
  pairs = trips = quads = 0;

  btr = board[0].rank();
  blr = board[0].rank();
  htr = hole.toprank();
  hlr = hole.lorank();
  pocketpair = hole.paired();
  n_board_ov = 0;
  n_board_ov2 = 0;
  pairrank = -1;
  tripsrank = -1;
  
  topoddboard = -1;

  rank_counts[hole.card(0).rank()]++;
  rank_counts[hole.card(1).rank()]++;

  if (pocketpair) {
    pairs++;
    pairrank = htr;
  }

  for (int i=0; i<ncards; i++) {
    rank_counts[board[i].rank()]++;
    rank_counts2[board[i].rank()]++;

    if (board[i].rank() > btr)
      btr = board[i].rank();

    if (board[i].rank() < blr)
      blr = board[i].rank();

    if (board[i].rank() > htr)
      n_board_ov++;

    if (board[i].rank() > hlr)
      n_board_ov2++;

    if (rank_counts[board[i].rank()] == 2) {
      pairs++;
      if (board[i].rank() > pairrank)
	pairrank = board[i].rank();
    } else if (rank_counts[board[i].rank()] == 3) {
      trips++;
      pairs--;
      if (board[i].rank() > tripsrank)
	tripsrank = board[i].rank();
    } else if (rank_counts[board[i].rank()] == 4) {
      quads++;
      trips--;
    }
  }
}

int Tth::nopair_made_type(Card board[5], int ncards, Hole hole, 
			  Strflush_info const & sfi,
			  Straight_info const & si,
			  Flush_info const & fi,
			  Rank_info const & ri)
{
  //  The board must really have no pair on it.

  //  Do big hands first: straight, flush or strflush
  if (sfi.made() || fi.made_nuts())
    return 58; // "Nut straight, nut flush or any straight flush (98 765)";
  
  if (fi.made)
    return 57; // "Non-nut straight or flush (84 756)"

  //  If we have a made straight, it may be threatened.
  //  We don't worry if we have any cards in the flush suit, it's still 
  //  considered a threatened straight.
  if (si.made) {
    if (fi.max() == 4)
      return 60; // "str vs 4-card flush (K8 9765 w/9765s)"
    if (fi.max() == 3)
      return 59; // "str vs 3-card flush (76 T98 w/T98s)"
    if (si.made_nuts())
      return 58; // "Nut straight, nut flush or any straight flush (98 765)";

    return 57; // "Non-nut straight or flush (84 756)"
  }

  //  Sets
  if (ri.trips) {
    if (fi.max() == 4 || si.nut_made1 >= 0)
      return 56; // "Set vs 4-card str or flush (77 9876)"
    if (fi.max() == 3 || si.nut_made >= 0)
      return 55; // "Set vs 3-card str or flush (77 876)"
    return 54;
  }

  //  Two pair
  if (ri.pairs == 2) {
    if (fi.max() == 4 || si.nut_made1 >= 0)
      return 53; // "2 pair vs 4-card str of flush (J9 QJT9)"
    if (fi.max() == 3 || si.nut_made >= 0)
      return 52; // "2 pair vs 3-card str or flush (J9 JT9)"
    if (ri.htr < ri.btr)
      return 50; // "2 pair not including top pair (J6 QJ6)"
    
    return 51; // "2 pair, top pair and other pair (J3 J63)"
  }

  //  Pairs: Pocket, Top and other
  if (ri.pairs == 1) {
    if (ri.pocketpair) {
      if (ri.htr > ri.btr) {
	//  pocket overpair
	if (fi.max() == 4 || si.nut_made1 >= 0)
	  return 45; // "Pocket overpair vs 4-str or flush (QQ 8764)";
	if (fi.max() == 3 || si.nut_made >= 0)
	  return 44; // "Pocket overpair vs 3-str or flush (KK J98)"

	if (ri.htr >= KING)
	  return 41; // "Pocket overpair, As or Ks (KK Q85)"
	if (ri.htr >= TEN)
	  return 42; // "Pocket overpair, Ts, Js or Qs (JJ 974)"

	return 43; // "Pocket overpair lower than Ts (99 873)"
      }
      
      //  pocket underpair
      if (fi.max() == 4 || si.nut_made1 >= 0)
	return 49; // "Pocket underpair vs 4-str or flush (88 KQJ9)"
      if (fi.max() == 3 || si.nut_made >= 0)
	return 48; // "Pocket underpair vs 3-card str of flush (88 KQJ)"

      //  case 46/47: is our pocket pair higher than 0 or 1 board cards?
      if (ri.n_board_ov == 1)
	return 46; // "Pocket underpair lower than 1 board overcard (99 K75)"
      return 47; // "Pocket underpair lower than 2+ board overcards (99 KQ5)"
    }

    if (ri.pairrank == ri.btr) {
      //  Top pair
      if (fi.max() == 4 || si.nut_made1 >= 0)
	return 40; // "Top pair vs 4-card str or flush (AJ JT97)"
      if (fi.max() == 3 || si.nut_made >= 0) {
	if (ri.htr > ri.btr)
	  return 39; // "Top pair, w/better kicker vs 3-card str or flush (K9 986)"
	return 38; // "Top pair, w/poor kicker vs 3-card str or flush (K8 KQJ)"
      }
      
      if (ri.pairrank == ACE) {
	if (ri.hlr <= NINE)
	  return 35; // "Top pair, As w/9 or lower kicker (A8 A93)"
	if (ri.hlr <= JACK)
	  return 36; // "Top pair, As w/T or J kicker (AJ A94)"
	return 37; // "Top pair, As w/Q or K kicker (AQ A94)"
      }

      if (ri.pairrank >= QUEEN) {
	if (ri.hlr <= JACK)
	  return 33; // "Top pair, Qs or Ks w/J or lower kicker (Q8 Q94)"
	return 34; // "Top pair, Qs or Ks w/Q or higher kicker (KQ Q93)"
      }

      if (ri.htr+ri.hlr-ri.pairrank >= QUEEN)
	return 32; // "Top pair, Js or lower w/Q or higher kicker (KJ J94)"
      return 31; // "Top pair, Js or lower w/J or lower kicker (J8 J94)"
    }

    //  Some other pair, not pocket or top
    if (fi.max() == 4 || si.nut_made1 >= 0)
      return 30; // "A pair, not top pair vs a 4-str or flush (84 9876)"
    if (fi.max() == 3 || si.nut_made >= 0)
      return 29; // "A pair, not top pair vs a 3-str or flush (AJ QJ9)"

    if (ri.htr+ri.hlr-ri.pairrank > ri.btr)
      return 28; // "A pair, not top pair w/kicker higher than board (KJ QJ4)"

    return 27; // "A pair, not top pair w/kicker lower than board (J8 QJ4)"
  }

  //  Less than a pair
  if (ri.hlr > ri.btr) {
    // two overcards
    bool major_overcards = ((ri.htr == ACE && ri.hlr >= JACK)
			    || (ri.htr == KING && ri.hlr == QUEEN));
    
    if (major_overcards) {
      if (fi.max() == 3 || si.nut_made >= 0)
	return 24; // "2 major overcards (AK, AQ, AJ or KQ) vs 3-str or 3-flush (AJ 986 w/986s)"
      return 21; // "2 major overcards (AK, AQ, AJ or KQ)"
    }

    if (si.nut_made >= 0)
      return 25; // "2 minor overcards or Ace overcard vs 3-str (K9 864)"
   
    if (ri.htr == ACE && ri.btr <= NINE)
      return 23; // "Ace overcard w/rags on the board (A8 963)"
    
    /*
     *  22 is "2 minor overcards w/rags on the board (Q9 863)"
     *  26 is "Nothing (J8 T53 or J8 AK7)"
     *  What about KJ T64 - is this 22 or 26 - I think 22 (i.e. is T a rag here)?
     */
    if (ri.btr <= NINE)
      return 22; // "2 minor overcards w/rags on the board (Q9 863)";
  }
  
  if (ri.htr == ACE && si.nut_made >= 0)
    return 25; // "2 minor overcards or Ace overcard vs 3-str (K9 864)"
  
  if (ri.htr == ACE && ri.btr <= NINE)
    return 23; // "Ace overcard w/rags on the board (A8 963)"

  return 26; // "Nothing (J8 T53 or J8 AK7)"
}

Threat_info::Threat_info(Flush_info const & fi, 
			 Straight_info const & si, 
			 int noppo, 
			 int ncards)
{
  //  P(some oppo has 2 or 1 card in a specified suit) (approx)
  psomeoppohas2 = 1 - pow(1-1/16.0, noppo);
  psomeoppohas1 = pow(1/4.0, 2*noppo); 
  
  /*
   *  There can be 0 (hcd), 1 (hhh) or two flush threats (hhdd)
   *  If we don't have a draw to any of the threatened suits, 
   *  we're in bad shape.
   */
  int s = fi.order[3];
  int sp = fi.order[2];
  
  //  Number of cards in worst threat
  threat = 0;
  
  if (!fi.info || fi.suit != s)
    threat = fi.present[s];
  else 
    /*
     *   We have a draw to the most populus suit so check the next
     *   most populus one.  (We can only have a draw to one suit so
     *   we cant't have a draw to this other suit too.)
     */
    if (!fi.info || fi.suit != sp)
      threat = fi.present[sp];

  if (threat < 2)
    return;

  p2_1 = 1/4.0 * psomeoppohas2;
  p3_1 = 1/4.0 * psomeoppohas1 + 3/4.0 * psomeoppohas2;
  p4_1 = 1/4.0 * 1./noppo + 3/4.0 * psomeoppohas1;
  p2_2 = 1/4.0 * p3_1 + 3/4.0 * p2_1;
  p3_2 = 1/4.0 * p4_1 + 3/4.0 * p3_1;
  pflushhits_and_we_lose = (threat == 2 ? 
			    (ncards == 3 ? p2_2 :
			     ncards == 4 ? p2_1 : 0) :
			    threat == 3 ? 
			    (ncards == 3 ? p3_2 :
			     ncards == 4 ? p3_1 : psomeoppohas2) :
			    threat == 4 ? 
			    (ncards == 4 ? p4_1 : psomeoppohas1) : 0);
}

#define DO_STR_DRAW(x, threatened) \
do { \
strdraw_type = x; \
strat.str.outs = si.nways()*4; \
strat.str.pwin = ((threatened) ? 1 - ti.pflushhits_and_we_lose : 1.0)*si.pwin(noppo); \
strat.flags |= TTH_HAVE_STR_DR; \
} while (0)

void Tth::do_nopair(Tth_strategy & strat, Card board[5], int ncards, Hole hole,
		    int round, int pos, int noppo, Tth_profile const * p)
{
  int strflushdraw_type = 0;
  int strdraw_type = 0;
  int flushdraw_type = 0;
  int made_type = 0;

  assert(ncards >= 3 && ncards <= 5);

  Straight_info si;
  Flush_info    fi;
  Strflush_info sfi;

  do_straights(board, ncards, hole, &si);
  do_flushes(board, ncards, hole, &fi, round, p);
  do_strflushes(board, ncards, hole, &sfi, &fi);
  
  /*
   *  Sort out the Tth_bet_variable for our strflush/flush/straight draw,
   *  If we have a strflush draw, get the Betv for that.
   *  o/w look for a threatened straight draw or normal straight draw
   *  then the flush draw in turn an max them
   *  If we have a draw, compute number of outs and P(win|we make the draw).
   */
  if (ncards < 5) {
    /* 
     *  Straight-flush draws: #19 and #20
     */
    if (sfi.info) {
      strflushdraw_type = sfi.info;
      strat.str.outs = 15;
      strat.str.pwin = 1.0;
      strat.flags |= TTH_HAVE_STR_DR;

    } else {

      struct Threat_info ti(fi, si, noppo, ncards);

      if (ti.threat >= 2) {
	/*
	 *  #8 2-way, 2-hole str draw vs 2 flush
	 *  #9 not(2-way, 2-hole) str draw vs 2 flush
	 */
	if (verbose) REPORT(stringit("P(flush hits and we lose) = %g", ti.pflushhits_and_we_lose));

	if (ti.threat == 2) {
	  if (si.info == 6 || si.info == 7)
	    DO_STR_DRAW(8, true);
	  else if (si.info)
	    DO_STR_DRAW(9, true);
	  
	  /*
	   *  #10 2-way, 2-hole str draw vs 3/4 flush
	   *  #11 not(2-way, 2-hole) str draw vs 3/4 flush
	   */
	} else {
	  if (si.info == 6 || si.info == 7)
	    DO_STR_DRAW(10, true);
	  else if (si.info)
	    DO_STR_DRAW(11, true);
	}
      } else {
	/*
	 *  No flush threat to our straight draw, use the normal straight draw.
	 *  This covers #1, #2, #3, #4, #5, #6, #7 and #18
	 */
	if (si.info) {
	  strdraw_type = si.info;
	  strat.str.outs = si.nways()*4;
	  strat.str.pwin = si.pwin(noppo);
	  strat.flags |= TTH_HAVE_STR_DR;
	}
      }

      /*
       *  Now flush-draw threatened by straight draw and normal flush draw.
       *  There are profile-dependent restrictions on when a flush draw is good enough.
       */
      if (fi.info) {
	/*
	 *  Flush draw when a straight draw is present - we're more
	 *  passive in case someone made it - we won't be able to steal as often (?).
	 *  If we have the straight, this will be taken into account in the made hand
	 *
	 *  #16: Flush draw w ace vs three or four card straight (A9 654)
	 *  #17: Flush draw wo ace vs three or four card straight (75 KJT)
	 */
	if (si.nut_made != -1) {
	  if (fi.rank == 0)
	    flushdraw_type = 16;
	  else 
	    flushdraw_type = 17;
	} else {
	  /*
	   *  Flush draws not threatened by straight draw.
	   */
	  flushdraw_type = fi.info;
	}
	
	strat.fl.outs = 9;
	//  we don't care if our draw is threatened and the other draw comes in as we win
	//	strat.fl.pwin = (fi.nholes() == 2 ? (1-psomeoppohas2) + psomeoppohas2*(1-fi.rank/8.0) :
	//			 (1-psomeoppohas1) + psomeoppohas1*(1-fi.rank/8.0));
	strat.fl.pwin = 1.0; // FIXME
	strat.flags |= TTH_HAVE_FL_DR;
      }
    }
  } // ncards < 5
  
  made_type = nopair_made_type(board, ncards, hole, sfi, si, fi, Rank_info(board, ncards, hole));

  /*
   *  All TTH_strategies are now setup.
   */
  if (strflushdraw_type) {
    //    printf("Strflush draw type %i (%s)\n", strflushdraw_type, nopair_str(strflushdraw_type));
    strat.str.desc = nopair_str(strflushdraw_type);
    strat.str.bv = p->nopair[strflushdraw_type-1][round][pos];
    strat.str.htype = strflushdraw_type-1;
  } else {
    if (strdraw_type) {
      //      printf("Str draw type %i (%s)\n", strdraw_type, nopair_str(strdraw_type));
      strat.str.desc = nopair_str(strdraw_type);
      strat.str.bv = p->nopair[strdraw_type-1][round][pos];
      strat.str.htype = strdraw_type-1;
    }
    if (flushdraw_type) {
      //      printf("Flush draw type %i (%s)\n", flushdraw_type, nopair_str(flushdraw_type));
      strat.fl.desc = nopair_str(flushdraw_type);
      strat.fl.bv = p->nopair[flushdraw_type-1][round][pos];
      strat.fl.htype = flushdraw_type-1;
    }
  }
  //  printf("Made type %i (%s)\n", made_type, nopair_str(made_type));
  strat.made.desc = nopair_str(made_type);
  strat.made.bv = p->nopair[made_type-1][round][pos];
  strat.made.htype = made_type-1;
}

void Tth::do_onepair(Tth_strategy & strat, Card board[5], int ncards, Hole hole,
		  int round, int pos, int noppo, Tth_profile const * p)
{
  int strflushdraw_type = 0;
  int strdraw_type = 0;
  int flushdraw_type = 0;
  int made_type = 0;

  assert(ncards >= 3 && ncards <= 5);

  Straight_info si;
  Flush_info    fi;
  Strflush_info sfi;

  do_straights(board, ncards, hole, &si);
  do_flushes(board, ncards, hole, &fi, round, p);
  do_strflushes(board, ncards, hole, &sfi, &fi);
  
  if (ncards < 5) {  
    //  Straight-flush draws: #7 and #8
    if (sfi.info) {
      strflushdraw_type = sfi.nholes() == 2 ? 8 : 7;
      strat.str.outs = 15;
      strat.str.pwin = 1.0;
      strat.flags |= TTH_HAVE_STR_DR;

    } else {
      if (si.info) {
	Threat_info ti(fi, si, noppo, ncards);
	
	if (ti.threat >= 2) {
	  //  Threatened straight draw

	  if (verbose) REPORT(stringit("P(flush hits and we lose) = %g", ti.pflushhits_and_we_lose));
	
	  if (ti.threat == 2)
	    if (si.two_cards())
	      DO_STR_DRAW(3, true); // "A straight draw w/2 cards vs a flopped 2-card flush (98 776 or T9 776)";
	    else
	      DO_STR_DRAW(34, true); // actually "A straight draw w/1 card vs a 3-card flush (K8 6554 or K9 8776)" - calling 1 bet on turn

	  else if (ti.threat == 3)
	    if (si.two_cards())
	      DO_STR_DRAW(4, true); //  "A straight draw w/2 cards vs a 3-card flush (98 7763 or T9 7763 w/763 suited)";
	    else 
	      DO_STR_DRAW(34, true); // "A straight draw w/1 card vs a 3-card flush (K8 6554 or K9 8776)";

	  //  If there are 4 flush cards present, since there's a pair we must have 5 board cards (and hence no draw)

	} else {
	  //  Normal straight draw
	  if (si.ncards() == 2)
	    if (si.nways() == 1)
	      DO_STR_DRAW(1, false); // "An inside straight draw w/2 cards (98 655 or 65 988)";
	    else
	      DO_STR_DRAW(2, false); // "A 2-way straight draw w/2 cards (98 776)";
	  else
	    DO_STR_DRAW(33, false); // "A straight draw w/1 card (K8 6554 or K9 8776)"; 
	}
      }
      
      if (fi.info) {
	//  Flush draw
	if (fi.rank == 0)
	  flushdraw_type = 5; // "A flush draw with an A (A9 J776 w/AJ76 suited)";
	else 
	  flushdraw_type = 6; // "A flush draw without an A (Q9 J776 w/QJ76 suited)";
	
	strat.fl.outs = 9;
	strat.fl.pwin = 1.0; // FIXME
	strat.flags |= TTH_HAVE_FL_DR;
      }
    }
  }
  
  made_type = onepair_made_type(board, ncards, round, hole, sfi, si, fi, 
				Rank_info(board, ncards, hole), p->trips_strong_kicker[round]);

  if (strflushdraw_type) {
    strat.str.desc = onepair_str(strflushdraw_type);
    strat.str.bv = p->onepair[strflushdraw_type-1][round][pos];
    strat.str.htype = strflushdraw_type-1;
  } else {
    if (strdraw_type) {
      strat.str.desc = onepair_str(strdraw_type);
      strat.str.bv = p->onepair[strdraw_type-1][round][pos];
      strat.str.htype = strdraw_type-1;
    }
    if (flushdraw_type) {
      strat.fl.desc = onepair_str(flushdraw_type);
      strat.fl.bv = p->onepair[flushdraw_type-1][round][pos];
      strat.fl.htype = flushdraw_type-1;
    }
  }
  strat.made.desc = onepair_str(made_type);
  strat.made.bv = p->onepair[made_type-1][round][pos];
  strat.made.htype = made_type-1;
}
  
int Tth::onepair_made_type(Card board[5], int ncards, int round, Hole hole, 
			   Strflush_info const & sfi,
			   Straight_info const & si,
			   Flush_info const & fi,
			   Rank_info const & ri,
			   int trips_strong_kicker)
{
  //  NB!!!  Board has one pair 

  //  Do big hands first: top FH or better
  if (sfi.made() || ri.quads)
    return 32; // "Top full house or better (KK KQQ or K9 KK9 or 44 443)"

  //  Full houses: NB board has one pair
  if (ri.pairs && ri.trips) {
    /*
     *  When is a FH top?
     *  66543 need 65
     *  65543, 65443 etc need 66
     *  So need tripsrank == btr and either a pocket pair or
     *  the board to have only 2 cards over hlr
     */
    if (ri.tripsrank == ri.btr
	&& (ri.pocketpair || ri.n_board_ov2 == 2))
      return 32; // "Top full house or better (KK KQQ or K9 KK9 or 44 443)"
    return 31; // "Full house, other than top full house (KQ KQQ)"
  }
    
  if (fi.made_nuts())
    return 28; // "Nut straight or flush (98 7765)"
  
  if (fi.made)
    return 27; // "Non-nut straight or flush (84 7765)"

  //  Threatened straight - we're worried the guy has a made flush
  if (si.made) {
    if (fi.max() == 4)
      return 30; // "A straight vs a 4-card flush (K8 99765 w/9765 suited)"
    if (fi.max() == 3)
      return 29; // "A straight vs a 3-card flush (98 T776 w/9765 suited)"
    if (si.made_nuts())
      return 28; // "Nut straight or flush (98 7765)"

    return 27; // "Non-nut straight or flush (84 7765)"
  }

  //  Trips or a set
  if (ri.trips) {
    if (fi.max() == 4 || si.nut_made1 >= 0)
      return 26; // "Trips vs 4-card straight or flush (K7 98776)"
    if (fi.max() == 3 || si.nut_made >= 0)
      return 25; // "Trips vs 3-card straight or flush (K7 9877)"
    
    if (ri.htr + ri.hlr - ri.tripsrank >= trips_strong_kicker)
      return 24; // "Trips w/strong kicker (7? 77Q)"

    return 23; // "Trips w/weak kicker (7? 77Q)"
  }

  //  Two pair (or three pair)
  if (ri.pairs >= 2) {
    if (fi.max() >= 3 || si.nut_made >= 0) {
      int toc = ri.top_odd_card();
      int other_pair_rank = ri.counts_board_and_hole(ri.htr) == 2 ? ri.htr : ri.hlr;
      if ((ri.pocketpair && ri.htr > toc)
	  || (ri.n_higher_odd_cards(board, ncards, other_pair_rank) == 0)) // NB 94 QQ74 is lesser 94 QQJ94 is lesser
	return 21; // "Better 2 pair vs 3,4-card straight or flush (TT QQ92 or A9 QQ92 or 97 QQ94)"
      return 22; // "Lesser 2 pair vs 3,4-card straight or flush (JJ KKQ2 or 66 QQJ7 or Q4 9974)"
    }

    if (ri.pocketpair) {
      int nh = ri.n_higher_odd_cards(board, ncards, ri.htr);
      if (nh == 0) {
	if (ri.htr >= JACK)
	  return 14; // "2 pair, pocket J's or better, no higher odd cards on board (JJ QQ9)"
	return 15; // "2 pair, pocket T's or lower no higher odd cards on board (TT QQ9)"
      }
      if (nh == 1)
	return 16; // "2 pair, any pocket pair, 1 higher odd card on board (JJ KKQ or JJ KKQ2)"
      
      return 17; // "2 pair, any pocket pair, 2 + higher odd cards on boad (66 QQJ7)"
    }
    
    int toc = ri.top_odd_card();
    if (ri.htr == toc || ri.hlr == toc) {
      //  ??? AJ AQQ counts as good kicker, guess not
      int kicker = ri.htr + ri.hlr - toc;
      if (kicker == ACE || kicker == KING)
	return 18; // "2 pair, match top odd card on board, plus A or K kicker (A9 QQ9 or A9 QQ92)"
      return 19; // "2 pair, match top odd card on board, no  A or K kicker (97 QQ9 or 97 QQ94)"
    }
    
    return 20; // "2 pair, match other than top odd card on board, any kicker (Q4 9974)"
  }
  
  if (ri.hlr > ri.btr) {
    bool major_overcards = ((ri.htr == ACE && ri.hlr >= JACK)
			    || (ri.htr == KING && ri.hlr == QUEEN));
    
    if (major_overcards) {
      if (fi.max() == 3 || si.nut_made >= 0)
	return 12; // "2 major overcards (AK, AQ, AJ or KQ) vs 3-str or 3-flush (AJ 986 w/986s)"
      return 9; // "2 major overcards (AK, AQ, AJ or KQ)"
    }
    
    if (si.nut_made >= 0)
      return 13; // "2 minor overcards or Ace overcard vs 3-str (K9 864)"
    
    if (ri.htr == ACE && ri.btr <= NINE)
      return 11; // "Ace overcard w/rags on the board (A8 963)"
    
    if (ri.btr <= NINE)
      return 10; // "2 minor overcards w/rags on the board (Q9 863)";
  }
  
  if (ri.htr == ACE && si.nut_made >= 0)
    return 13; // "2 minor overcards or Ace overcard vs 3-str (K9 864)"

  if (ri.htr == ACE && ri.btr <= NINE)
    return 11; // "Ace overcard w/rags on the board (A8 963)"

  return 35; // "Nothing (J8 T53 or J8 AK7)"
}

void Tth::do_twopair(Tth_strategy & strat, Card board[5], int ncards, Hole hole,
		     int round, int pos, int noppo, Tth_profile const * p)
{
  int strflushdraw_type = 0;
  int strdraw_type = 0;
  int flushdraw_type = 0;
  int made_type = 0;

  assert(ncards >= 3 && ncards <= 5);

  Straight_info si;
  Flush_info    fi;
  Strflush_info sfi;

  do_straights(board, ncards, hole, &si);
  do_flushes(board, ncards, hole, &fi, round, p);
  do_strflushes(board, ncards, hole, &sfi, &fi);
  
  Threat_info ti(fi, si, noppo, ncards);

  if (ncards < 5) {  
    if (sfi.info) {
      strflushdraw_type = 3;
      strat.str.outs = 15;
      strat.str.pwin = 1.0;
      strat.flags |= TTH_HAVE_STR_DR;
    } else {
      if (si.info && si.nways() == 2)
	DO_STR_DRAW(1, false);
      
      if (fi.info) {
	if (fi.rank == 0)
	  flushdraw_type = 2;
	else
	  flushdraw_type = 1;
	
	strat.fl.outs = 9;
	strat.fl.pwin = 1.0; // FIXME
	strat.flags |= TTH_HAVE_FL_DR;
      }
    }
  }
  
  made_type = twopair_made_type(board, ncards, round, hole, sfi, si, fi, Rank_info(board, ncards, hole));

  if (strflushdraw_type) {
    strat.str.desc = twopair_str(strflushdraw_type);
    strat.str.bv = p->twopair[strflushdraw_type-1][round][pos];
    strat.str.htype = strflushdraw_type-1;
  } else {
    if (strdraw_type) {
      strat.str.desc = twopair_str(strdraw_type);
      strat.str.bv = p->twopair[strdraw_type-1][round][pos];
      strat.str.htype = strdraw_type-1;
    }
    if (flushdraw_type) {
      strat.fl.desc = twopair_str(flushdraw_type);
      strat.fl.bv = p->twopair[flushdraw_type-1][round][pos];
      strat.fl.htype = flushdraw_type-1;
    }
  }
  strat.made.desc = twopair_str(made_type);
  strat.made.bv = p->twopair[made_type-1][round][pos];
  strat.made.htype = made_type-1;
}

int Tth::twopair_made_type(Card board[5], int ncards, int round, Hole hole, 
			   Strflush_info const & sfi,
			   Straight_info const & si,
			   Flush_info const & fi,
			   Rank_info const & ri)
{
  if (sfi.made() || ri.quads)
    return 14; // "Four of a kind of better (44 4455)"
  
  if (ri.trips && ri.pairs) {
    
    //  Over FH (our pocket pairs matches top board card & we don't have a quad)
    if (ri.pocketpair && ri.htr == ri.btr)
      return 13; // "Over full house (KK QQ99K)"
    
    //  Top FH 44332 need a 4. 43322 need 44 (which is an over FH & so done above)
    if (ri.counts_board_and_hole(ri.btr) == 3)
      return 12; // "Top full house (QJ QQ99)";

    return 11; // "Full house, other than top full (QJ QQKK)"
  }

  if (si.made || fi.made)
    return 10; // "A straight or flush (QJ AKTAK)"

  if (ri.pocketpair) {
    if (ri.htr > ri.btr)
      return 7; // "Pocket overpair (JJ 9966) or match board overcard (KQ Q9966)"
    if (ri.htr < ri.blr)
      return 9; // "Pocket underpair (55 9966)"
    return 8; // "Pocket middle pair (88 9966) or match board middle card (QJ KK66Q)"
  }

  if (ri.pairs == 3) {
    int rank = ri.counts_board_and_hole(ri.htr) == 2 ? ri.htr : ri.hlr;
    if (ri.n_higher_cards(board, ncards, rank) == 0)
      return 7; // "Pocket overpair (JJ 9966) or match board overcard (KQ Q9966)"
    if (ri.n_higher_cards(board, ncards, rank) == 2)
      return 8; // "Pocket middle pair (88 9966) or match board middle card (QJ KK66Q)
  }

  if (ri.htr == ACE) {
    if (ri.hlr < ri.get_lowest_non_odd_card(board, ncards))
      return 5;  // "Ace w/kicker lower than lower pair (A6 QQ77)"
    return 4; // "Ace w/kicker higher than lower pair (A8 7755 or AJ 9933)"
  }

  if (ri.htr == KING) 
    if (ri.hlr > ri.get_lowest_non_odd_card(board, ncards))
      return 6; // "King w/kicker higher than lower pair (KJ AA77 or KJ 9966)"
  
  return 15; // "Nothing (J8 9966 or K3 9966)"
}

void Tth::do_trips(Tth_strategy & strat, Card board[5], int ncards, Hole hole,
		   int round, int pos, int noppo, Tth_profile const * p)
{
  int strflushdraw_type = 0;
  int strdraw_type = 0;
  int flushdraw_type = 0;
  int made_type = 0;

  assert(ncards >= 3 && ncards <= 5);

  Straight_info si;
  Flush_info    fi;
  Strflush_info sfi;

  do_straights(board, ncards, hole, &si);
  do_flushes(board, ncards, hole, &fi, round, p);
  do_strflushes(board, ncards, hole, &sfi, &fi);

  Threat_info ti(fi, si, noppo, ncards);

  if (ncards < 5) {  
    if (sfi.info) {
      strflushdraw_type = 3;
      strat.str.outs = 15;
      strat.str.pwin = 1.0;
      strat.flags |= TTH_HAVE_STR_DR;
    } else {
      if (si.info && si.nways() == 2)
	DO_STR_DRAW(1, false);
      
      if (fi.info) {
	if (fi.rank == 0)
	  flushdraw_type = 2;
	else
	  flushdraw_type = 1;
	
	strat.fl.outs = 9;
	strat.fl.pwin = 1.0; // FIXME
	strat.flags |= TTH_HAVE_FL_DR;
      }
    }
  }

  made_type = trips_made_type(board, ncards, round, hole, sfi, si, fi, Rank_info(board, ncards, hole));

  if (strflushdraw_type) {
    strat.str.desc = trips_str(strflushdraw_type);
    strat.str.bv = p->trips[strflushdraw_type-1][round][pos];
    strat.str.htype = strflushdraw_type-1;
  } else {
    if (strdraw_type) {
      strat.str.desc = trips_str(strdraw_type);
      strat.str.bv = p->trips[strdraw_type-1][round][pos];
      strat.str.htype = strdraw_type-1;
    }
    if (flushdraw_type) {
      strat.fl.desc = trips_str(flushdraw_type);
      strat.fl.bv = p->trips[flushdraw_type-1][round][pos];
      strat.fl.htype = flushdraw_type-1;
    }
  }
  strat.made.desc = trips_str(made_type);
  strat.made.bv = p->trips[made_type-1][round][pos];
  strat.made.htype = made_type-1;
}

//  If the board is a FH, we end here
int Tth::trips_made_type(Card board[5], int ncards, int round, Hole hole, 
			 Strflush_info const & sfi,
			 Straight_info const & si,
			 Flush_info const & fi,
			 Rank_info const & ri)
{
  if (sfi.made() || ri.quads)
    return 14; // "Over full house, four of a kind or better (JJ J999 A9 J999)"
  
  //  Over FH 2223 need 33 
  //  guess 33222 3x OK too
  if (ri.trips == 2 && 
      ((ri.pocketpair && ri.htr == ri.btr)
       || (ri.btr == ri.htr || ri.btr == ri.hlr)))
    return 14; // "Over full house, four of a kind or better (JJ J999 A9 J999)"

  if (ri.trips && ri.pairs) {
    if (ri.pocketpair) {
      if (ri.n_higher_odd_cards(board, ncards, ri.htr) == 0) {
	if (ri.htr >= QUEEN)
	  return 8; // "Full house w/pocket Q's or better, no higher odd card(s) on board"
	if (ri.htr >= JACK)
	  return 9; // "Full house w/pocket 9's thru J's, no higher odd card(s) on board (99 JJJ8)"
	return 10; // "Full house w/pocket 2's thru 8's, no higher odd cards on board (66 7775)"
      }
      return 11; // "Full house w/any pocket but higher odd card(s) on board (QQ 777K)"
    }

    int toc = ri.get_highest_odd_card(board, ncards);
    if (ri.htr == toc || ri.hlr == toc)
      return 12; // "Full house w/match of high odd card on the board (KQ 777Q or KQ 777Q6)"
    return 13; // "Full house w/match of low odd card on the board (K6 7776Q)"
  }

  if (si.made || fi.made)
    return 7; // "A straight or flush (QJ AKTAA)

  if (ri.n_higher_odd_cards(board, ncards, ri.hlr-1) == 0
      && ((ri.htr == ACE && ri.hlr >= TEN)
	  || (ri.htr == KING && ri.hlr == QUEEN)))
    
    return 4; // "Big cards: AK, AQ, AJ, AT or KQ both higher than odd card(s) (AQ JKKK3)"

  if (ri.htr == ACE && ri.btr < ACE)
    return 5; // "Ace overcard (A9 JJJ2 or A2 KKK9)"

  if (ri.hlr >= NINE && ri.n_higher_odd_cards(board, ncards, ri.hlr-1) == 0)
    return 6; // "2 cards, 9 high or better, both higher than odd card(s) (QJ KKK8)" 

  return 15; // "Nothing (J8 999)"
}

void Tth_strategy::dump()
{
  if (flags & TTH_HAVE_STR_DR) {
    if (verbose) REPORT(stringit("str draw: %s", str.desc));
    if (verbose) REPORT(stringit("str draw: BV=%s, out=%i pwin=%g", str.bv.to_str(), str.outs, str.pwin));
  }

  if (flags & TTH_HAVE_FL_DR) {
    if (verbose) REPORT(stringit("flush draw: %s", fl.desc));
    if (verbose) REPORT(stringit("flush draw: BV=%s, out=%i pwin=%g", fl.bv.to_str(), fl.outs, fl.pwin));
  }

  if (verbose) REPORT(stringit("made hand: %s", made.desc));
  if (verbose) REPORT(stringit("made hand: BV=%s", made.bv.to_str()));
}

#ifdef TTH_MAIN

#define X "2c"

int main_nopair()
{
  struct {
    Hole h;
    Card brd[5];
    int ncards;
  } egs[] = {
    {Hand("Qd Jc"), {"Kd", "Ad", "9c", X, X}, 3},
    
	     {Hand("Qc 9c"), {"8c", "6d", "5h", X, X}, 3},
	     {Hand("6c 5c"), {"Qc", "9d", "8h", X, X}, 3},
	     {Hand("9c 8c"), {"Ac", "6d", "5h", X, X}, 3},
	     {Hand("8c 6c"), {"Ac", "9d", "5h", X, X}, 3},
	     {Hand("Kc 6c"), {"9c", "8d", "7h", X, X}, 3},
	     {Hand("Kc 9c"), {"8c", "7d", "6h", X, X}, 3},
	     {Hand("7c 6c"), {"Kc", "9d", "8h", X, X}, 3}, // 6
	     {Hand("4c 2d"), {"8c", "6d", "5h", X, X}, 3}, // 6
	     {Hand("9c 8c"), {"Kc", "7d", "6h", X, X}, 3}, // 7
	     {Hand("Qc Jc"), {"Ac", "Td", "8h", X, X}, 3}, // 7
	     {Hand("8d 6h"), {"Ks", "9c", "7c", X, X}, 3},
	     {Hand("Kd 9h"), {"8s", "7c", "6c", X, X}, 3}, 
	     {Hand("9d 8h"), {"Kc", "7c", "6c", X, X}, 3},
	     {Hand("Kd 9h"), {"8c", "7c", "6c", X, X}, 3},
	     
	     {Hand("Ac 9d"), {"Jc", "7c", "6c", X, X}, 3},
	     {Hand("Kc 9d"), {"Jc", "7c", "6c", X, X}, 3},
	     {Hand("Ac 9c"), {"Jc", "7c", "6d", X, X}, 3},
	     {Hand("Kc 9c"), {"Jd", "7c", "6c", X, X}, 3},
	     {Hand("Ac 9d"), {"6c", "5c", "4c", X, X}, 3},
	     {Hand("7c 5c"), {"Kc", "Jc", "Ts", X, X}, 3},

	     {Hand("Qd 5c"), {"9h", "8s", "6c", X, X}, 3}, // 18

	     {Hand("Kd 6c"), {"9c", "8c", "7c", X, X}, 3}, // 19
	     {Hand("7c 6c"), {"9c", "8c", "3d", X, X}, 3},

	     {Hand("Ac Kc"), {"9d", "5c", "4s", X, X}, 3}, // 21
	     {Hand("Qc 9c"), {"8d", "6c", "3s", X, X}, 3},
	     {Hand("Ac 8c"), {"9d", "6c", "3s", X, X}, 3},
	     {Hand("Ac Jc"), {"9d", "8d", "6d", X, X}, 3},
	     {Hand("Kc 9c"), {"8d", "6d", "4d", X, X}, 3},
	     {Hand("Jc 8c"), {"Td", "5d", "3c", X, X}, 3},
	     {Hand("Jc 8c"), {"Ad", "Kd", "7c", X, X}, 3},

	     {Hand("Jc 8c"), {"Qc", "Jd", "4c", X, X}, 3}, // 27
	     {Hand("Kc Jc"), {"Qc", "Jd", "4c", X, X}, 3},
	     {Hand("Ac Jc"), {"Qc", "Jd", "9c", X, X}, 3},
	     {Hand("8s 4s"), {"9c", "8d", "7c", "6c", X}, 4},
	     
	     {Hand("Jc 8c"), {"Jd", "9d", "4s", X, X}, 3}, // 31
	     {Hand("Kc Jc"), {"Jd", "9d", "4s", X, X}, 3},
	     {Hand("Qc 8c"), {"Qd", "9d", "4s", X, X}, 3},
	     {Hand("Kd Qc"), {"Qd", "9d", "3s", X, X}, 3},
	     {Hand("Ad 8c"), {"Ac", "9d", "3s", X, X}, 3},
	     {Hand("Ad Jc"), {"Ac", "9d", "4s", X, X}, 3},
	     {Hand("Ad Qc"), {"Ac", "9d", "4s", X, X}, 3},
	     {Hand("Kd 8c"), {"Kc", "Qd", "Js", X, X}, 3},
	     {Hand("Kd 9c"), {"9c", "8d", "6s", X, X}, 3},
	     {Hand("Ad Jc"), {"Jc", "Td", "9s", "7c", X}, 4},
	     
	     {Hand("Kc Kd"), {"Qc", "8d", "5d", X, X}, 3}, // 41
	     {Hand("Jc Jd"), {"9c", "7d", "4d", X, X}, 3},
	     {Hand("9c 9d"), {"8c", "7d", "3d", X, X}, 3},
	     {Hand("Kc Kd"), {"Jc", "9d", "8d", X, X}, 3}, // 44
	     {Hand("Kc Kd"), {"Jh", "5h", "3h", X, X}, 3}, // 44
	     {Hand("Qc Qd"), {"8c", "7d", "6d", "4d", X}, 4}, // 45
	     {Hand("Qc Qd"), {"Jh", "9h", "5h", "3h", X}, 4}, // 45
	     {Hand("9c 9d"), {"Kh", "7h", "5d", X, X}, 3}, 
	     {Hand("9c 9d"), {"Kh", "7h", "5d", X, X}, 3}, // 47
	     {Hand("9c 9d"), {"Kh", "Qh", "5d", X, X}, 3}, // 47
	     {Hand("8c 8d"), {"Kh", "Qh", "Jd", X, X}, 3}, // 48
	     {Hand("8c 8d"), {"Kh", "Th", "2h", X, X}, 3}, // 48
	     {Hand("8c 8d"), {"Kh", "Qs", "Jh", "9d", X}, 4}, // 49
	     {Hand("8c 8d"), {"Kh", "Qh", "3h", "2h", X}, 4}, // 49

	     {Hand("Jc 6c"), {"Qc", "Jh", "6s", X, X}, 3}, // 50
	     {Hand("Jc 3c"), {"Jc", "6h", "3s", X, X}, 3},
	     {Hand("Jc 9c"), {"Jc", "Th", "9s", X, X}, 3}, // 52
	     {Hand("6s 3c"), {"Js", "6s", "3s", X, X}, 3}, // 52
	     {Hand("Js 9c"), {"Qs", "Js", "Tc", "9h", X}, 4}, // 53
	     {Hand("Qs Tc"), {"Qh", "Th", "6h", "2h", X}, 4}, // 53

	     {Hand("7c 7d"), {"Qc", "Jc", "7s", X, X}, 3}, // 54
	     {Hand("7c 7d"), {"8c", "7s", "6d", X, X}, 3}, // 55
	     {Hand("7c 7d"), {"Qh", "Jh", "7h", X, X}, 3}, // 55
	     {Hand("9s 9c"), {"Qs", "Js", "Tc", "9h", X}, 4}, // 56
	     {Hand("6s 6c"), {"Qh", "Th", "6h", "2h", X}, 4}, // 56
	     
	     {Hand("8c 4c"), {"7d", "5h", "6s", X, X}, 3}, // 57
	     {Hand("Kc 4c"), {"Tc", "5c", "6c", X, X}, 3}, // 57
	     {Hand("8c 7c"), {"9d", "5c", "6c", X, X}, 3}, // 58
	     {Hand("Ac 7c"), {"9c", "5c", "6c", X, X}, 3}, // 58
	     {Hand("8c 7c"), {"9c", "5c", "6c", X, X}, 3}, // 58
	     {Hand("8c 4c"), {"7s", "5s", "6s", X, X}, 3}, // 59
	     {Hand("8c 4c"), {"7s", "5s", "6s", "2s", X}, 4}, // 60
  };
  
  for (unsigned i=0; i<sizeof(egs)/sizeof(egs[0]); i++) {
    //    Straight_info sinfo;
    //    Flush_info finfo;
    //    Strflush_info sfinfo;

    printf("\n");
    printf("Hole %s\n", egs[i].h.to_str());
    printf("Board: ");
    for (int j=0; j<egs[i].ncards; j++)
      printf("%s ", egs[i].brd[j].to_str());
    printf("\n");

#if 0
    Tth::do_straights(egs[i].brd, egs[i].ncards, egs[i].h, &sinfo);
    printf("straight info %i\n", sinfo.info);

    Tth::do_flushes(egs[i].brd, egs[i].ncards, egs[i].h, &finfo);
    printf("flush info %i suit %i\n", finfo.info, finfo.suit);

    Tth::do_strflushes(egs[i].brd, egs[i].ncards, egs[i].h, &sfinfo, &finfo);
    printf("strflush info %i suit %i\n", sfinfo.info, sfinfo.suit);
#endif

    Tth_strategy strat;
    Tth::do_nopair(strat, egs[i].brd, egs[i].ncards, egs[i].h, 1, 0, 1, &tth_bret);
    strat.dump();
  }

  return 0;
}

int main_pair()
{
  struct {
    Hole h;
    Card brd[5];
    int ncards;
  } egs[] = {
    {Hand("9c 8d"), {"6h", "5s", "5c", X, X}, 3}, // 1
    {Hand("6c 5d"), {"9h", "8s", "8c", X, X}, 3}, // 1
    {Hand("Kc 8d"), {"6c", "5d", "5h", "4s", X}, 4}, // 33
    {Hand("Kc 9d"), {"8c", "7d", "7h", "6s", X}, 4}, // 33
    {Hand("9c 8d"), {"7h", "7s", "6c", X, X}, 3}, // 2

    {Hand("9c 8d"), {"7h", "7h", "6c", X, X}, 3}, // 3
    {Hand("Tc 9d"), {"7h", "7h", "6c", X, X}, 3}, // 3

    {Hand("Kc 8d"), {"6h", "5h", "5h", "4s", X}, 4}, // 34
    {Hand("Kc 9d"), {"8h", "7h", "7h", "6s", X}, 4}, // 34
    {Hand("9c 8d"), {"7h", "7h", "6h", "3s", X}, 4}, // 4
    {Hand("Tc 9d"), {"7d", "7h", "6h", "3h", X}, 4}, // 4

    {Hand("Ac 9d"), {"Jc", "7c", "7h", "6c", X}, 4}, // 5
    {Hand("Qc 9d"), {"Qc", "Jc", "7h", "6c", X}, 4}, // 6

    {Hand("Kc 6d"), {"9c", "8c", "7h", "7c", X}, 4}, // 7
    {Hand("7c 6d"), {"9c", "8c", "8h", X, X}, 3}, // 8

    {Hand("Ac Jd"), {"9c", "9d", "6c", "2s", X}, 4}, // 9
    {Hand("Qc 9d"), {"8c", "8d", "6c", "2s", X}, 4}, // 10
    {Hand("Ac 4d"), {"8c", "8d", "7c", "3s", X}, 4}, // 11
    {Hand("Ac Jd"), {"9c", "9d", "8c", "6s", X}, 4}, // 12
    {Hand("Ac Jd"), {"9c", "9s", "8s", "3s", X}, 4}, // 12
    {Hand("Kc 9d"), {"8c", "6s", "6c", "4h", X}, 4}, // 13

    {Hand("Jc Jd"), {"Qc", "Qs", "9h", X, X}, 3}, // 14
    {Hand("Tc Td"), {"Qc", "Qs", "9h", X, X}, 3}, // 15
    {Hand("Jc Jd"), {"Kc", "Ks", "Qh", X, X}, 3}, // 16
    {Hand("Jc Jd"), {"Kc", "Ks", "Qh", "2s", X}, 4}, // 16
    {Hand("6c 6d"), {"Qc", "Qs", "Jh", "7s", X}, 4}, // 17

    {Hand("Ac 9d"), {"Qc", "Qd", "9s", X, X}, 3}, // 18
    {Hand("Ac 9d"), {"Qc", "Qd", "9s", "2s", X}, 4}, // 18
    {Hand("9c 7d"), {"Qc", "Qd", "9s", X, X}, 3}, // 19
    {Hand("9c 7d"), {"Qc", "Qd", "9s", "4s", X}, 4}, // 19
    {Hand("Qc 4d"), {"9c", "9d", "7s", "4s", X}, 4}, // 20

    {Hand("Tc Td"), {"Qc", "Qs", "9s", "2s", X}, 4}, // 21
    {Hand("Ac 9d"), {"Qc", "Qs", "9s", "2s", X}, 4}, // 21
    {Hand("9c 7d"), {"Qc", "Qs", "9s", "4s", X}, 4}, // 21
    {Hand("9c 4d"), {"Qc", "Qs", "9s", "4s", X}, 4}, // 21

    {Hand("9c 5d"), {"6c", "6h", "5s", "4s", X}, 4}, // 21

    {Hand("Jc Jd"), {"Kc", "Ks", "Qs", "2s", X}, 4}, // 22
    {Hand("6c 6d"), {"Qc", "Qs", "Js", "Th", X}, 4}, // 22
    {Hand("Qc 4d"), {"9c", "9s", "7s", "4s", X}, 4}, // 22

    {Hand("7c 2d"), {"7c", "7d", "Qs", X, X}, 3}, // 23
    {Hand("7c Ad"), {"7c", "7d", "Qs", X, X}, 3}, // 24
    {Hand("Kc 7d"), {"9c", "8d", "7s", "7c", X}, 4}, // 25
    {Hand("Kc 7d"), {"Ah", "7s", "7h", "2h", X}, 4}, // 25
    {Hand("Kc 7d"), {"9c", "8d", "7s", "7c", "6s"}, 5}, // 26
    {Hand("Kc 7d"), {"Ah", "Qh", "7h", "7c", "6h"}, 5}, // 26

    {Hand("8c 4d"), {"7c", "7d", "6s", "5c", X}, 4}, // 27
    {Hand("Kc 4c"), {"7c", "7d", "6c", "5c", X}, 4}, // 27

    {Hand("9c 8d"), {"7c", "7d", "6s", "5c", X}, 4}, // 28
    {Hand("Ac 4c"), {"7c", "7d", "6c", "5c", X}, 4}, // 28

    {Hand("9c 8d"), {"7c", "7s", "6s", "5s", X}, 4}, // 29
    {Hand("9c 8d"), {"7s", "7s", "6s", "5s", X}, 4}, // 29

    {Hand("Kc 8d"), {"9c", "9s", "7s", "6s", "5s"}, 5}, // 30
    {Hand("Kc Qd"), {"Kh", "Qs", "Qc", X, X}, 3}, // 31
    {Hand("Kc Kd"), {"Kh", "Qs", "Qc", X, X}, 3}, // 32
    {Hand("Kc 9d"), {"Kh", "Ks", "9c", X, X}, 3}, // 32
    {Hand("4c 4d"), {"4h", "4s", "3c", X, X}, 3}, // 32
    {Hand("9c 8c"), {"7c", "7d", "6c", "5c", X}, 4}, // 32

    {Hand("Jc 8d"), {"9h", "9s", "3c", X, X}, 3}, // 35
  };
  
  for (unsigned i=0; i<sizeof(egs)/sizeof(egs[0]); i++) {
    printf("\n");
    printf("Hole %s\n", egs[i].h.to_str());
    printf("Board: ");
    for (int j=0; j<egs[i].ncards; j++)
      printf("%s ", egs[i].brd[j].to_str());
    printf("\n");
    
    Tth_strategy strat;
    Tth::do_onepair(strat, egs[i].brd, egs[i].ncards, egs[i].h, 1, 0, 1, &tth_bret);
    strat.dump();
  }

  return 0;
}

int main_twopair()
{
  struct {
    Hole h;
    Card brd[5];
    int ncards;
  } egs[] = {

    {Hand("9c 8d"), {"7h", "6s", "7c", "6h", X}, 4}, // 1
    {Hand("Ac 9c"), {"9c", "8c", "9s", "8h", X}, 4}, // 2
    {Hand("7c 6c"), {"9c", "8c", "9s", "8h", X}, 4}, // 3

    {Hand("Ac 8c"), {"7c", "7d", "5s", "5h", X}, 4}, // 4
    {Hand("Ac Jc"), {"9c", "9d", "3s", "3h", X}, 4}, // 4
    {Hand("Ac 6c"), {"Qc", "Qd", "7s", "7h", X}, 4}, // 5
    {Hand("Kc Jc"), {"Ac", "Ad", "7s", "7h", X}, 4}, // 6
    {Hand("Kc Jc"), {"9c", "9d", "6s", "6h", X}, 4}, // 6

    {Hand("Jc Jd"), {"9c", "9d", "6s", "6h", X}, 4}, // 7
    {Hand("Kc Qd"), {"Qc", "9d", "9s", "6h", "6s"}, 5}, // 7
    {Hand("8c 8d"), {"9d", "9s", "6h", "6s", X}, 4}, // 8
    {Hand("Qc Jd"), {"Kd", "Ks", "6h", "6s", "Qh"}, 5}, // 8
    {Hand("Qc Jd"), {"Kd", "Ks", "6h", "6s", "Qh"}, 5}, // 8

    {Hand("5c 5d"), {"9d", "9s", "6h", "6s", X}, 4}, // 9

    {Hand("Qc Jd"), {"Ad", "Ks", "Th", "As", "Kh"}, 5}, // 10
    {Hand("Qc Jd"), {"Qd", "Qs", "Ks", "Kh", X}, 4}, // 11
    {Hand("Qc Jd"), {"Qd", "Qs", "9h", "9s", X}, 4}, // 12
    {Hand("Kc Kd"), {"Qd", "Qs", "9h", "9s", "Kc"}, 5}, // 13
    {Hand("4c 4d"), {"4h", "4s", "5h", "5s", X}, 4}, // 14

    {Hand("Jc 8d"), {"9h", "9s", "6h", "6s", X}, 4}, // 15
    {Hand("Kc 3d"), {"9h", "9s", "6h", "6s", X}, 4}, // 15
  };

  for (unsigned i=0; i<sizeof(egs)/sizeof(egs[0]); i++) {
    printf("\n");
    printf("Hole %s\n", egs[i].h.to_str());
    printf("Board: ");
    for (int j=0; j<egs[i].ncards; j++)
      printf("%s ", egs[i].brd[j].to_str());
    printf("\n");
    
    Tth_strategy strat;
    Tth::do_twopair(strat, egs[i].brd, egs[i].ncards, egs[i].h, 1, 0, 1, &tth_bret);
    strat.dump();
  }

  return 0;
}

int main_trips()
{
  struct {
    Hole h;
    Card brd[5];
    int ncards;
  } egs[] = {
    {Hand("9c 8d"), {"7h", "6s", "7c", "7h", X}, 4}, // 1
    {Hand("9c 8c"), {"7c", "3c", "7s", "7h", X}, 4}, // 1
    {Hand("Ac 8c"), {"7c", "6c", "7s", "7h", X}, 4}, // 2
    {Hand("9c 8c"), {"7c", "6c", "7s", "7h", X}, 4}, // 3

    {Hand("Ac Qc"), {"Jc", "Kd", "Ks", "Kh", "3s"}, 5}, // 4
    {Hand("Ac 9c"), {"Jc", "Jd", "Js", "2s", X}, 4}, // 5
    {Hand("Qc Jd"), {"Kc", "Kd", "Ks", "8s", X}, 4}, // 6

    {Hand("Qc Jd"), {"Ac", "Kd", "Ts", "As", "Ad"}, 5}, // 7
    {Hand("Qd Jd"), {"Ac", "2d", "Td", "As", "Ad"}, 5}, // 7

    {Hand("Qd Qs"), {"Ac", "2d", "Td", "As", "Ad"}, 5}, // 8
    {Hand("Qd Qs"), {"9c", "2d", "Td", "9s", "9d"}, 5}, // 8

    {Hand("Jd Js"), {"9c", "2d", "Td", "9s", "9d"}, 5}, // 9
    {Hand("5d 5s"), {"9c", "2d", "3d", "9s", "9d"}, 5}, // 10
    {Hand("5d 5s"), {"9c", "2d", "Td", "9s", "9d"}, 5}, // 11

    {Hand("Kd Qs"), {"7c", "7d", "7h", "Qh", X}, 4}, // 12
    {Hand("Kd Qs"), {"7c", "7d", "7h", "Qh", "6s"}, 5}, // 12
    {Hand("Kd 6s"), {"7c", "7d", "7h", "6h", "Qs"}, 5}, // 13
    {Hand("Jd Js"), {"Jc", "9d", "9h", "9s", X}, 4}, // 14
    {Hand("Ad 9s"), {"Jc", "9d", "9h", "9s", X}, 4}, // 14
    {Hand("Jd 8s"), {"9d", "9h", "9s", X, X}, 3}, // 15

  };

  for (unsigned i=0; i<sizeof(egs)/sizeof(egs[0]); i++) {
    printf("\n");
    printf("Hole %s\n", egs[i].h.to_str());
    printf("Board: ");
    for (int j=0; j<egs[i].ncards; j++)
      printf("%s ", egs[i].brd[j].to_str());
    printf("\n");
    
    Tth_strategy strat;
    Tth::do_trips(strat, egs[i].brd, egs[i].ncards, egs[i].h, 1, 0, 1, &tth_bret);
    strat.dump();
  }

  return 0;
}

int main_play(int argc, char* argv[])
{
  int np = 2;
  Dealer dlr(np);

  setbuf(stdout, 0);

  dlr.seed(atoi(argv[1]));
  dlr.set_dealer(np-1);

  vector<Hand> hands(2);
  hands[0] = Hand("9h 6h");
  hands[1] = Hand("4d Td");
  dlr.set_hands(hands);
  Card flop[3] = {"Jh", "Js", "2c"};
  dlr.set_flop(flop);
  dlr.set_turn("Jc");
  dlr.set_river("Jd");

  for (int np=0; np<2; np++)
    dlr.add_player(Bot_manager::create("test3"), 0);
  
  dlr.deal();
  dlr.run();
  return 0;
}

int main(int argc, char* argv[])
{
  //  main_nopair();
  //  main_pair();
  //  main_twopair();
  //  main_trips();
  return main_play(argc, argv);

  struct {
    Hole h;
    Card brd[5];
    int ncards;
  } egs[] = {
      {Hand("Kc Qd"), {"Kh", "Ks", "5c", "5h", "5s"}, 5}};
  
  for (unsigned i=0; i<sizeof(egs)/sizeof(egs[0]); i++) {
    printf("\n");
    printf("Hole %s\n", egs[i].h.to_str());
    printf("Board: ");
    for (int j=0; j<egs[i].ncards; j++)
      printf("%s ", egs[i].brd[j].to_str());
    printf("\n");
    
    Tth_strategy strat;
    Tth::do_trips(strat, egs[i].brd, egs[i].ncards, egs[i].h, 1, 0, 1, &tth_bret);
    strat.dump();
  }

  return 0;
}

#endif
