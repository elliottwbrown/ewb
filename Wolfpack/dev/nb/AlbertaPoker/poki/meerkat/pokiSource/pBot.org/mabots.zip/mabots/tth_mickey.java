
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_mickey extends wrapper implements Player
{
    public tth_mickey() 
    { 
	super("tth:mickey"); 
    }
}
