
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_adv6 extends wrapper implements Player
{
    public tth_adv6() 
    { 
	super("tth:adv6"); 
    }
}
