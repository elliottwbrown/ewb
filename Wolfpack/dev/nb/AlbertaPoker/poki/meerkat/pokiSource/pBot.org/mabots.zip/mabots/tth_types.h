// -*- c++ -*-
#ifndef TTH_TYPES_H
#define TTH_TYPES_H

#undef max
#undef min

//  Need to sort out the names of these

struct Straight_info
{
  Straight_info() 
    : info(0), nut_draw(-1), nut_made(-1), nut_made1(-1), our_rank(-1), made(false),
      three_str(false), four_str(false) { }

 /*
  *  0: nothing
  *  18: 1-out + 1-hole card gives us a straight but not the best from board + 2 ideal
  *  1: 1-out + 1-hole card gives us the nut straight with board + 2 ideal
  *  2: 1-out + 2-hole cards gives as a straight, but not the best from board + 3 ideal
  *  3: 1-out + 2-hole cards gives the best straight from board + 3 ideal
  *  4: 2-outs, both use 1-hole card, neither the best from board + 2 ideal
  *  5: 2-outs, both use 1-hole card one is best from board + 2 ideal
  *  6: 2-outs, at least one uses 2-hole cards but neither gives the best of board + 3 ideal
  *  7: 2-outs, at least one uses 2-hole cards and it is the best from board + 3 ideal
  */
  int info;

  //  -1 for none, o/w rank of top card in the straight
  int nut_draw; // with 3 ideal
  int nut_made; // with 2 ideal
  int nut_made1; // with 1 ideal

  //  -1 if we have no draw, o/w the rank of the top card in our straight (12=ace)
  int our_rank;

  //  Have we made our straight already? If so, made_rank is the rank
  bool made;
  int made_rank;

  //  Does the board have three or four consecutive ranks?
  bool three_str;
  bool four_str;

  bool made_nuts() const { return made && made_rank == nut_made; }

  bool two_cards() const {
    return info == 2 || info == 3 || info == 6 || info == 7;
  }

  int ncards() const {
    if (!info)
      return 0;
    if (two_cards())
      return 2;
    return 1;
  }

  int nways() const {
    if (!info)
      return 0;
    if (info == 18 || (info >= 1 && info <= 3))
      return 1;
    return 2;
  }

  //  Number of cards in deck which make our draw
  int nouts() const { return info >= 4 && info <= 7 ? 8 : 4; }

  //  estimate of P(win | draw comes in)
  double pwin(int noppo = -1) const;
};

struct Flush_info
{
  Flush_info() : info(0), suit(-1), rank(-1), made(false) { }

 /*
  *  0: nothing
  *  12: 4-flush using 1 hole card, no ace
  *  13: 4-flush using 1 hole card, with ace
  *  14: 4-flush using 2 hole cards, no ace
  *  15: 4-flush using 2 hole cards, with ace
  *
  *  If we have a made flush, info will be 0
  *
  *  'ace' means the highest ranking card in the suit not on the board
  *  (i.e. so the flush is the nut) 4 really does mean 4.
  */
  int info;

  //  If we have a made flush or a draw, this gives the suit
  int suit;

  //  If we have a made flush or draw, what is our rank (0 = nut, 1=nut-1, 2=nut-2 etc, 8=worst)
  int rank;

  /*
   *  Referring to the board, how many of each suit are visible, and
   *  what's an ordering of suits which puts the least-represented first?
   */
  int present[4];
  int order[4];

  /*
   *  Referring to our hand, how many cards do we have in each suit.
   */
  int suits[4];

  /*
   *  Do we have a made flush.
   */
  bool made;

  //  The number of hole cards we have in the draw/made suit
  int nholes() const { 
    return suits[suit];
  }

  bool made_nuts() const {
    return made && rank == 0;
  }

  //  max number of cards in any suit
  int max() const {
    return present[order[3]];
  }

  //  the suit with the most board cards present
  int max_suit() const {
    return order[3];
  }
};

struct Strflush_info
{
  Strflush_info() : info(0), suit(0), nuts(false), si() { }

  /*
   *  0  nothing
   *  19  draw to straight flush using 1 hole card
   *  20  draw to straight flush using 2 hole card
   */
  int info;
  int suit; // which suit is involved
  bool nuts; // Are all our draws to nuts?

  //  Info about the straights using just the board/hole cards in the relevant suit
  Straight_info si;

  int nholes() const {
    if (info == 19)
      return 1;
    if (info == 20)
      return 2;
    return 0;
  }

  bool made() const {
    return si.made;
  }
};

/*
 *  Information about pairs/trips/quads & high cards between our hand and the board.
 *  Useful for assessing what kind of made hand we currently have.
 */
struct Rank_info
{
  Rank_info(Card board[5], int cards, Hole hole);

  //  return rank of highest card on board which isn't paired by another board card
  int get_highest_odd_card(Card board[5], int ncards) const ;
  int get_lowest_odd_card(Card board[5], int ncards) const ;
  int get_lowest_non_odd_card(Card board[5], int ncards) const ;

  //  return the number of higher board cards which aren't mathced by another board card
  int n_higher_odd_cards(Card board[5], int ncards, int rank) const ;
  int n_higher_cards(Card board[5], int ncards, int rank) const ;

  int top_odd_card() const ;

  int counts_board_and_hole(int r) const { return rank_counts[r]; }
  int counts_board(int r)          const { return rank_counts2[r]; }

  int pairs; // here trips don't count as pairs
  int trips; // includes set. 
  int quads;
  int btr;  // board top rank
  int blr;  // board low rank
  int htr;  // hole top rank
  int hlr;  // hole low rank
  bool pocketpair;
  int n_board_ov;  // number of board cards > htr
  int n_board_ov2; // number of board cards > hlr
  int pairrank;    // rank of our top pair if we have one or -1 (trips count as pairs too)
  int tripsrank;   // rank of our top trips if we have one or -1
  int topoddboard;

private:
  //  includes hole cards
  int rank_counts[13];

  //  excludes hole cards
  int rank_counts2[13];
};

/*
 *  To handle straight draws which may have a flush threat
 */
struct Threat_info
{
  Threat_info(Flush_info const &, Straight_info const &, int noppo, int ncards_on_board);

  //  Number of flush cards on the board we're worried about.
  int threat;
  
  //  Rest only defined if threat >= 2

  //  P(some oppo has 2 or 1 card in the threat suit)
  double psomeoppohas2;
  double psomeoppohas1;
  
  //  px_y is P(flush draw beats us with y cards to come and x on the board)
  double p2_1;
  double p3_1;
  double p4_1;
  double p2_2;
  double p3_2;

  //  Overall P(someone has the flush draw, and it comes in)
  double pflushhits_and_we_lose;
};


inline double Straight_info::pwin(int noppo) const
{
  if (!info)
    return 0.0;

  int i = (info == 18 ? 0 : info);

  static double pw[8] = {0.8, 0.99, 0.9, 1.0,
			 0.8, 0.99, 0.9, 1.0};
  
  assert(i >= 0 && i < 8);
  
  return pw[i];
}

inline int Rank_info::get_highest_odd_card(Card board[5], int ncards) const 
{
  int h = -1;

  for (int i=0; i<ncards; i++)
    if (rank_counts2[board[i].rank()] == 1 && board[i].rank() > h)
      h = board[i].rank();

  return h;
}

inline int Rank_info::get_lowest_odd_card(Card board[5], int ncards) const 
{
  int h = 14;

  for (int i=0; i<ncards; i++)
    if (rank_counts2[board[i].rank()] == 1 && board[i].rank() < h)
      h = board[i].rank();

  return h;
}

inline int Rank_info::get_lowest_non_odd_card(Card board[5], int ncards) const 
{
  int h = 14;

  for (int i=0; i<ncards; i++)
    if (rank_counts2[board[i].rank()] >= 2 && board[i].rank() < h)
      h = board[i].rank();

  return h;
}

inline int Rank_info::n_higher_odd_cards(Card board[5], int ncards, int rank) const 
{
  int h = 0;

  for (int i=0; i<ncards; i++)
    if (rank_counts2[board[i].rank()] == 1 && board[i].rank() > rank)
      h++;

  return h;
}

inline int Rank_info::n_higher_cards(Card board[5], int ncards, int rank) const 
{
  int h = 0;

  for (int i=0; i<ncards; i++)
    if (board[i].rank() > rank)
      h++;

  return h;
}

inline int Rank_info::top_odd_card() const 
{
  int h = -1;

  for (int i=0; i<13; i++)
    if (rank_counts2[i] == 1)
      h = i;
  
  return h;
}

#endif
