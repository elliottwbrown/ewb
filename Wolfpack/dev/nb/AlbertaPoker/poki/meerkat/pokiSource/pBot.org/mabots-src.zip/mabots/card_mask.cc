
#include "mapoker.h"

static CardMask get_full_deck();
static Card_mask get_full_deck2();

CardMask full_deck = get_full_deck();
Card_mask Card_mask_full_deck = get_full_deck2();

char* Card_mask::to_str() const
{
  static char buf[52*3];
  
  buf[0] = 0;
  
  for (int i=0; i<52; i++)
    if (StdDeck_CardMask_CARD_IS_SET(cm, i)) {
      strcat(buf, Card(i).to_str());
      strcat(buf, " ");
    }
  return buf;
}

static CardMask get_full_deck()
{
  CardMask cm;
  CardMask_RESET(cm);

  for (int c = 0; c < 52; c++)
    StdDeck_CardMask_SET(cm, c);

  return cm;
}

static Card_mask get_full_deck2()
{
  Card_mask C;
  C.fill();
  return C;
}

void Card_mask::sample_wo_replacement(Card* cards, int ncards, prng & p)
{
  for (int c=0; c<ncards; c++) {
    int idx = sample(p);
    remove(idx);
    cards[c] = Card(idx);
  }
}
