/***************************************************************************
   Copyright (c) 2000:
		 University of Alberta,
		 Deptartment of Computing Science
		 Computer Poker Research Group

		 See "Liscence.txt"
***************************************************************************/

package poker.ai.model;

import poker.*;
import poker.util.*;
import java.util.*;
import java.io.*;

/**
 * A Weight Table of all possible 2-card combinations. (52 choose 2)
 *
 * This table is used to store values associated with any 2-card.
 * hand. 
 *
 * If the values in the table represent the relative probabilities
 * that each hand is held by an opponent, then the handStrength()
 * methods will return the probability that a given hand is at least 
 * as good as the opponent's hand.
 *
 * @author  Aaron Davidson
 * @version 1.3.1
 */
public class WeightTable extends TriangularWeightTable implements Serializable {
	private transient static HandEvaluator he = new HandEvaluator();
	private transient double good = 0;   
	private transient double bad = 0;
	private transient double tied = 0;
    
	private transient Deck 			d = new Deck();
	private transient Card  		n1,n2;
	private transient Randomizer  	rnd = new Randomizer();
	
	/**
	 * Constructor (with entries initialized to 1.0)
	 */
	public WeightTable() {
		super(52,1);
	}

	/**
	 * Constructor (load from file)
	 */
	public WeightTable(String fname) {
	super(fname);
	}

	/**
	 * Constructor
	 * @param start initialize the table to this value.
	 */
	public WeightTable(int start) {
		super(52,start);
	}

	/** 
	 * Set all entries with this card to weights of zero
	 * @param c the card to clear	
	 */
	public void clearCard(Card c) {
		int n = c.getIndex();
		for(int i=0;i<52;i++) if (i!=n) setCell(n,i,0);
	}

	/**
	 * Obtain the weight for a particular 2-card combination.
	 * Card order is irrelevant.
	 * @param c1 the first card
	 * @param c2 the second card
	 * @return the weight for the two cards
	 */
	public double getHandWeight(Card c1, Card c2) {
		return getCell(c1.getIndex(),c2.getIndex());
	}
	
	/**
	 * Obtain the weight for a particular 2-card combination.
	 * @param h the 2-card hand
	 * @return the weight for the two cards
	 */
	public double getHandWeight(Hand h) {
		return getCell(h.getCard(1).getIndex(),h.getCard(2).getIndex());
	}

	/**
	 * Set the weight for a particular 2-card combination.
	 * Card order is irrelevant.
	 * @param c1 the first card
	 * @param c2 the second card
	 * @param val the weight to set
	 */
	public void setHandWeight(Card c1, Card c2, double val) {
		setCell(c1.getIndex(),c2.getIndex(), val);
	}
	
	/**
	 * ReWeight a particular 2-card combination by a given value.
	 * Card order is irrelevant.
	 * @param c1 the first card
	 * @param c2 the second card
	 * @param val the weight to multiply the current weight by
	 */
	public double reWeight(Card c1, Card c2, double val) {
		return super.reWeight(c1.getIndex(),c2.getIndex(), val);
	}


	/****************************** HAND STRENGTH METHODS ******************************/
	
	
	/**
	 * Calculate the strength of the given hand.
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @param h the board cards
	 * @param dk a deck with all known cards removed
	 * @return the hand strength
	 */
	public double handStrength(Card c1, Card c2, Hand h, Deck dk) {
		Hand myHand = new Hand(h);
		Hand xxHand = new Hand(h);
		myHand.addCard(c1);
		myHand.addCard(c2);
			int myRank = HandEvaluator.rankHand(myHand);
		good = bad = tied = 0;
			int j,v;
	  
		// tabulate rank
		for (int i=dk.getTopCardIndex();i<Deck.NUM_CARDS;i++) {
				n1 = dk.getCard(i);
			xxHand.addCard(n1);
			for (j=i+1;j<Deck.NUM_CARDS;j++) {
					n2 = dk.getCard(j);
					xxHand.addCard(n2);
					v = HandEvaluator.compareHands(myRank,xxHand);
					if (v == 1) good += getCell(n1.getIndex(),n2.getIndex());
					else if (v==2) bad += getCell(n1.getIndex(),n2.getIndex());
					else tied += getCell(n1.getIndex(),n2.getIndex());
					xxHand.removeCard();
				}
			xxHand.removeCard();
		}

		return (good+(tied/2))/(good+bad+tied);
	}
	
	/**
	 * Calculate the strength of the given hand.
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @param h the board cards
	 * @return the hand strength
	 */
	public double handStrength(Card c1, Card c2, Hand h) {
		// remove all known cards
		d.reset();
		d.extractCard(c1);
		d.extractCard(c2);
		d.extractHand(h);

		return handStrength(c1,c2,h,d);
	}
	
	/**
	 * Calculates the probability of having 
	 * the best hand against several opponents.
	 * @param c1 hole card 1
	 * @param c2 hole card 2
	 * @param h  the board
	 * @param np the number of active opponents in the hand	 
	 * @return probability of having the best hand.
	 */
	public double handStrength(Card c1, Card c2, Hand h, int np) {
		double HS = handStrength(c1,c2,h);
		double H = HS; 
		for (int j=0;j<(np-1);j++) 
			H *= HS;
		return H;
	}


	/**
	 * Calculate the strength of the given hand.
	 * Use the hand rank cache to speed the calculations up
	 *     (cache is obtained from HandEvaluator.getRanks(Hand))
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @param h the board cards
	 * @param rankCache a cache of hand rankings for the current board
	 * @return the hand strength
	 */
	public double handStrength(Card c1, Card c2, Hand h, int[][] rc) {
		// remove all known cards
		d.reset();
		d.extractCard(c1);
		d.extractCard(c2);
		d.extractHand(h);
		return handStrength(c1,c2,rc,d);
	}

	
	/**
	 * Calculate the strength of the given hand.
	 * Use the rank cache to speed the calculations up.
	 *     (cache is obtained from HandEvaluator.getRanks(Hand))
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @param rankCache a cache of hand rankings for the current board
	 * @return the hand strength
	 */
	public double handStrength(Card c1, Card c2, int[][] rankCache) {
		// remove all known cards
		d.reset();
		d.extractCard(c1);
		d.extractCard(c2);
		return handStrength(c1,c2,rankCache,d);
	}
	
	/**
	 * Calculate the strength of the given hand.
	 * Use the rank cache to speed the calculations up.
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @param rankCache the ranks for all hands against a board
	 *        where rankCache[i][j] = the rank of Card(i) and Card(j)
	 *        the array stores the same values both in [i][j] and [j][i]
	 *        for faster access times.
	 *        (this cache can be obtained from HandEvaluator.getRanks(Hand))
	 * @param the deck with all known cards removed
	 * @return the hand strength
	 */
	public double handStrength(Card c1, Card c2, int[][] rankCache, Deck dk) {
		int myRank = rankCache[c1.getIndex()][c2.getIndex()];
		good = bad = tied = 0;
		int j,opRank;
	  
		for (int i=dk.getTopCardIndex();i<Deck.NUM_CARDS;i++) {
			n1 = dk.getCard(i);
			for (j=i+1;j<Deck.NUM_CARDS;j++) {
				n2 = dk.getCard(j);
				opRank = rankCache[n1.getIndex()][n2.getIndex()];
				if (myRank > opRank) good += getCell(n1.getIndex(),n2.getIndex());
				else if (myRank < opRank) bad += getCell(n1.getIndex(),n2.getIndex());
				else tied += getCell(n1.getIndex(),n2.getIndex());			  	
		   }
		}
		return (good+(tied/2))/(good+bad+tied);
	}

	

	/****************************** HAND STRENGTH CACHING ******************************/

	private transient double[][] hs_cache = new double[52][52];
	private transient Deck	  cd = new Deck();

	/**
	 * Cache all possible hand strengths for the current board.
	 * @param h the current board cards
	 * @param ranks a set of cached hand ranks. If null, ranks will be calculated. 
	 *		    Use <CODE>HandEvaluator.getRanks(Hand)</CODE> to generate the rank array.
	 */
	public void cacheHandStrengths(Hand h, int[][] ranks) {
		int i,j,v,n1,n2;

		if (ranks == null)
			ranks = HandEvaluator.getRanks(h);

		cd.reset();
		d.extractHand(h);

		for (i=cd.getTopCardIndex();i<Deck.NUM_CARDS;i++) {
			n1 = cd.getCard(i).getIndex();
			for (j=i+1;j<Deck.NUM_CARDS;j++) {
				n2 = cd.getCard(j).getIndex();
				hs_cache[n1][n2] = hs_cache[n2][n1] = generateHandStrength(cd.getCard(i),cd.getCard(j),h, ranks);
			}
		}
	}

	/**
	 * Get a cached hand strength.
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @returns the last cached hand strength for this pair of cards
	 */
	public double getHandStrength(Card c1, Card c2) {
		return hs_cache[c1.getIndex()][c2.getIndex()];
	}

	/**
	 * Generate a hand strength using cached hand ranks
	 * @param c1 the first hole card
	 * @param c2 the second hole card
	 * @param h the board cards
	 * @param ranks the rank cache
	 */
	public double generateHandStrength(Card c1, Card c2, Hand h, int[][] ranks) {
		good = bad = tied = 0;
		int i,j,v,v1,v2;
		double myrank = ranks[c1.getIndex()][c2.getIndex()];
		// remove all known cards
		d.reset();
		d.extractCard(c1);
		d.extractCard(c2);
		d.extractHand(h);

		// tabulate rank
		for (i=d.getTopCardIndex();i<Deck.NUM_CARDS;i++) {
			n1 = d.getCard(i);
			v1 = n1.getIndex();
			for (j=i+1;j<Deck.NUM_CARDS;j++) {
				n2 = d.getCard(j);
				v2 = n2.getIndex();
				v = ranks[v1][v2];
				if (myrank > v) good += getCell(v1,v2);
				else if (myrank < v) bad += getCell(v1,v2);
				else tied += getCell(v1,v2);
			}
		}
		return (good+(tied/2))/(good+bad+tied);
	}



	/****************************** PRINTING METHODS ******************************/


	public String toString() {
		StringBuffer s = new StringBuffer();
		Card c1,c2; 
		
			 for (int i=0;i<52;i++) {
					c1 = new Card(i);
					for (int j=0;j<52;j++) {
				if (i > j) {
							c2 = new Card(j);
						s.append(getHandWeight(c1,c2) + "\n");
				} else s.append("0.0\n");
					}
			s.append("\n");
			 }
		return s.toString();
	}


   public String toStringSmall () {
	  StringBuffer s = new StringBuffer();
	  int v;
	  s.append("     2     3     4     5     6     7     8     9     T     J     Q     K     A    (u)\n");
	  for (int i=0;i<13;i++) {
		 s.append(" " + Card.getRankChar(i) + "| ");
		 for (int j=0;j<13;j++) {
			double val = getHandType(i,j,i>j);
			String str = ""+round(val,2);
				s.append(str);
				int l = str.length();
			while (l++ < 6) s.append(" ");
		 }
		 s.append("| "+Card.getRankChar(i)+"\n");
	  }
	  s.append("(s)  2     3     4     5     6     7     8     9     T     J     Q     K     A\n\n");
		return s.toString();
   }

   public double getHandType(Card c1, Card c2) {
	  return getHandType(c1.getRank(), c2.getRank(), c1.getSuit()==c2.getSuit());
   }

   public double getHandType(int i, int j, boolean suited) {
	  double val = 0;
	  if (suited) {
		 for (int su=0;su<4;su++)
			val += getHandWeight(new Card(i,su), new Card(j,su));
		 val /= 4;
	  } else if (i==j) {
		 val += getHandWeight(new Card(i,Card.HEARTS), new Card(j,Card.DIAMONDS));
		 val += getHandWeight(new Card(i,Card.CLUBS), new Card(j,Card.DIAMONDS));
		 val += getHandWeight(new Card(i,Card.SPADES), new Card(j,Card.DIAMONDS));
		 val += getHandWeight(new Card(i,Card.CLUBS), new Card(j,Card.HEARTS));
		 val += getHandWeight(new Card(i,Card.SPADES), new Card(j,Card.HEARTS));
		 val += getHandWeight(new Card(i,Card.CLUBS), new Card(j,Card.SPADES));
		 val /= 6;
	  } else {
		 for (int su1=0;su1<4;su1++)
			for (int su2=0;su2<4;su2++)
			   if (su1 != su2)
				  val += getHandWeight(new Card(i,su1), new Card(j,su2));
		 val /= 12;
	  }
	  return val;
   }

	/****************************** HAND SELECTION ******************************/

	/**
	 * Treating the table as a probability distribution,
	 * choose a hand from the table, given real a value from 0..1.
	 * @param spin a value from 0..1
	 */
	public Hand chooseHand(double spin) {
		double ct = (double)0.0;
		n1 = new Card();
		n2 = new Card();
		spin *= sum();
		for (int i=1;i<52;i++) {
			n1.setIndex(i);
			for (int j=0;j<i;j++) {
				n2.setIndex(j);
				ct += getHandWeight(n1,n2);
				if (spin < ct) {
					Hand h = new Hand();
					h.addCard(n1);
					h.addCard(n2);
					return h;
				}
			} 
		}
		return null;
	}


	/**
	 * Choose a maximum likely hand from the remaining deck,
	 * where the a hand is chosen randomly from the most likely
	 * hands the opponent may have.
	 * note: expects wt to be normalized and scaled to 1
	 * note: chooses from a full deck, however weight table
	 *       should have zeroed entries for impossible hands.
	 */	
	public Hand chooseMaxHand() {	
		Card c1 = new Card();
		Card c2 = new Card();
		
		int n = 0;
		int t = 0;
		
		Vector v = new Vector();
		
		for (int i=0;i<52;i++) {
			c1.setIndex(i);
			for (int j=i+1;j<52;j++) {
				c2.setIndex(j);
				t++;
				if (this.getHandWeight(c1,c2) > 0.90) {
					Hand h = new Hand();
					h.addCard(c1);
					h.addCard(c2);
					v.addElement(h);
					n++;
				}
		   }
		}
		if (v.size() > 0)
			return (Hand)v.elementAt(rnd.randInt(v.size()));
		return  null;
	}


	/**
	 * Given a Deck, choose a hand from the weight table
	 * as if it were a large probability distribution.
	 */
	public Hand chooseHandDist(Deck dk) {
		double spinner=0;
		int spc = 0;	
		Hand holes = null;
		
		while (holes == null) {
			spinner = rnd.nextDouble();
			holes = this.chooseHand(spinner);
			if (holes == null) return null;
			if (dk.findCard(holes.getCard(1)) != -1 && 
			   dk.findCard(holes.getCard(2)) != -1) {
				dk.extractCard(holes.getCard(1));
				dk.extractCard(holes.getCard(2));
			} else holes = null;
			if (spc++ > 500) {
				return null;
			}
		}
		return holes;
	}


	/**
	 * Given a Deck, choose a hand where a spinner 
	 * is below the normalized weight table entry. 
	 */
	public Hand chooseHand(Deck dk) {
		int MAXSPINS = 2000;
		Card c1,c2;
		int spc = 0;
		double wtf,spinner=0;
		Hand holes = null;

		while (spc++ < MAXSPINS) {	
			c1 = dk.extractRandomCard();
			c2 = dk.pickRandomCard();		
				
			wtf = this.getHandWeight(c1,c2);
			
			spinner = rnd.nextDouble();
			
			if ((spinner < wtf)) {
				holes = new Hand();
				holes.addCard(c1);
				holes.addCard(c2);
				dk.extractCard(c2);
				spc = MAXSPINS;
			} else {
				if (spc >= MAXSPINS-1) {
					holes = new Hand();
					holes.addCard(c1);
					holes.addCard(c2);
				} else
					dk.replaceCard(c1);
			}
		}
		return holes;
	}
	




	/****************************** MISC. METHODS ******************************/

	/** 
	 * Creates a generic weight table for a likely distribution 
	 * for players after the flop.
	 */
	public void makeStdWeightTable() {
		Card c1 = new Card();
		Card c2 = new Card();	
		for (int h1=0;h1<51;h1++) {
			c1.setIndex(h1);
			for (int h2=h1+1;h2<52;h2++) {
				c2.setIndex(h2);
				setHandWeight(c1,c2, (0.01 * Hand_Prob(h1, h2)));
			}
		}
	}
	
	private int Hand_Prob(int card1, int card2) {

	/* Table of probabilities of given hands seeing the flop (crude, but
	   good estimates are a hard problem requiring opponent modeling, etc).
	   Integers represent percentages (nine-handed is assumed).
	   high-low is   suited (eg. [12][11] = AKs)
	   low-high is unsuited (eg. [11][12] = AK ) */

		int[][] probtable  = {
			{ 70,  10,   1,   1,   1,   1,   1,   1,   1,   1,   1,  10,  50},
			{ 50,  70,  10,   1,   1,   1,   1,   1,   1,   1,   1,  10,  50},
			{ 20,  60,  70,  10,   1,   1,   1,   1,   1,   1,   1,  10,  60},
			{ 20,  20,  70,  70,  10,   1,   1,   1,   1,   1,   1,  10,  60},
			{ 10,  10,  20,  70,  70,  10,   1,   1,   1,   1,   1,  10,  70},
			{ 10,  10,  10,  30,  70,  70,  20,  10,   1,   1,  10,  20,  70},
			{ 10,  10,  10,  10,  30,  70,  70,  60,  30,  20,  30,  40,  80},
			{ 10,  10,  10,  10,  20,  30,  80,  80,  60,  60,  60,  60,  80},
			{ 20,  20,  20,  20,  20,  30,  40,  90,  90,  90,  90,  90,  90},
			{ 20,  20,  20,  20,  20,  30,  50,  80, 100, 100,  90,  90,  90},
			{ 50,  50,  50,  50,  60,  60,  70,  80, 100, 100, 100,  90, 100},
			{ 70,  70,  70,  70,  80,  80,  80,  80, 100, 100, 100, 100, 100},
			{ 90,  90,  90,  90,  90,  90,  90,  90, 100, 100, 100, 100, 100}
		};
			/* 0    1    2    3    4    5    6    7    8    9   10   11   12
			   2    3    4    5    6    7    8    9    T    J    Q    K    A */
		int rank1, rank2, swaptemp, handprob;
		rank1 = card1 % 13;
		rank2 = card2 % 13;
		if (rank1 < rank2) {
		   swaptemp = rank1;
		   rank1 = rank2;
		   rank2 = swaptemp; 
		}
		if ((card1 / 13) == (card2 / 13)) {
		   handprob = probtable[rank1][rank2];}
		else { handprob = probtable[rank2][rank1];}
		return(handprob);
	}
	
	private static double round(double f, int precision) {
		double n = 1;
		for (int i=0;i<precision;i++) n*=10;
		return java.lang.Math.round(f*n)/n;
	}

}


 
