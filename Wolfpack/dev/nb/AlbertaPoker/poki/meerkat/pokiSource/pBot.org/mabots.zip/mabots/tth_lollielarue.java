
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_lollielarue extends wrapper implements Player
{
    public tth_lollielarue() 
    { 
	super("tth:lollielarue"); 
    }
}
