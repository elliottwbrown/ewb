/***************************************************************************
   Copyright (c) 2000:
		 University of Alberta,
		 Deptartment of Computing Science
		 Computer Poker Research Group

		 See "Liscence.txt"
***************************************************************************/
package poker.ai;

import poker.*;
import poker.util.*;

/**
 * The Probabiltiy Triple Generator.
 * Stores a probability distribution for three parts for fold, call and raise.
 *
 * @author  Aaron Davidson
 * @version 1.2.3
 */

public class ProbTriple {
	private static Randomizer rnd = new Randomizer();
	private double	pf,pc,pr;
	
	/**
	 * Default constructor. Values all zero.
	 */
	public ProbTriple() {}
	
	/**
	 * Construct with the values given.
	 * @param f fold prob
	 * @param c call prob
	 * @param r raise prob	 	 
	 */
	public ProbTriple(double f, double c, double r) {
		pf = f;
		pc = c;
		pr = r;
	}

	/**
	 * Set the values given.
	 * @param f fold prob
	 * @param c call prob
	 * @param r raise prob	 	 
	 */
	public void set(double f, double c, double r) {
		pf = f;
		pc = c;
		pr = r;
	}

	public double getFold() { return pf; }
	public double getCall() { return pc; }
	public double getRaise() { return pr; }

	/**
	 * Get the probability for an action
	 * @param action FOLD/CALL/RAISE
	 * @return the appropriate probability of that action
	 */
	public double getValue(int action) {
		switch (action) {
			case Holdem.FOLD: return (double)pf;
			case Holdem.CALL: return (double)pc;
			case Holdem.RAISE: return (double)pr;
			default: return 0;
		}
	}

	/**
	 * Normalize the values in the triple to sum to 1.0
	 */
	public void normalize() {
		double t = (pf+pc+pr);
		pf = pf/t;
		pc = pc/t;
		pr = pr/t;		
	}

	public boolean valid() {
		double t = pf+pc+pr;      
		return (t>0.99999 && t<1.00001);
	}

	
	/**
	 * Add the values of one triple into this one.
	 */	
	public  void add(ProbTriple pt) {
		this.pf = this.pf + pt.getFold();
		this.pc = this.pc + pt.getCall();
		this.pr = this.pr + pt.getRaise();
	}


	/**
	 * Add the values of one triple into this one.
	 */	
	public void dotProduct(ProbTriple pt) {
		pf *= pt.pf;
		pc *= pt.pc;
		pr *= pt.pr;				
	}
	
	/**
	 * Multiply all entries by a constant.
	 * @param val to multiply the values.
	 */
	public void weight(double val) {
		pf *= val;
		pc *= val;
		pr *= val;
	}

	public void setFold(double f) { this.pf = f; }
	public void setCall(double c) { this.pc = c; }
	public void setRaise(double r) { this.pr = r; }

	/**
	 * Select an action from the triple distribution.
	 * @param spin a random value indexing into the triple.
	 * @param useMax take one of the maximum values in the triple.
	 */
	public int select(double spin, boolean useMax) {
		if (useMax) return selectMax(spin);
		return select(spin);
	}

	/**
	 * Select an action from the triple using the given spinner.
	 * @param spin A random number between 0 and 1
	 */
	public int select(double spin) {
			if (spin < pf) return Holdem.FOLD;
				else if (spin < pf+pc) 
			return Holdem.CALL;
				else 
			return Holdem.RAISE;
	}
	
	
	/**
	 * Select the maximum value.
	 * @param spin A random number between 0 and 1	 
	 */
	public int selectMax(double spin) {
		if (pf > pc && pf > pr) return Holdem.FOLD;
		if (pc > pf && pc > pr) return Holdem.CALL;
		if (pr > pf && pr > pc) return Holdem.RAISE;
		if (pr > pf && pr == pc) return (spin > 0.5 ? Holdem.CALL : Holdem.RAISE);
		if (pc > pr && pc == pf) return (spin > 0.5 ? Holdem.FOLD : Holdem.CALL);
		if (pr > pc && pr == pf) return (spin > 0.5 ? Holdem.FOLD : Holdem.RAISE);
		return Holdem.CALL;
	}
	
	/**
	 * Select the maximum value.
	 */
	public int selectMax() {
		return selectMax(rnd.nextDouble());
	}

	/**
	 * Randomly select an action from the triple.
	 */
	public int select() {
		return select(rnd.nextDouble());
	}

	public String toString() {
		return new String("{"+round((double)pf,3)+", "+round((double)pc,3)+", "+round((double)pr,3)+"}");
	}

	private static double round(double f, int precision) {
		double n = 1;
		for (int i=0;i<precision;i++) n*=10;
		return java.lang.Math.round(f*n)/n;
	}




}
