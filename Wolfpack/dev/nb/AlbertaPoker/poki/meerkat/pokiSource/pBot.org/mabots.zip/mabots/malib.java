/*
 *  Class to load mabots.dll and interface with it.  This class must
 *  be loaded by the System ClassLoader to avoid "DLL is already
 *  loaded by another ClassLoader" errors, so it must go in the
 *  lib/ext directory.
 *
 *  We must then avoid using anything from meerkat-api.jar (unless we 
 *  load it up in its own ClassLoader), due to name conflicts.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */

import java.lang.*;

public class malib
{
    static {
	System.loadLibrary("mabots");
    }

    public static native int new_bot(String name);
    public static native void delete_bot(int ref);
    public static native void set_verbose(int ref, int level);

    public static native void do_new_game(int ref, 
					   int smallblind, int bigblind,
					   int smallbet, int bigbet,
					   boolean headsup, 
					   String[] players,
					   int[] starting_chips,
					   boolean[] allin,
					   int button,
					   int[] live_blinds,
					   int[] dead_blinds,
					   int ID, int card1_index, int card2_index);
				    
    public static native int  get_action(int ref);
    public static native void do_action_event(int ref, int pos, int action, int amount, boolean use_allin_rules);
    public static native void do_showdown_event(int ref, int pos, int c1, int c2);
    public static native void set_flop(int ref, int c1, int c2, int c3);
    public static native void set_turn_river(int ref, boolean is_river, int c);
    public static native void do_game_over_event(int ref);
};
