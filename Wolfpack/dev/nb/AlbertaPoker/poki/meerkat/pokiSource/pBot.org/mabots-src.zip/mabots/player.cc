
#include "mapoker.h"

Player::~Player()
{
}

void Player::start_game(Holdem const &, int seat)
{
}
  
void Player::pre_update(Holdem const &, int who, int action)
{
}

void Player::post_update(Holdem const &, int who, int action)
{
}

void Player::end_of_game(Holdem const &)
{
}

void Player::flop_cards(Holdem const &)
{
}

void Player::turn_card(Holdem const &)
{
}

void Player::river_card(Holdem const &)
{
}
