
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_redteller extends wrapper implements Player
{
    public tth_redteller() 
    { 
	super("tth:redteller"); 
    }
}
