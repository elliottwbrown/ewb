
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_nicelyjohnson extends wrapper implements Player
{
    public tth_nicelyjohnson() 
    { 
	super("tth:nicelyjohnson"); 
    }
}
