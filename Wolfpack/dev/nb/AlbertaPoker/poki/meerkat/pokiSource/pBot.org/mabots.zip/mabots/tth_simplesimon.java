
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_simplesimon extends wrapper implements Player
{
    public tth_simplesimon() 
    { 
	super("tth:simplesimon"); 
    }
}
