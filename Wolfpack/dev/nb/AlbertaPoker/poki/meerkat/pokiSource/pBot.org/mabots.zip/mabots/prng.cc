
#include "mapoker.h"

static struct prng current;
struct prng* prng_current = &current;

void prng_init(unsigned seed)
{
  prng_current->seed(seed);
}

#ifdef PRNG_MAIN

int main()
{
#if 0
  //  prng_init(time(NULL));
  prng_init(3);

  for (int i=0; i<1*25*1024*1024; i++) {
    unsigned u = prng_sample();
    fwrite(&u, 4, 1, stdout);
  } 
#endif

  prng p;
  p.seed(3);
  for (int i=0; i<1*25*1024*1024; i++) {
    unsigned u = p.sample();
    fwrite(&u, 4, 1, stdout);
  } 
}

#endif
