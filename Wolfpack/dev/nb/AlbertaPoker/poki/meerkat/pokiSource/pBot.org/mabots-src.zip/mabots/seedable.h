// -*- c++ -*-
#ifndef SEEDABLE_H
#define SEEDABLE_H

struct Seedable
{
  Seedable() : p() { }
  Seedable(const char* str) : seeded(false), seed_str(XSTRDUP(str))  { }
  bool get_seeded() const                                            { return seeded; }
  void set_seed(unsigned u)                                          { p.seed(u, seed_str); seeded = true; }

protected:
  prng p;
  unsigned seed;
  bool seeded;
  const char* seed_str;
};

struct Seedable_fast
{
  Seedable_fast() : p() { }
  Seedable_fast(const char* str) : seeded(false), seed_str(XSTRDUP(str))  { }
  bool get_seeded() const                                            { return seeded; }
  void set_seed(unsigned u)                                          { p.seed(u, seed_str); seeded = true; }

protected:
  prng_fast p;
  unsigned seed;
  bool seeded;
  const char* seed_str;
};

#endif
