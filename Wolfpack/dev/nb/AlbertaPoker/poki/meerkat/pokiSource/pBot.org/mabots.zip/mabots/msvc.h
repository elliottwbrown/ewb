
#ifndef MSVC_H
#define MSVC_H
// MAPOKER

#include <direct.h>
#include <limits>

#ifdef __cplusplus
extern "C" {
#endif

char* index(char* str, char c);
int finite(double c);
double drand48();

#undef min
#undef max

  //  long names in debug info
#pragma warning(disable:4786)

#define MKDIR(path,mode) _mkdir(path)
#define __PRETTY_FUNCTION__ __FILE__

#ifdef MAKEMAPOKERDLL
#define MAPOKERATTR __declspec(dllexport)
#else
  //  forget the DLL for the moment - I don't know how much needs exporting
  //#define MAPOKERATTR __declspec(dllimport)
#define MAPOKERATTR
#endif
  
#ifdef __cplusplus
}
#endif

#endif
