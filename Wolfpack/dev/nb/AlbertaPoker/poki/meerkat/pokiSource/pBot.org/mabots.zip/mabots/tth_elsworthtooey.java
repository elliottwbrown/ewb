
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_elsworthtooey extends wrapper implements Player
{
    public tth_elsworthtooey() 
    { 
	super("tth:elsworthtooey"); 
    }
}
