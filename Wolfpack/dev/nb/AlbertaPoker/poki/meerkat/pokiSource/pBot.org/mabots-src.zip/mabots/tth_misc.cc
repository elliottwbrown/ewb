
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "tth_misc.h"
#include "tth_profile.h"

static int parse_int(const char* str)
{
  int i;
  if (sscanf(str, "%i", &i) != 1) {
    fprintf(stderr, "Expected int, read '%s'\n", str);
    abort();
  }
  return i;
}

void parse_bv(Tth_bet_variable& bv, const char* str)
{
  assert(strlen(str) == 2);

  //  deal with specials first
  if (!strcmp(str, "X1")) bv.style = BV_X1;
  else if (!strcmp(str, "X2")) bv.style = BV_X2;
  else if (!strcmp(str, "CR")) bv.style = BV_CR;
  else if (!strcmp(str, "CA")) bv.style = BV_CA;
  else if (!strcmp(str, "CX")) bv.style = BV_CX;
  else if (!strcmp(str, "CC")) bv.style = BV_CC;
  else if (!strcmp(str, "DR")) bv.style = BV_DR;
  else if (!strcmp(str, "HU")) bv.style = BV_HU;
  else if (!strcmp(str, "PN")) bv.style = BV_PN;
  else if (!strcmp(str, "BN")) bv.style = BV_BN;
  else if (!strcmp(str, "RN")) bv.style = BV_RN;
  else if (!strcmp(str, "bn")) bv.style = BV_bn;
  else if (!strcmp(str, "rn")) bv.style = BV_rn;
  else if (!strcmp(str, "x1")) bv.style = BV_x1;
  else if (!strcmp(str, "x2")) bv.style = BV_x2;
  else {
    switch (str[0]) {
    case 'P': bv.style = BV_P_; break;
    case 'B': bv.style = BV_B_; break;
    case 'b': bv.style = BV_b_; break;
    case 'R': bv.style = BV_R_; break;
    case 'r': bv.style = BV_r_; break;
    case 'S': bv.style = BV_S_; break;
    case 's': bv.style = BV_s_; break;
    case 'A': bv.style = BV_A_; break;
    case 'a': bv.style = BV_a_; break;
    case '-': bv.style = BV_UN; return;
    default:
      assert(!"Unknown bet variable style");
    }

    bv.max_commit = parse_int(&str[1]);
  }
}

Tth_bet_variable Tth_bet_variable::make(const char* str)
{
  Tth_bet_variable bv;
  parse_bv(bv, str);
  return bv;
}

const char* Tth_bet_variable::to_str() const
{
  static char buf[10];

  switch (style) {
  case BV_UN: return "??";

  case BV_X1: return "X1";
  case BV_X2: return "X2";
  case BV_CR: return "CR";
  case BV_CA: return "CA";
  case BV_CC: return "CC";
  case BV_CX: return "CX";
  case BV_DR: return "DR";
  case BV_HU: return "HU";
  case BV_PN: return "PN";
  case BV_BN: return "BN";
  case BV_RN: return "RN";
  case BV_bn: return "bn";
  case BV_rn: return "rn";
  case BV_x1: return "x1";
  case BV_x2: return "x2";

  case BV_P_: sprintf(buf, "P%i", max_commit); break;
  case BV_B_: sprintf(buf, "B%i", max_commit); break;
  case BV_b_: sprintf(buf, "b%i", max_commit); break;
  case BV_R_: sprintf(buf, "R%i", max_commit); break;
  case BV_r_: sprintf(buf, "r%i", max_commit); break;
  case BV_S_: sprintf(buf, "S%i", max_commit); break;
  case BV_s_: sprintf(buf, "s%i", max_commit); break;
  case BV_A_: sprintf(buf, "A%i", max_commit); break;
  case BV_a_: sprintf(buf, "a%i", max_commit); break;
  default:
    assert(!"Internal error");
  }

  return buf;
}
