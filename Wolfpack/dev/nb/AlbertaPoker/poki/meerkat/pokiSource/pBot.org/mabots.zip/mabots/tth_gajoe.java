
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_gajoe extends wrapper implements Player
{
    public tth_gajoe() 
    { 
	super("tth:g.a.joe"); 
    }
}
