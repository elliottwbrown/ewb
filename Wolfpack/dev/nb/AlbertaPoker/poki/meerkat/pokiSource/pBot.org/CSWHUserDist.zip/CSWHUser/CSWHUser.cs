using System;
using System.Collections.Generic;
using System.Text;
using System.IO;


namespace CSWHUser
{
    public class CSWHUser : WHUser.WHUserProxy
    {
        public CSWHUser() { }

        public override double ProcessQuery(string message)
        {
            double returnValue = base.WinHoldem_Symbol("prwin");
            
            return returnValue;
        }
    }
}
