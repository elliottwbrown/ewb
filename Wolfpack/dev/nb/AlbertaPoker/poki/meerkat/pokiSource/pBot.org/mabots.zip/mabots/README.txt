

INTRODUCTION
------------

This package contains versions of the poker bots from Turbo Texas Holdem
('TTH') wrapped up in the Meerkat Poker API, which lets them be plugged
into Poki's Poker Academy ('PPA').

TTH (www.wilsonsoftware.com) is a holdem trainer which aims to provide
a wide range of opponents reflecting the idiosyncracies of typical
poker players.  One nice feature of TTH is that it allows simulations
to be performed against the bots using a user-definable profile to
specify how each decision during the play of the hand should be made.

PPA (www.poki-poker.com) is similar, but based on research from the
University of Alberta (http://www.cs.ualberta.ca/~games/poker/).  At
full ring games, the best PPA bots are generally considered stronger
players than the best of the TTH bots, but are less varied in their
style of play.  They are also considerably slower than the TTH bots.
The special PPA bot for heads-up play (sparbot) is vastly stronger
than any of the TTH bots at heads-up.

The code in this package implements the TTH bots as plug-ins for PPA.
It is based on the documentation from the freely downloadable demo
version of TTH. Some aspects of their play is only hinted at in the
docs (such as how their play is modified depending on the number of
opponents in the hand), so the bots contained in this package are not
perfect clones of the TTH code.

Details of the peculiarities of the various TTH bots' behaviour can be
found in the TTH documentation that comes with the demo.


INSTALLATION
------------

I assume you already have PPA and have downloaded and installed the
Meerkat API from http://www.poki-poker.com/downloads, needed to
support plugin bots.

The package here contains both source and precompiled binaries.  If
'POKI' denotes the directory where PokiPoker is installed, for example
c:\Program Files\PokiPoker, to install the binaries you need to copy

  mabots.dll to POKI
  mabots.jar to POKI/data/bots
  malib.jar  to POKI/java/lib/ext
  the player definition files (the .pd files) to POKI/data/bots

You should now be able to create new players and specify
'tth_bretmaverick' (for example) as the AI engine.


RECOMPILING 
-----------

You need MSVC 6.0 and a reasonably recent version of the Java SDK.
Edit makefile.vc to set the location of the Java SDK and
meerkat-api.jar then type

	nmake -f makefile.vc

This will build mabots.dll, which contains the bulk of the code, and
malib.jar and mabots.jar which contain some trivial code to interface
with the DLL.


KNOWN BUGS
----------

If the bot seems to be folding without looking at its cards, it's
probably crashed.  Look at bot.error in the data directory.  If it has
crashed, please send me the details of the hand it crashed on (just
copy the hand log from the PPA window), together with bot.error and
bot.output .

Long standing internal bug with split pots in holdem.cc: odd amount
goes to the player to the left of the button, even if they folded.

Pot odd calculations in tth.cc:consider_pot_odds() are rather approximate.

Some 'bet variables' may be defined incorrectly due to gaps in the TTH
documentation (how we play if the board has a full house or quads, or
what does X2 mean if we're not heads-up?).

Some of the 'General Rules' parts of the profile aren't respected.

Other bug reports/fixes welcome.


LICENSE
-------

All the code here is released under the terms of the GNU General
Public license, see LICENSE.txt for details.


ACKNOWLEDGEMENTS
----------------

This package contains code from the pokersource library, available from
http://pokersource.sourceforge.net/.



Marv (marv742@netscape.net)
24 May, 2004

