
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_harrythehorse extends wrapper implements Player
{
    public tth_harrythehorse() 
    { 
	super("tth:harrythehorse"); 
    }
}
