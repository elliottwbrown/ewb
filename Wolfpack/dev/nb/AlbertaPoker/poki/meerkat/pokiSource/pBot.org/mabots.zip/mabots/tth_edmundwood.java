
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_edmundwood extends wrapper implements Player
{
    public tth_edmundwood() 
    { 
	super("tth:edmundwood"); 
    }
}
