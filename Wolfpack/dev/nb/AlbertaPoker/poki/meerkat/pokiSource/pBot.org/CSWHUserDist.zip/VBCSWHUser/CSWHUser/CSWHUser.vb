Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.IO


Public Class CSWHUser
    Inherits WHUser.WHUserProxy
  

    Public Sub New()

    End Sub

    Public Sub CSWHUser()

    End Sub

    Public Overrides Function ProcessQuery(ByVal message As String) As Double
        
    End Function

    

End Class




