/*
 *  Class to load mabots.dll and interface with it.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 */

public class malib
{
    static {
    	//System.out.println(System.getProperty("java.library.path"));
    	try {
    		System.loadLibrary("mabots");
   	} catch (Exception e) {
   		e.printStackTrace();
   	}
    }

    public static native int new_bot(String name);
    public static native void delete_bot(int ref);
    public static native void set_verbose(int ref, int level);

    public static native void do_new_game(int ref, 
					   int smallblind, int bigblind,
					   int smallbet, int bigbet,
					   boolean headsup, 
					   String[] players,
					   int[] starting_chips,
					   boolean[] allin,
					   int button,
					   int[] live_blinds,
					   int[] dead_blinds,
					   int ID, int card1_index, int card2_index);
				    
    public static native int  get_action(int ref);
    public static native void do_action_event(int ref, int pos, int action, int amount, boolean use_allin_rules);
    public static native void do_showdown_event(int ref, int pos, int c1, int c2);
    public static native void set_flop(int ref, int c1, int c2, int c3);
    public static native void set_turn_river(int ref, boolean is_river, int c);
    public static native void do_game_over_event(int ref);
};
