/*
 *  Hand class definition.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */

#include "mapoker.h"

void Hand::print() const
{
  printf("%s", to_str());
}

char* Hand::to_str() const
{
  static char buf[10];
  int j = 0;
  
  memset(buf, 0, sizeof(buf));
  
  if (!known_)
    strcpy(buf, "?? ??");
  else
    for (int i=0; i<52; i++)
      if (StdDeck_CardMask_CARD_IS_SET(cm, i)) {
	strcat(buf, Card(i).to_str());
	j += 2;
	if (j < 5)
	  strcat(buf, " ");
      }

  return buf;
}

Card Hand::card(int j) const
{
  assert(known());
  
  if (j == 0) {
    for (int i=0; i<52; i++)
      if (StdDeck_CardMask_CARD_IS_SET(cm, i))
	return Card(i);
  } else 
    for (int i=51; i>=0; i--)
      if (StdDeck_CardMask_CARD_IS_SET(cm, i))
	return Card(i);

  THROW("internal error");
  return Card(0);
}

Hand::Hand(const char* c)
{
  char buf[3];
  Card cards[2];
  int i;

  while (*c && isspace(*c))
    c++;

  known_ = 0;

  if (sscanf(c, "%2s%n", buf, &i) != 1)
    return;
  c += i;
  cards[0] = Card(buf);

  if (sscanf(c, "%2s%n", buf, &i) != 1)
    assert(!"Internal error in Hand::Hand()");
  c += i;
  cards[1] = Card(buf);

  *this = Hand(cards[0], cards[1]);
}
