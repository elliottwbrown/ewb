
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_senatorsnort extends wrapper implements Player
{
    public tth_senatorsnort() 
    { 
	super("tth:senatorsnort"); 
    }
}
