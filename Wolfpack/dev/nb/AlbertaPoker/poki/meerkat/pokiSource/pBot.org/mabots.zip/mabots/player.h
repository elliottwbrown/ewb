// -*- c++ -*-
/*
 *  mapoker's Player interface.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#ifndef PLAYER_H
#define PLAYER_H


//  Just worry about limit holdem for the moment
//  strategy.h assumes these are <= 9
#define PLAYER_FOLD_CHECK 0
#define PLAYER_FOLD       0
#define PLAYER_CALL       1
#define PLAYER_RAISE      2
#define PLAYER_NACTIONS   3

/*
 *  Default implementation does nothing.
 */
struct Player
{
  virtual ~Player();

  virtual const char* get_name() const = 0;

  //  Called after everything but the first action is known & before the pre_update hooks
  //  i.e. just after set_predeal
  //  seat < 0 if I'm observing
  virtual void start_game(Holdem const &, int seat);

  //  Called immediately after card is dealt
  virtual void flop_cards(Holdem const &);
  virtual void turn_card(Holdem const &);
  virtual void river_card(Holdem const &);
  
  //  Here action is 0=fold 1=check/call 2=bet/raise.
  //  Whether or not this is an allin action can't be specified here.

  //  Holdem may or may not have oppo hole cards.
  virtual int get_action(Holdem const &) = 0;
  
  //  Called immediately before & after the game state is modified by the dealer.
  virtual void pre_update (Holdem const &, int who, int action);
  virtual void post_update(Holdem const &, int who, int action);

  //  Called after the end of the game
  virtual void end_of_game(Holdem const &);

  virtual void set_seed(unsigned) { }
};

struct Always_fold : public Player
{
  const char* get_name() const { return "fold"; }
  int get_action(Holdem const &) { return PLAYER_FOLD_CHECK; }
};

struct Always_call : public Player
{
  const char* get_name() const { return "call"; }
  int get_action(Holdem const &) { return PLAYER_CALL; }
};

struct Always_raise : public Player
{
  const char* get_name() const { return "raise"; }
  int get_action(Holdem const &) { return PLAYER_RAISE; }
};

struct Random_player : public Player
{
  Random_player(double fold_prob = 0.45, double raise_prob = 0.15) 
    : pf(fold_prob), pr(raise_prob) 
  { 
    name = (char*)XMALLOC(100);
    sprintf(name, "random(FOLD=%g,RAISE=%g)", pf, pr); 
  }

  ~Random_player() { }

  const char* get_name() const { return name; }

  int get_action(Holdem const &) { 
    double s = prng_sample_u();
    if (s<pf)
      return PLAYER_FOLD_CHECK; 
    else if (s<(1-pr))
      return PLAYER_CALL;
    return PLAYER_RAISE;
  }

  double pf;
  double pr;
  char* name;
};

#endif
