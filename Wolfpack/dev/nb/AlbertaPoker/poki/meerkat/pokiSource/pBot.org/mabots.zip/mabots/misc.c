
#include "misc.h"
#if defined(__MINGW32__) || defined(MSVC)
#include "vsnprintf.h"
#endif



#ifdef O_FAST_ALLOC
static void* get(int n)
{
  static unsigned char* block = 0;
  unsigned char* n2;

#ifdef FAST_ALLOC_TEST
  static int total = 0;
  static int mark = 0;

  total += 8*(1+n/8);
  if (total > mark) {
    printf(QSTR("Using %i bytes\n"), total);
    mark += 1024*1204;
  }
  return calloc(1, n);
#endif

  if (!block) 
    block = calloc(1024,1024*FAST_ALLOC_SIZE);

  n = 8*(1+n/8);

  n2 = block;
  block += n;

  return (void*) n2;
}
#endif


void* xmalloc(size_t size)
{
  void* ans;
  
#ifdef O_FAST_ALLOC
  return get(size);
#endif

  ans = malloc(size);
  if (!ans)
    die("Out of memory\n");
  return ans;
}


void* xcalloc(size_t nmemb, size_t size)
{
  void* ans;

#ifdef O_FAST_ALLOC
  return get(size*nmemb);
#endif

  ans = calloc(nmemb, size);
  if (!ans)
    die("Out of memory\n");
  return ans;
}


void* xrealloc(void* ptr, size_t size)
{
  void* p = realloc(ptr, size);
  if (size && !p)
    die("Out of memory\n");
  return p;
}


/* pinched from the man pages and modified a bit */
char *
stringit(const char *fmt, ...) 
{
  /* Guess we need no more than 100 bytes. */
  int n, size = 100;
  va_list ap;
  static char *p=0;

  if (p)
    FREE(p);

  if ((p = MALLOC(size)) == NULL)
    return NULL;
  while (1) {
    /* Try to print in the allocated space. */
    va_start(ap, fmt);
    n = vsnprintf (p, size, fmt, ap);
    va_end(ap);

#ifdef WIN32
    /*  our non-standard vsnprintf (in snprint.c) just returns strlen(p) */
    if (n < size-1)
      break;
    else
      size *= 2;
#else

    /* If that worked, return the string. */
    if (n > -1 && n < size)
      break;

    /* Else try again with more space. */
    if (n > -1)    /* glibc 2.1 */
      size = n+1; /* precisely what is needed */
    else           /* glibc 2.0 */
      size *= 2;  /* twice the old size */

#endif

    if ((p = REALLOC(p, size)) == NULL)
      return NULL;
  }
  return p; 
}


char* print_args(const char *fmt, va_list ap) 
{
  /* Guess we need no more than 100 bytes. */
  int n, size = 100;
  char *p=0;

  fflush(0);

  if ((p = MALLOC(size)) == NULL)
    return "Out of memory forming error string";

  while (1) {
    /* Try to print in the allocated space. */
    n = vsnprintf (p, size, fmt, ap);

#ifdef WIN32
    /*  our non-standard vsnprintf (in snprint.c) just returns strlen(p) */
    if (n < size-1)
      break;
    else
      size *= 2;
#else

    /* If that worked, return the string. */
    if (n > -1 && n < size)
      break;
    /* Else try again with more space. */
    if (n > -1)    /* glibc 2.1 */
      size = n+1; /* precisely what is needed */
    else           /* glibc 2.0 */
      size *= 2;  /* twice the old size */
#endif

    if ((p = REALLOC(p, size)) == NULL)
      return "Out of memory forming error string";
  }
  return p;
}

void vdie(const char* fmt, va_list ap)
{
  /* Guess we need no more than 100 bytes. */
  int n, size = 100;
  char *p=0;

  fflush(0);

  if ((p = MALLOC(size)) == NULL)
    goto mem_error;

  while (1) {
    /* Try to print in the allocated space. */
    n = vsnprintf (p, size, fmt, ap);

#ifdef WIN32
    /*  our non-standard vsnprintf (in snprint.c) just returns strlen(p) */
    if (n < size-1)
      break;
    else
      size *= 2;
#else

    /* If that worked, return the string. */
    if (n > -1 && n < size)
      break;
    /* Else try again with more space. */
    if (n > -1)    /* glibc 2.1 */
      size = n+1; /* precisely what is needed */
    else           /* glibc 2.0 */
      size *= 2;  /* twice the old size */
#endif

    if ((p = REALLOC(p, size)) == NULL)
      goto mem_error;
  }

  fprintf(stderr,"%s",p);
  if (p[strlen(p)-1] != '\n')
    fprintf(stderr,"\n");

#ifdef ABORT_ON_DIE
  abort();
#endif

  exit(1);

 mem_error:
  fprintf(stderr,"Out of memory forming error string");
  exit(1);  
}

#ifndef NO_DIE
void die(const char *fmt, ...) 
{
  va_list ap;
  va_start(ap, fmt);
  vdie(fmt, ap);
  va_end(ap);
}
#endif

void 
debug_(const char* file,int line,const char* f,const char* msg)
{
  static int i=0; 
  /*
    char buf[100];
    sprintf(buf,"debug %d\n",i++);
    write(0,buf,strlen(buf));
  */
  fflush(0);
  setbuf(stdout,0);
  fprintf(stdout, "debug %i at %s:%i %s: %s\n",i++,file,line,f,msg);
}


void 
stub_(const char* file,int line,const char* f,const char* msg)
{
  /*  static int i=0; */
  fflush(0);
  setbuf(stdout,0);
  /*  fprintf(stderr,"stub %i at %s:%i %s: %s\n",i++,file,line,f,msg); */
  fprintf(stdout, "stub at %s:%i %s: %s\n",file,line,f,msg); 
  /*   fprintf(stderr,"Stub: %s\n",msg); */
}


void 
warn_(const char* file,int line,const char* f,const char* msg)
{
  fflush(0);
  fprintf(stderr, "Warning at %s:%i %s: %s\n",file,line,f,msg); 
}

void 
fatal(const char *fmt, ...) 
{
  va_list ap;
  char* p;

  va_start(ap, fmt);
  p = print_args(fmt, ap);
  va_end(ap);

  fprintf(stderr,"Error: %s", p);
  if (p[strlen(p)-1] != '\n')
    fprintf(stderr,"\n");

#ifdef ABORT_ON_DIE
  abort();
#endif

  exit(1);
}
