
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_johndoe extends wrapper implements Player
{
    public tth_johndoe() 
    { 
	super("tth:johndoe"); 
    }
}
