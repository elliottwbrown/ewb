
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_adv3 extends wrapper implements Player
{
    public tth_adv3() 
    { 
	super("tth:adv3"); 
    }
}
