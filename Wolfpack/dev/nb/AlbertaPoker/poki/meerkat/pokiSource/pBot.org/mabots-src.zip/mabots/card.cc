// -*- c++ -*-

#include "mapoker.h"

Card::Card(const char* a)
  : c(-1)
{
  if (!a || a[0] == '?')
    return;

  while (*a && isspace(*a))
    a++;

  if (strlen(a) < 2)
    THROW("Invalid argument to Card constructor");

  int rank = 0;

  switch (toupper(a[0])) {
  case 'A': rank = 12; break; 
  case 'K': rank = 11; break;  
  case 'Q': rank = 10; break;  
  case 'J': rank = 9; break;  
  case 'T': rank = 8; break;  
  case '9': rank = 7; break;  
  case '8': rank = 6; break;  
  case '7': rank = 5; break;  
  case '6': rank = 4; break;  
  case '5': rank = 3; break; 
  case '4': rank = 2; break;  
  case '3': rank = 1; break;  
  case '2': rank = 0; break; 
  default:
    THROW("Invalid argument to Card constructor");
  }
  
  int suit = 0;
  
  switch (tolower(a[1])) {
  case 'h': suit = 0; break;
  case 'd': suit = 1; break;
  case 'c': suit = 2; break;
  case 's': suit = 3; break;
  default:
    THROW("Invalid argument to Card");
  }

  c = suit*13 + rank;
}

void Card::print() const
{
  printf("%s", to_str());
}

char* Card::to_str() const
{
  char* ranks = "23456789TJQKA";
  char* suits = "hdcs";
  static char buf[3];
  
  memset(buf, 0, sizeof(buf));

  if (c == -1)
    strcpy(buf, "??");
  else
    sprintf(buf, "%c%c", ranks[c % 13], suits[c / 13]);

  return buf;
}
