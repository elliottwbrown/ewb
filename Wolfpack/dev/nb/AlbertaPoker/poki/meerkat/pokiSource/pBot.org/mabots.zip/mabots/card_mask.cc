/*
 *  CardMask class definition.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */

#include "mapoker.h"

static CardMask get_full_deck();
CardMask full_deck = get_full_deck();

char* Card_mask::to_str() const
{
  static char buf[52*3];
  
  buf[0] = 0;
  
  for (int i=0; i<52; i++)
    if (StdDeck_CardMask_CARD_IS_SET(cm, i)) {
      strcat(buf, Card(i).to_str());
      strcat(buf, " ");
    }
  return buf;
}

CardMask get_full_deck()
{
  CardMask cm;
  CardMask_RESET(cm);

  for (int c = 0; c < 52; c++)
    StdDeck_CardMask_SET(cm, c);

  return cm;
}

void Card_mask::sample_wo_replacement(Card* cards, int ncards)
{
  for (int c=0; c<ncards; c++) {
    int idx = sample();
    remove(idx);
    cards[c] = Card(idx);
  }
}
