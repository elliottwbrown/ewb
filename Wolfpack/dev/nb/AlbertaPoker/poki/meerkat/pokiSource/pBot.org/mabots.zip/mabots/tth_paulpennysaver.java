
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_paulpennysaver extends wrapper implements Player
{
    public tth_paulpennysaver() 
    { 
	super("tth:paulpennysaver"); 
    }
}
