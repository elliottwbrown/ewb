// -*- c++ -*-
/*
 *  This needs to be included to parse individual profiles, but
 *  doesn't want to be included in everything.
 */

#ifndef TTH_PROFILE_H
#define TTH_PROFILE_H

//  rank thresholds for preflop tables
#define U 0 /* undefined */
#define T 10
#define J 11
#define Q 12
#define K 13
#define A 14
#define X 15 /* i.e. never */ 

//  preflop position codes
#define SmB 0
#define BgB 1
#define UnG 2
#define Ear 3
#define Mid 4
#define Lat 5
#define But 6

//  postflop position codes
#define postflop_First 0
#define postflop_Mid   1
#define postflop_Last  2

#if 0
// an 'always fold' preflop table
strat_t empty[NPOTSTATUSES*2*NPREFLOPPOSITIONS] =

{{1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X},
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X},

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X},
 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 

 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, 
 {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}, {1.0,X,X}};
#endif

#endif
