// -*- c++ -*-
#ifndef REPORTER_H
#define REPORTER_H


#ifdef NOREPORTING

#define REPORT(x)
#define REPORT2(x,r)
#define REPORTQ(r,x)

#else

//#ifdef HAVE_BOT_H
//#define ACTIVE_BOT(x) x
//#else
//#define ACTIVE_BOT(x)
//#endif

//#define REPORT(x) do { if (active_bot) active_bot->get_reporter().log(__PRETTY_FUNCTION__, x); else printf("%s: %s\n", __PRETTY_FUNCTION__, x); fflush(stdout); } while (0)

//#define REPORT(x) do { ACTIVE_BOT(if (active_bot) active_bot->get_reporter().log(__PRETTY_FUNCTION__, x); else) printf("%s: %s\n", __PRETTY_FUNCTION__, x); fflush(stdout); } while (0)

#ifdef HAVE_BOT_H
#define REPORT(x) do { current_reporter->log(__PRETTY_FUNCTION__, x); fflush(current_reporter->get_fp()); } while (0)
#else
#define REPORT(x) do { printf("%s: %s\n", __PRETTY_FUNCTION__, x); fflush(stdout); } while (0)
#endif

#define REPORT2(r,x) do { (r).log(__PRETTY_FUNCTION__, x); } while (0)
#define REPORTQ2(r,x) do { (r).log(x); } while (0)

#endif

//#define REPORT_FP (active_bot ? active_bot->get_reporter().get_fp() : stdout)
#define REPORT_FP (current_reporter->get_fp())

struct Reporter
{
  Reporter();
  ~Reporter();

  void set_logname(string const & filename);
  Reporter & log(const char* prefix, string const & s);
  Reporter & log(string const & s);
  void set_logging(bool);
  bool get_logging() const { return logging; }
  FILE* get_fp() { return fp; }

private:
  string filename;
  FILE* fp;
  bool logging;

  Reporter & log_(const char* prefix, string const & s);
};

inline Reporter & Reporter::log(const char* prefix, string const & str)
{
  if (!logging)
    return *this;
  
  return log_(prefix, str);
}

inline Reporter & Reporter::log(string const & str)
{
  if (!logging)
    return *this;
  
  return log_(0, str);
}

extern Reporter  default_reporter;
extern Reporter* current_reporter;


#endif
