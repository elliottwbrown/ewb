// -*- c++ -*-
/*
 *  Wrapper around pokersources CardMask
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#ifndef CARD_MASK_H
#define CARD_MASK_H

struct Card_mask;

MAPOKERATTR extern CardMask full_deck;
MAPOKERATTR extern Card_mask Card_mask_full_deck;

struct Card_mask
{
  Card_mask()                                   { CardMask_RESET(cm); } 
  Card_mask(Card const & c)                     { CardMask_RESET(cm); assert(c.known()); CardMask_SET(cm, c.c); } 
  Card_mask(int i)                              { CardMask_RESET(cm); CardMask_SET(cm, i); } 
  Card_mask(Hand const & h)                     { CardMask_RESET(cm); assert(h.known()); cm = h.cm; }
  Card_mask(Hole const & h)                     { cm = card_mask_table[h.h].cm; }
  Card_mask(Card const * crds, int ncards)
  {
    CardMask_RESET(cm);
    for (int c=0; c<ncards; c++)
      add(crds[c]);
  }

  void empty()                                  { CardMask_RESET(cm); }
  bool overlaps(Card_mask const & c) const      { return CardMask_ANY_SET(cm, c.cm); }
  bool overlaps(Card const & c) const           { assert(c.known()); return CardMask_CARD_IS_SET(cm, c.c); }
  Card_mask & add(Card_mask const & c)          { CardMask_OR(cm, cm, c.cm); return *this; }
  Card_mask & add(const char* str)              { return add(Card_mask(Card(str))); }
  Card_mask & remove(Card_mask const & c);
  int sample_other() const;                     // sample from one of the other cards in the deck
  int sample() const;                           // sample one of these cards
  int sample(prng &) const;                     
  int sample(prng_fast &) const;                
  void sample_wo_replacement(Card* cards, int ncards, prng & p = *prng_current);
  bool card_is_set(int c) const                 { return CardMask_CARD_IS_SET(cm, c); }

  bool operator==(Card_mask const & c) const    { return cm.cards_n == c.cm.cards_n; }

  //  Get the cards in a particular suit
  unsigned clubs() const                        { return CardMask_CLUBS(cm); }
  unsigned diamonds() const                     { return CardMask_DIAMONDS(cm); }
  unsigned hearts() const                       { return CardMask_HEARTS(cm); }
  unsigned spades() const                       { return CardMask_SPADES(cm); }

  unsigned suit(int n) const 
  {
    switch (n) {
    case Suit_HEARTS:   return CardMask_HEARTS(cm);
    case Suit_DIAMONDS: return CardMask_DIAMONDS(cm);
    case Suit_CLUBS:    return CardMask_CLUBS(cm);
    case Suit_SPADES:   return CardMask_SPADES(cm);
    }
    assert(!"Internal error");
    return 0;
  }

  char* to_str() const; // return pointer to static data
  unsigned size() const;
  Card_mask & fill();   // set this to the 52 cards

  CardMask cm;
};

inline int Card_mask::sample_other() const
{
  int idx;
  do {
    idx = prng_sample() % 52;
  } while (CardMask_CARD_IS_SET(cm, idx));

  return idx;
}

inline int Card_mask::sample() const
{
  int idx;
  do {
    idx = prng_sample() % 52;
  } while (!CardMask_CARD_IS_SET(cm, idx));

  return idx;
}

inline int Card_mask::sample(prng & p) const
{
  int idx;
  do {
    idx = p.sample() % 52;
  } while (!CardMask_CARD_IS_SET(cm, idx));

  return idx;
}

inline int Card_mask::sample(prng_fast & p) const
{
  int idx;
  do {
    idx = p.sample() % 52;
  } while (!CardMask_CARD_IS_SET(cm, idx));

  return idx;
}

inline unsigned Card_mask::size() const
{
  unsigned total=0;
  for (int c=0; c<52; c++)
    if (CardMask_CARD_IS_SET(cm, c))
      total++;
  return total;
}

inline Card_mask & Card_mask::fill() 
{
  cm = full_deck;
  return *this;
}

inline Card_mask & Card_mask::remove(Card_mask const & c)
{ 
  CardMask m = c.cm; 
  CardMask_NOT(m, m); 
  CardMask_AND(cm, cm, m); 
  return *this; 
}

#endif
