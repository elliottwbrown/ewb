
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_test extends wrapper implements Player
{
    public tth_test() 
    { 
	super("tth:test"); 
    }
}
