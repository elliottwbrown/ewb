// -*- c++ -*-
#ifndef CARD_H
#define CARD_H

class Holdem;

//  ranks (TWO = 0 ... ACE = 12)
#define ACE   12
#define KING  11
#define QUEEN 10
#define JACK  9
#define TEN   8
#define NINE  7
#define EIGHT 6
#define SEVEN 5

//  maybe 'unknown'
struct Card 
{
  Card(const char*);       /*  {A,K,Q,J,T,9,8,7,6,5,4,3,2}{c,d,h,s} NULL or ? ?? for unkown */
  Card()                   { c = -1; }

  //  Order: 2h..Ah 2d..2c..2s..As  (HDCS)
  Card(int index)          { c = index; }

  Card(unsigned suit, unsigned rank) { assert(rank<13 && suit<4); c = rank + suit*13; }
  void set_unknown()       { c = -1; }
  bool known() const       { return c >= 0; }
  void print() const;
  int index() const        { assert(known()); return c; }
  char* to_str() const; // return static data, string will be 2 chars long
  int suit() const         { assert(known()); return c/13; }
  int rank() const         { assert(known()); return c % 13; }

  bool operator==(Card const & crd) const { return index() == crd.index(); }

  int c;
};

#endif
