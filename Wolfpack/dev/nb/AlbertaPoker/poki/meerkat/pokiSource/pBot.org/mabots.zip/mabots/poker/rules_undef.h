#undef HandType_NOPAIR    
#undef HandType_ONEPAIR   
#undef HandType_TWOPAIR   
#undef HandType_TRIPS     
#undef HandType_STRAIGHT  
#undef HandType_FLUSH     
#undef HandType_FULLHOUSE 
#undef HandType_QUADS     
#undef HandType_STFLUSH   
#undef HandType_FIRST     
#undef HandType_COUNT     
#undef HandType_LAST      

#undef handTypeNames        
#undef handTypeNamesPadded  
#undef nSigCards            
#undef HandVal_print        
#undef HandVal_toString     
