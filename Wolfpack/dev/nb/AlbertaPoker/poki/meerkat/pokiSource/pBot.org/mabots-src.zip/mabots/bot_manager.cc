
#include "mapoker.h"

static int nbots = 0;

Player* Bot_manager::create(const char* botname,
			    const char* botargs,
			    int id)
{
  if (!strcmp(botname, "raise"))
    return XNEW(Always_raise);

  if (!strcmp(botname, "call"))
    return XNEW(Always_call);

  if (!strcmp(botname, "tth")) {

    if (!strcmp(botargs, "bretmaverick"))
      return XNEWC(Tth, (&tth_bret));

    if (!strcmp(botargs, "conan"))
      return XNEWC(Tth, (&tth_conan));    

    if (!strcmp(botargs, "gypsyrose"))
      return XNEWC(Tth, (&tth_profile_3));

    if (!strcmp(botargs, "lashlarue"))
      return XNEWC(Tth, (&tth_profile_4));

    if (!strcmp(botargs, "gomerlarue"))
      return XNEWC(Tth, (&tth_profile_5));

    if (!strcmp(botargs, "lollielarue"))
      return XNEWC(Tth, (&tth_profile_6));

    if (!strcmp(botargs, "nicelyjohnson"))
      return XNEWC(Tth, (&tth_profile_7));

    if (!strcmp(botargs, "cecilycinch"))
      return XNEWC(Tth, (&tth_profile_8));

    if (!strcmp(botargs, "myopicmike"))
      return XNEWC(Tth, (&tth_profile_9));

    if (!strcmp(botargs, "lamontcranston"))
      return XNEWC(Tth, (&tth_profile_10));

    if (!strcmp(botargs, "trickydickie"))
      return XNEWC(Tth, (&tth_profile_11));

    if (!strcmp(botargs, "drjekyll"))
      return XNEWC(Tth, (&tth_profile_12));

    if (!strcmp(botargs, "harrythehorse"))
      return XNEWC(Tth, (&tth_profile_13));

    if (!strcmp(botargs, "nathandetroit"))
      return XNEWC(Tth, (&tth_profile_14));

    if (!strcmp(botargs, "larsonwhipsnade"))
      return XNEWC(Tth, (&tth_profile_15));

    if (!strcmp(botargs, "igorinc"))
      return XNEWC(Tth, (&tth_profile_16));

    if (!strcmp(botargs, "igorina"))
      return XNEWC(Tth, (&tth_profile_17));

    if (!strcmp(botargs, "renfield"))
      return XNEWC(Tth, (&tth_profile_18));

    if (!strcmp(botargs, "janedoe"))
      return XNEWC(Tth, (&tth_profile_19));

    if (!strcmp(botargs, "johndoe"))
      return XNEWC(Tth, (&tth_profile_20));

    if (!strcmp(botargs, "bufordmuldoon"))
      return XNEWC(Tth, (&tth_profile_21));

    if (!strcmp(botargs, "bulletsmcgee"))
      return XNEWC(Tth, (&tth_profile_22));

    if (!strcmp(botargs, "lanceyhoward"))
      return XNEWC(Tth, (&tth_profile_23));

    if (!strcmp(botargs, "omarpotmaker"))
      return XNEWC(Tth, (&tth_profile_24));

    if (!strcmp(botargs, "mrhyde"))
      return XNEWC(Tth, (&tth_profile_25));

    if (!strcmp(botargs, "judiciousjammer"))
      return XNEWC(Tth, (&tth_profile_26));

    if (!strcmp(botargs, "welcomewaldo"))
      return XNEWC(Tth, (&tth_profile_27));

    if (!strcmp(botargs, "regularrube"))
      return XNEWC(Tth, (&tth_profile_28));

    if (!strcmp(botargs, "jerryjackpot"))
      return XNEWC(Tth, (&tth_profile_29));

    if (!strcmp(botargs, "g.a.joe"))
      return XNEWC(Tth, (&tth_profile_30));

    if (!strcmp(botargs, "skymasterson"))
      return XNEWC(Tth, (&tth_profile_31));

    if (!strcmp(botargs, "redteller"))
      return XNEWC(Tth, (&tth_profile_32));

    if (!strcmp(botargs, "drstrangelove"))
      return XNEWC(Tth, (&tth_profile_33));

    if (!strcmp(botargs, "smilinmack"))
      return XNEWC(Tth, (&tth_profile_34));

    if (!strcmp(botargs, "happyhowie"))
      return XNEWC(Tth, (&tth_profile_35));

    if (!strcmp(botargs, "senatorsnort"))
      return XNEWC(Tth, (&tth_profile_36));

    if (!strcmp(botargs, "crustyjack"))
      return XNEWC(Tth, (&tth_profile_37));

    if (!strcmp(botargs, "simplesimon"))
      return XNEWC(Tth, (&tth_profile_38));

    if (!strcmp(botargs, "advisor"))
      return XNEW(Tth_advisor);

    if (!strcmp(botargs, "adv7"))
      return XNEWC(Tth, (&tth_adv_7));

    if (!strcmp(botargs, "adv6"))
      return XNEWC(Tth, (&tth_adv_6));

    if (!strcmp(botargs, "adv5"))
      return XNEWC(Tth, (&tth_adv_5));

    if (!strcmp(botargs, "adv4"))
      return XNEWC(Tth, (&tth_adv_4));

    if (!strcmp(botargs, "adv3"))
      return XNEWC(Tth, (&tth_adv_3));

    if (!strcmp(botargs, "adv2"))
      return XNEWC(Tth, (&tth_adv_2));

    if (!strcmp(botargs, "llhsat"))
      return  XNEWC(Tth, (&llhsat));

    if (!strcmp(botargs, "mickey"))
      return XNEWC(Tth, (&tth_profile_80));

    if (!strcmp(botargs, "sylvia"))
      return XNEWC(Tth, (&tth_profile_81));

    if (!strcmp(botargs, "tinytim"))
      return XNEWC(Tth, (&tth_profile_82));

    if (!strcmp(botargs, "edmundwood"))
      return XNEWC(Tth, (&tth_profile_83));

    if (!strcmp(botargs, "eunicefarthing"))
      return XNEWC(Tth, (&tth_profile_84));

    if (!strcmp(botargs, "elsworthtooey"))
      return XNEWC(Tth, (&tth_profile_85));

    if (!strcmp(botargs, "mannythemooch"))
      return XNEWC(Tth, (&tth_profile_86));

    if (!strcmp(botargs, "moemalarkey"))
      return XNEWC(Tth, (&tth_profile_87));

    if (!strcmp(botargs, "jovialjoe"))
      return XNEWC(Tth, (&tth_profile_88));

    if (!strcmp(botargs, "paulpennysaver"))
      return XNEWC(Tth, (&tth_profile_89));

    if (!strcmp(botargs, "colonelcapp"))
      return XNEWC(Tth, (&tth_profile_90));

    if (!strcmp(botargs, "mzkangaroo"))
      return XNEWC(Tth, (&tth_profile_91));

    if (!strcmp(botargs, "bereftbart"))
      return XNEWC(Tth, (&tth_profile_92));

    if (!strcmp(botargs, "test"))
      return XNEWC(Tth, (&tth_test));
  }
  
  fprintf(stderr, "Unknown bot '%s:%s'\n", botname, botargs);
  abort();
}

//  name is <bot-name>:<bot-args>
Player* Bot_manager::create(const char* name)
{
  char buf[1000];
  
  strcpy(buf, name);
  char* p = index(buf, ':');
  
  ++nbots;

  if (p) {
    *p = 0;
    return create(buf, p+1, nbots);
  }

  return create(buf, 0, nbots);
}
