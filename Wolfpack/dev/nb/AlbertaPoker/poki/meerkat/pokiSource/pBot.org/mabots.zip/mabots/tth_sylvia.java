
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_sylvia extends wrapper implements Player
{
    public tth_sylvia() 
    { 
	super("tth:sylvia"); 
    }
}
