#include "memcheck.h"

void memcheck_fill(void* v, size_t sz)
{
  static int seed = 0;
  size_t u;
  char* b;
  char* c;
  
  if (!seed) {
#ifdef __unix
    unsigned pid = (unsigned)getpid();
#else /* windows */
    unsigned pid = (unsigned)GetCurrentProcessId();
#endif

    /*
     *  Include address of this function as we may have many copies
     *  of memcheck_fill() from different compilation units.
     */
    seed = (time(NULL) << 16) ^ pid ^ ((unsigned)memcheck_fill) ^ 0xdeadbeef ;

    for (u=0; u<50; u++)
      seed = seed*1664525 + 1013904223;
  }
  
  /*
   *  We'll assume (seed >> 24) is top byte.
   */
  assert(sizeof(seed) == 4);

  b = (char*) &seed;
  c = (char*) v;

  for (u=0; u<sz; u++) {
    char t;
    
    /* 
     *  We always want non-zero bytes.
     *  Low order bits aren't very random here, high order bits are.
     */
    do {
      seed = seed*1664525 + 1013904223;
      t = seed >> 24;
    } while (!t);
    
    c[u] = t;
  }
}

void* memcheck_mallocfill(size_t sz)
{
  void* v = malloc(sz);
  if (v)
    memcheck_fill(v, sz);
  return v;
}
