// -*- c++ -*-
/*
 *  Prototypes for the TTH hand/board classification code.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA. 
 */
#ifndef TTH_H
#define TTH_H

void set_tth_verbose(bool);

/*
 *  This is computed at the beginning of each round.  It has the Bet
 *  Variables and draw information for the str draw (which is the
 *  strflush draw if we have one), the flush draw and the made hand
 *  (for which outs and pwin are ignored).  
 */
struct Tth_strategy
{
  Tth_strategy() : flags(0) { }

  void dump();

#define TTH_HAVE_STR_DR   1
#define TTH_HAVE_FL_DR    2

  int flags;
  int tabindex;
  int position;
  int noppo;
  int round;

  struct subs {
    Tth_bet_variable bv;
    int outs;
    double pwin;
    const char* desc;
    int htype;
  } str, fl, made;
};

struct Tth : public Seedable_fast, public Player
{
  Tth(Tth_profile* p = 0) : Seedable_fast(__FILE__), profile(p)  { }

  const char* get_name() const   { return profile->name; }
  void set_seed(unsigned u) { Seedable_fast::set_seed(u); }

  int  get_action(Holdem const &);
  void start_game(Holdem const &, int seat);
  void pre_update (Holdem const &, int who, int action);

  void set_profile(Tth_profile* p) { profile = p; }
  Tth_profile* get_profile()        { return profile; }

  //private:
public:
  Tth_profile* profile;

  //  leader is only guaranteed to be defined post-flop
  int leader;
  bool leader_surrendered; // if the leader checks

  //  Setup at the start of each round.
  Tth_strategy strat;

  static int get_preflop_pot_status(const Holdem & h);
  static int get_preflop_position(const Holdem & h);
  int get_preflop_action(Holdem const & h);

  int Tth::get_preflop_action2(Hole hole, int pot, int posn);

  static int get_postflop_position(Holdem const & h);
  static int get_action2(Holdem const & h, int & which_action, Tth_strategy &, int leader, bool leader_surrendered, bool consider_pot_odds);
  static int get_action(Holdem const & h, Tth_bet_variable const & bv, int leader, bool leader_surrendered);

  static int consider_pot_odds(Holdem const &, Tth_strategy const &, int action);
  static bool check_raise_ok(Holdem const &, int leader, bool leader_surrendered); // for smart check-raising
  
  static void get_postflop_strat(Holdem const & h, Tth_profile const* profile /* need to judge kicker value */, Tth_strategy & strat);

  static void do_straights(Card board[5], int ncards, Hole hole, Straight_info*);
  static void do_flushes(Card board[5], int ncards, Hole hole, Flush_info* fi, int round, Tth_profile const *);
  static void do_strflushes(Card board[5], int ncards, Hole hole, Strflush_info* sfi, Flush_info const * fi);
  static void flush_threats(Card board[5], int ncards, int present[4], int order[4], int topabsent[4], int present2[4][13]);

  static void do_quads(Tth_strategy &, Card board[5], int ncards, Hole hole, int noppo);

  //  hole_ranks[i] can be -1 if that hole card is to be ignored
  static void do_straights(Card board[5], int ncards, int hole_ranks[2], Straight_info* strinfo);
  
  static const char* nopair_str(int i);
  static void do_nopair(Tth_strategy &, Card board[5], int ncards, Hole hole,
			int round, int pos, int noppo, Tth_profile const *);

  static int nopair_made_type(Card board[5], int ncards, Hole hole, 
			      Strflush_info const & sfi,
			      Straight_info const & si,
			      Flush_info const & fi,
			      Rank_info const & ri);

  static const char* onepair_str(int i);  
  static void do_onepair(Tth_strategy &, Card board[5], int ncards, Hole hole,
		      int round, int pos, int noppo, Tth_profile const *);
  static int onepair_made_type(Card board[5], int ncards, int round, Hole hole, 
			       Strflush_info const & sfi,
			       Straight_info const & si,
			       Flush_info const & fi,
			       Rank_info const & ri,
			       int trips_strong_kicker);

  static const char* twopair_str(int i);
  static void do_twopair(Tth_strategy &, Card board[5], int ncards, Hole hole,
			 int round, int pos, int noppo, Tth_profile const *);
  static int twopair_made_type(Card board[5], int ncards, int round, Hole hole, 
			       Strflush_info const & sfi,
			       Straight_info const & si,
			       Flush_info const & fi,
			       Rank_info const & ri);
  
  static const char* trips_str(int i);
  static void do_trips(Tth_strategy &, Card board[5], int ncards, Hole hole,
		       int round, int pos, int noppo, Tth_profile const *);
  static int trips_made_type(Card board[5], int ncards, int round, Hole hole, 
			     Strflush_info const & sfi,
			     Straight_info const & si,
			     Flush_info const & fi,
			     Rank_info const & ri);

  bool made_flush_good_enough(Flush_info const & fi, int round, Tth_profile const * p);
  bool flush_draw_good_enough(Flush_info const & fi, int round, Tth_profile const * p);
};

//  A Player which uses whichever advisor is appropriate for the number of players dealt in
struct Tth_advisor : public Player
{
  const char* get_name() const                             { return "TTH advisor"; }
  void set_seed(unsigned u)                                { tth.set_seed(u); }
  int  get_action(Holdem const & h)                        { return tth.get_action(h); }
  void start_game(Holdem const &, int seat);
  void pre_update (Holdem const & h, int w, int a)         { tth.pre_update(h, w, a); }

private:
  static Tth_profile* const profiles[9];
  Tth tth;
};

extern const char* prefloppositionnames[NPREFLOPPOSITIONS];
extern const char* prefloppotstatusnames[NPOTSTATUSES];
extern const char* postfloproundnames[3];
extern const char* postfloppositionnames[3];

#endif
