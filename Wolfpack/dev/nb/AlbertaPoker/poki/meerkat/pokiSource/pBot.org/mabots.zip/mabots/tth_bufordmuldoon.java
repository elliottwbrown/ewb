
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_bufordmuldoon extends wrapper implements Player
{
    public tth_bufordmuldoon() 
    { 
	super("tth:bufordmuldoon"); 
    }
}
