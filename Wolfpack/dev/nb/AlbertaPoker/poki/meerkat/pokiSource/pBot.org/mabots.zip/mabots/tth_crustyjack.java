
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_crustyjack extends wrapper implements Player
{
    public tth_crustyjack() 
    { 
	super("tth:crustyjack"); 
    }
}
