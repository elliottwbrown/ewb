
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_drstrangelove extends wrapper implements Player
{
    public tth_drstrangelove() 
    { 
	super("tth:drstrangelove"); 
    }
}
