
#include "mapoker.h"

static Card_mask* construct_card_mask_table();

Hole*      hole_table = 0;
Hand*      hand_table = 0;
Card_mask* card_mask_table = construct_card_mask_table();


Hole* construct_hole_table()
{
  Hole* holes = XNEWA(Hole, (1<<12));

  int k = 0;
  for (unsigned c1=0; c1<52; c1++)
    for (unsigned c2=c1+1; c2<52; c2++, k++) {
      unsigned s1 = c1/13;
      unsigned r1 = c1 % 13;
      unsigned s2 = c2/13;
      unsigned r2 = c2 % 13;
      unsigned idx;
      
      idx = r1;
      idx <<= 2; idx |= s1;
      idx <<= 4; idx |= r2;
      idx <<= 2; idx |= s2;
      
      holes[idx] = Hole(k);
    }
  
  return holes;
}

Hand* construct_hand_table()
{
  Hand* hands = XNEWA(Hand, NHOLES);

  int k = 0;
  for (unsigned c1=0; c1<52; c1++)
    for (unsigned c2=c1+1; c2<52; c2++, k++)
      hands[k] = Hand(Card(c1),Card(c2));
  
  return hands;
}

static Card_mask* construct_card_mask_table()
{
  Card_mask* cm = XNEWA(Card_mask, NHOLES);

  for (int h=0; h<NHOLES; h++)
    cm[h] = Card_mask(Hole(h).to_Hand());

  return cm;
}

int Hole::canonical() const
{
  Hand h = to_Hand();
  Card c1 = h.card(0);
  Card c2 = h.card(1);
  unsigned r1 = c1.rank();
  unsigned s1 = c1.suit();
  unsigned r2 = c2.rank();
  unsigned s2 = c2.suit();
  
  if (s1 != s2 ^ r1 < r2) {
    unsigned t = r1;
    r1 = r2;
    r2 = t;
  }

  // r1 > r2 is suited
  return 13*r1 + r2;
}

Hole::Hole(const char* str) 
{
  int rank[2];
  int suited = 0;

  for (int c=0; c<2; c++) {
    switch (toupper(str[c])) {
    case 'A': rank[c] = 12; break; 
    case 'K': rank[c] = 11; break;  
    case 'Q': rank[c] = 10; break;  
    case 'J': rank[c] = 9; break;  
    case 'T': rank[c] = 8; break;  
    case '9': rank[c] = 7; break;  
    case '8': rank[c] = 6; break;  
    case '7': rank[c] = 5; break;  
    case '6': rank[c] = 4; break;  
    case '5': rank[c] = 3; break; 
    case '4': rank[c] = 2; break;  
    case '3': rank[c] = 1; break;  
    case '2': rank[c] = 0; break; 
    default:
      THROW2(("Invalid argument to Hole constructor: rank=%c", rank[c]));
    }
  }

  if (strlen(str) >= 3 && tolower(str[2]) == 's')
    suited = 1;
  
  if (suited) {
    if (rank[0] == rank[1])
      THROW2(("Invalid argument to Hole constructor: rank[0]==rank[1]==%i", rank[0]));
    *this = Hole(rank[0], 0, rank[1], 0);
  } else 
    *this = Hole(rank[0], 0, rank[1], 1);
}

Hole Hole::from_canon(unsigned u)
{
  assert(u < NHOLES_CANON);

  unsigned r1 = u / 13;
  unsigned r2 = u % 13;

  if (r1 > r2)
    return Hole(r1, 0, r2, 0);
  
  return Hole(r1, 0, r2, 1);
}

#ifdef HOLE_INFO_TABLE

int main(int argc, char* argv[])
{
  printf("struct Hole_info hole_info_table[NHOLES] =\n{\n");
  for (int h=0; h<NHOLES; h++) {
    Hole hole(h);

    printf("\t{%i, %i, %i, %i, %i}, // %s\n",
	   hole.suited(), hole.paired(),
	   hole.gap(), hole.lorank(), hole.toprank(), hole.to_str());
  }
  printf("};\n");
}

#endif

#ifdef HOLE_STRENGTH

int main(int argc, char* argv[])
{
  int str[NHOLES];

  for (int c=0; c<NHOLES; c++) {
    Hole h(c);
    if (h.paired())
      str[c] = 2*20*20 + h.lorank();
    else {
      str[c] = h.suited() + 2*(h.lorank() + 20*h.toprank());
    }
  }
  
  double wins[NHOLES];
  int    cnts[NHOLES];
  
  for (int k=0; k<NHOLES; k++) {
    wins[k] = 0.0;
    cnts[k] = 0;
    for (int j=0; j<NHOLES; j++) {
      if (Hole(k).consistent(j)) {
	if (str[k] > str[j])
	  wins[k] += 1.0;
	else if (str[k] == str[j])
	  wins[k] += 0.5;
	cnts[k]++;
      }
    }
  }

  printf("double preflop_strength[NHOLES] =\n{\n");
  for (int h=0; h<NHOLES; h++)
    printf("%g, /* %s */\n", wins[h]/cnts[h], Hole(h).to_str());
  printf("};\n");
}

#endif

#ifdef HOLE_TMP

int main(int argc, char* argv[])
{
  for (int c=0; c<NHOLES_CANON; c++)
    printf("%s\n", Hole::from_canon(c).to_str());
}

#endif
