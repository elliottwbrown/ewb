// -*- c++ -*-
#ifndef UTILS_H
#define UTILS_H

using namespace std;

struct Equal_to_str {
  bool operator()(const char* s1, const char* s2) {
    return !strcmp(s1, s2);
  }
  bool operator()(char* s1, char* s2) {
    return !strcmp(s1, s2);
  }
};

/**
 *  Used to sort a T[] v so that t[v[i]] is ascending/descending in i.
 */
template<class T> struct compare
{
  T* t;
  bool a;
  compare(T* t_, bool ascending = true) : t(t_), a(ascending) { }
  bool operator()(int i1, int i2) {
    return a ? (t[i1] < t[i2]) : (t[i1] > t[i2]);
  }
};

template<class T, class S>
struct compare_first 
{ 
  bool operator()(const pair<T,S> & a, const pair<T,S> & b) {
    return a.first < b.first;
  }
};

template<class T, class S>
struct compare_second
{ 
  bool operator()(const pair<T,S> & a, const pair<T,S> & b) {
    return a.second < b.second;
  }
};

inline double array_sum(double const * src, int sz)
{
  double sum = 0.0;

  for (int c=0; c<sz; c++)
    sum += src[c];

  return sum;
}

inline void normalize(double * src, int sz)
{
  double sum = array_sum(src, sz);
  for (int c=0; c<sz; c++)
    src[c] /= sum;
}

inline void merge(double* dst, double const * src, int sz)
{
  double s1 = array_sum(src, sz);
  double s2 = array_sum(dst, sz);

  for (int c=0; c<sz; c++)
    dst[c] = src[c]/s1 + dst[c]/s2;
}



#endif
