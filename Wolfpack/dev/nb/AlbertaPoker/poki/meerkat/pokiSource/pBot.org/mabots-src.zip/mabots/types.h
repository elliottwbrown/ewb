
typedef int chip_t;
