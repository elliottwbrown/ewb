
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_lamontcranston extends wrapper implements Player
{
    public tth_lamontcranston() 
    { 
	super("tth:lamontcranston"); 
    }
}
