/*
 *  Native part of Meerkat -> my code interface.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#include "mapoker.h"
#include "malib.h"

static bool debug = false;

struct Meerkat
{
  vector<Hand> hands;
  Holdem H;
  Player* P;
};

/*
 *  Meerkat uses 2s..As 2h..2d..2c..Ac
 *  I use        2h..Ah 2d..2c..2s..As
 */
static int meerkat_card_index_to_my_index(int i)
{
  //  FIXME use a lookup table
  if (i < 13)
    return i+39;
  return i-13;
}

/*
 * Class:     malib
 * Method:    set_verbose
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_malib_set_1verbose
  (JNIEnv *, jclass, jint ref, jint level)
{
  set_tth_verbose(level >= 1);
  debug  = (level >= 3);
}

/*
 * Class:     malib
 * Method:    new_bot
 * Signature: (Ljava/lang/String;)I
 */
JNIEXPORT jint JNICALL Java_malib_new_1bot
  (JNIEnv *env, jclass, jstring name)
{
  const char* str = env->GetStringUTFChars(name, 0);
  Meerkat* M = XNEWO(Meerkat);
  M->P = Bot_manager::create(str);
  env->ReleaseStringUTFChars(name, str);
  setbuf(stdout, 0);
  return (jint) M;
}

/*
 * Class:     malib
 * Method:    delete_bot
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_malib_delete_1bot
  (JNIEnv *, jclass, jint ref)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;
  DELETEO(M->P);
  DELETEO(M);
}

/*
 * Class:     malib
 * Method:    do_new_game
 * Signature: (IIIIIZ[Ljava/lang/String;[I[ZI[I[IIII)I
 */
JNIEXPORT void JNICALL Java_malib_do_1new_1game
  (JNIEnv *env, jclass, jint ref, 
   jint sbl, jint bbl, jint sbet, jint bbet, jboolean hu, 
   jobjectArray players_, 
   jintArray starting_chips_, jbooleanArray allin_, jint dealer, 
   jintArray live_blinds_, jintArray dead_blinds_, 
   jint pos, jint c1, jint c2)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;
  Holdem & H = M->H;
  int i;

  int nplayers = env->GetArrayLength(players_);

  M->hands.resize(nplayers);
  for (i=0; i<nplayers; i++)
    M->hands[i].set_unknown();

  vector<string> players(nplayers);
  vector<int>    starting_chips(nplayers);
  vector<int>    allin(nplayers);
  vector<int>    live_blinds(nplayers);
  vector<int>    dead_blinds(nplayers);

  jint* starting_chips__ = env->GetIntArrayElements(starting_chips_, 0);
  jboolean* allin__ = env->GetBooleanArrayElements(allin_, 0);
  jint* lblinds = env->GetIntArrayElements(live_blinds_, 0);
  jint* dblinds = env->GetIntArrayElements(dead_blinds_, 0);

  for (i=0; i<nplayers; i++) {
    jstring jstr = (jstring)env->GetObjectArrayElement(players_, i);
    const char* str = env->GetStringUTFChars(jstr, 0);

    players[i] = str;
    starting_chips[i] = starting_chips__[i];
    allin[i] = allin__[i];
    live_blinds[i] = lblinds[i];
    dead_blinds[i] = dblinds[i];

    env->ReleaseStringUTFChars(jstr, str);
  }

  env->ReleaseIntArrayElements(starting_chips_, starting_chips__, 0);
  env->ReleaseBooleanArrayElements(allin_, allin__, 0);
  env->ReleaseIntArrayElements(live_blinds_, lblinds, 0);
  env->ReleaseIntArrayElements(dead_blinds_, dblinds, 0);

  M->hands[pos] = Hand(Card(meerkat_card_index_to_my_index(c1)),
		       Card(meerkat_card_index_to_my_index(c2)));

  H.set_structure(0, sbl, bbl, sbet, bbet, 0, 0, hu);
  H.set_predeal(players, starting_chips, allin, dealer, live_blinds, dead_blinds, M->hands);
  M->P->start_game(H, pos);
}

/*
 * Class:     malib
 * Method:    get_action
 * Signature: (I)I
 *
 *  return 0=fold 1=check/call 2=raise
 */
JNIEXPORT jint JNICALL Java_malib_get_1action
  (JNIEnv *env, jclass, jint ref)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;

  return M->P->get_action(M->H);
}

/*
 * Class:     malib
 * Method:    do_action_event
 * Signature: (IIII)V
 *
 * action is 0/1/2, or 3 for allin
 */
JNIEXPORT void JNICALL Java_malib_do_1action_1event
  (JNIEnv *, jclass, jint ref, jint pos, jint action, jint amount, jboolean use_allin_rules)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;

  /*
   *  What happens if a guy is put allin due to a disconnect?
   *  Obviously this can't happen with PPA, but I'll assume we'll
   *  see a ALLIN event for the corresponding player.
   *  (Normally we can ignore ALLIN events since we have to spot the
   *  case where a guy runs out of chips and put him allin ourselves
   *  anyway - see comment below.)
   */
  if (action == 3) {
    if (M->H.end_of_round() || M->H.whose_on() != pos)
      //  we skipped him.
      return;

    /* 
     *  Since amount means different things for 'bet' and 'call',
     *  who knows what an ALLIN action with amount != 0 means?
     */
    assert(amount == 0);
  }

  //  Meerkat sends us 'fold' events on mucks.
  if (M->H.get_state() == SHOWDOWN) {
    assert(action == 0);
    return;
  }
  
  //  for bet/raise, 'amount' is the extra.
  if (action == 2)
    amount += M->H.to_call();
  
  int a = 0;
  bool allin = false;
  
  /* 
   *  If the guy has just enough chips for his action (so he'll have
   *  no chips left after this action) and there's only 1 other
   *  player, Meerkat may never send any ALLIN events, so we have to
   *  detect this allin action ourself.  
   */
  if (use_allin_rules)
    if (M->H.get_total_contrib(pos) + amount == M->H.get_starting_chips(pos))
       allin = true;

  if (action != 0) {
    if (amount < M->H.to_call()) {
      a = 1;
      allin = true;
    } else if (amount == M->H.to_call())
      a = 1;
    else if (amount < M->H.to_raise()) {
      a = 2;
      allin = true;
    } else
      a = 2;
  }

  //  In case we're sent ALLIN with amount=0 on a disconnect.
  if (action == 3)
    allin = true;

  M->P->pre_update(M->H, pos, a);

  if (!allin) {
    if (a == 0)
      M->H.fold();
    else
      M->H.bet(amount);
  } else
    M->H.goallin(amount);
  
  M->P->post_update(M->H, pos, a);

  if (debug)
    M->H.dump();
}

/*
 * Class:     malib
 * Method:    do_showdown_event
 * Signature: (IIII)V
 */
JNIEXPORT void JNICALL Java_malib_do_1showdown_1event
  (JNIEnv *, jclass, jint ref, jint pos, jint c1, jint c2)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;
  
  M->hands[pos] = Hand(Card(meerkat_card_index_to_my_index(c1)),
		       Card(meerkat_card_index_to_my_index(c2)));
}

/*
 * Class:     malib
 * Method:    set_flop
 * Signature: (IIII)V
 */
JNIEXPORT void JNICALL Java_malib_set_1flop
  (JNIEnv *, jclass, jint ref, jint c1, jint c2, jint c3)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;
  
  Card flop[3];
  flop[0] = Card(meerkat_card_index_to_my_index(c1));
  flop[1] = Card(meerkat_card_index_to_my_index(c2));
  flop[2] = Card(meerkat_card_index_to_my_index(c3));
  M->H.set_flop(flop);
  M->P->flop_cards(M->H);

  if (debug)
    M->H.dump();
}

/*
 * Class:     malib
 * Method:    set_turn_river
 * Signature: (IZI)V
 */
JNIEXPORT void JNICALL Java_malib_set_1turn_1river
  (JNIEnv *, jclass, jint ref, jboolean is_river, jint c)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;

  if (!is_river) {
    M->H.set_turn(Card(meerkat_card_index_to_my_index(c)));
    M->P->turn_card(M->H);
  } else {
    M->H.set_river(Card(meerkat_card_index_to_my_index(c)));
    M->P->river_card(M->H);
  }

  if (debug)
    M->H.dump();
}

/*
 * Class:     malib
 * Method:    do_game_over_event
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_malib_do_1game_1over_1event
  (JNIEnv *, jclass, jint ref)
{
  assert(ref);
  Meerkat* M = (Meerkat*) ref;

  M->H.do_showdown(M->hands);

  if (debug)
    M->H.dump();

  M->P->end_of_game(M->H);
}
