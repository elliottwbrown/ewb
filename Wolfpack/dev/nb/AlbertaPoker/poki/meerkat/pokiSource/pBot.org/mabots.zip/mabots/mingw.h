#ifndef MINGW_H
#define MINGW_H

#include <io.h>

#ifdef __cplusplus
extern "C" {
#endif

char* index(char* str, char c);
int finite(double c);
double drand48();

#undef min
#undef max

#define MKDIR(path,mode) mkdir(path)

#ifdef __cplusplus
}
#endif

#endif
