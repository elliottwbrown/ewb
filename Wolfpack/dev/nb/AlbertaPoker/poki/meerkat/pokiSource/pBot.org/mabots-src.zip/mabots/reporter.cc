
#include "mapoker.h"

Reporter  default_reporter;
Reporter* current_reporter = &default_reporter;

Reporter::Reporter()
  : filename("reporter.log"), fp(0), logging(false)
{
}

Reporter::~Reporter()
{
  if (fp) {
    fclose(fp);
    fp = 0;
  }
}

void Reporter::set_logname(string const & filename_)
{
  filename = filename_;

  if (fp) {
    fclose(fp);
    fp = 0;
  }
}

void Reporter::set_logging(bool b)
{
  logging = b;
}

Reporter & Reporter::log_(const char* prefix, string const & str)
{
  if (!logging)
    return *this;

  if (!fp) {
    if (!(fp = fopen(filename.c_str(), "a")))
      THROW2(("fopen(%s): %s", filename.c_str(), strerror(errno)));
    setbuf(fp,0);
  }

  if (prefix)
    fprintf(fp, "%s: ",  prefix);
  
  const char* s = str.c_str();
  fprintf(fp, "%s", s);

  if (s[strlen(s)-1] != '\n')
    fprintf(fp, "\n");

  if (ferror(fp))
    THROW2(("ferror(%s): %s", filename.c_str(), strerror(errno)));

  return *this;
}
