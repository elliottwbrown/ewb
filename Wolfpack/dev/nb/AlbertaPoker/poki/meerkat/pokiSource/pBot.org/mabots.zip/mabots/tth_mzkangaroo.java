
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_mzkangaroo extends wrapper implements Player
{
    public tth_mzkangaroo() 
    { 
	super("tth:mzkangaroo"); 
    }
}
