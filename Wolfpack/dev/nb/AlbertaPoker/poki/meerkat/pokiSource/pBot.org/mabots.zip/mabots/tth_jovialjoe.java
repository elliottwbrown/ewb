
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_jovialjoe extends wrapper implements Player
{
    public tth_jovialjoe() 
    { 
	super("tth:jovialjoe"); 
    }
}
