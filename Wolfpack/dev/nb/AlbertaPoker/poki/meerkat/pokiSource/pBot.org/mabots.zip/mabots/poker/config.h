/* include/config.h.  Generated automatically by configure.  */
/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define as __inline if that's what the C compiler calls it.  */
/* #undef inline */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

#define HAVE_UNISTD_H 1
#define HAVE_SYS_STAT_H 1

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* Define if your compiler supports "long long" for 64 bit integers */
#define HAVE_INT64 1
#define HAVE_LONG_LONG 1

/* Integer sizes */
#define SIZEOF_INT  4
#define SIZEOF_LONG 4
