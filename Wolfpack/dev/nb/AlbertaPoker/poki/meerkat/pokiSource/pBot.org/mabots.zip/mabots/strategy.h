// -*- c++ -*-
/*
 *  Definitions of 'strategies' to use throughout a single betting round.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA. 
 */

#ifndef STRATEGY_H
#define STRATEGY_H

//  preflop strategies
#define MAKE0  10
#define CALLH  11                /* we have small blind, & we're calling for half a small bet */
#define CALL1  12
#define MAKE1  13                /* folds if facing 2 bets */
#define MAKE2CALLANY 14
#define CALLANY 15
#define MAKEANY 16
#define CALL1THENFOLD 17
#define RAISECALL1 18
#define RAISECALL2  19
#define CALLCALL1 20
#define CALLCALL2 21
#define RAISECALL 22
#define CALLRERAISERERAISE 23
#define CALLRERAISEMAYBE 24
#define CALLRERAISEUNLESSHEADSUP 25
#define CALLIFPOTODDSPAIR 26
#define CALLRERAISECALL 27
#define CALLRERAISEIFMANYOPPO 28
#define RAISEFOLD 29

#define PF_P0 30 /* fold, or check if I can */
#define PF_CH 31 /* call half if SB, fold o/w */
#define PF_X1 32 /* fold if someone else has bet. if no-one else has called, raise, but fold a reraise */
#define PF_X2 33 /* like PN. but if no-one else has called, raise */
#define PF_PN 34 /* call, but fold 2 bet raise */
#define PF_P4 35 /* call forever */
#define PF_RN 36 /* make 2, don't cold call 2 bets later */
#define PF_R4 37 /* make 2, call thereafter even if 2 bets */
#define PF_A4 38 /* make 3, call if capped */
#define PF_DR 39 /* call first time, then raise forever */

struct Strategy : public Seedable
{
  Strategy() : Seedable(__FILE__) { }

  //  return 0, 1 or 2
  int get_action(Holdem const & h, int strategy);

  static const char* name(int i);
};

#endif
