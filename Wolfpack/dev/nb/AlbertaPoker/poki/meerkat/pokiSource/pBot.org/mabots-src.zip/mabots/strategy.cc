
#include "mapoker.h"

#if 0
char* pfs[] = {"MAKE0", "CALLH", "CALL1", "MAKE1", 
	       "MAKE2CALLANY", /* aka MAKE2 */
	       "CALLANY",      /* aka CALL2, CALL1.5 */
	       "MAKEANY"};     /* aka MAKE4 */
#endif

int Strategy::get_action(Holdem const & h, int strategy)
{
  int action = get_action_aux(h, strategy);

  if ((action == 2 && !h.get_can_raise())
      || (action == 0 && h.get_can_check()))
    action = 1;
  
  return action;
}

int Strategy::get_action_aux(Holdem const & h, int strategy)
{
  prng_state st(p);

  int tocall = h.to_call();
  int raise = h.raise_this_round();
  int vol = h.made_nonforced_bet(h.whose_on());

  switch (strategy) {

  case PF_DR:
    if (!h.has_acted())
      return PLAYER_CALL;
    return PLAYER_RAISE;

  case PF_X1:
    if (h.get_pot() == h.get_small_blind() + h.get_big_blind())
      return PLAYER_RAISE;
    return PLAYER_FOLD;

  case PF_RN:
    if (tocall >= 2*raise)
      return PLAYER_FOLD;
  case PF_R4:
    if (h.get_max_bet_this_round() < 2*raise)
      return PLAYER_RAISE;
    return PLAYER_CALL;

  case PF_X2:
    if (h.get_pot() == h.get_small_blind() + h.get_big_blind())
      return PLAYER_RAISE;
  case PF_PN:
    if (tocall >= 2*raise)
      return PLAYER_FOLD;
    return PLAYER_CALL;

  case PF_P0:
  case MAKE0:
    if (tocall == 0)
      return PLAYER_CALL;
    return PLAYER_FOLD_CHECK;
    
  case PF_CH:
    if (tocall > 0 && tocall < raise)
      return PLAYER_CALL;
    return PLAYER_FOLD;

  case CALLH: // call a bet of 0.5, fold if more
    if (tocall > raise/2 && !vol)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;
    
  case CALL1: 
    if (tocall > raise && !vol)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;

  case CALL1THENFOLD:
    if (!vol && tocall <= raise)
      return PLAYER_CALL;
    return PLAYER_FOLD_CHECK;

  case MAKE1: 
    if (h.get_max_bet_this_round() < raise)
      return PLAYER_RAISE;
    if (tocall > raise && !vol)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;

  case MAKE2CALLANY:
    if (h.get_max_bet_this_round() < 2*raise)
      return PLAYER_RAISE;
    return PLAYER_CALL;

  case PF_P4:
  case CALLANY:
    return PLAYER_CALL;

  case PF_A4:
  case MAKEANY:
    return PLAYER_RAISE;

  case RAISECALL1:
    if (!vol)
      return PLAYER_RAISE;
    if (tocall > raise)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;
    
  case RAISECALL2:
    if (!vol)
      return PLAYER_RAISE;
    if (tocall > raise*2)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;
    
  case CALLCALL1:
    if (!vol)
      return PLAYER_CALL;
    if (tocall > raise)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;
    
  case CALLCALL2:
    if (!vol)
      return PLAYER_CALL;
    if (tocall > 2*raise)
      return PLAYER_FOLD_CHECK;
    return PLAYER_CALL;
    
  case RAISECALL:
    if (!vol)
      return PLAYER_RAISE;
    return PLAYER_CALL;
    
  case CALLRERAISECALL:
  case CALLRERAISERERAISE:
    if (!vol)
      return PLAYER_CALL;
    return PLAYER_RAISE;

  case RAISEFOLD:
    if (!vol)
      return PLAYER_RAISE;
    return PLAYER_FOLD;

  case CALLRERAISEIFMANYOPPO:
    if (!vol)
      return PLAYER_CALL;
    if (h.get_nstillin() >= 3)
      return PLAYER_RAISE;
    return PLAYER_CALL;

  case CALLRERAISEMAYBE:
    if (!vol)
      return PLAYER_CALL;
    if (h.get_nstillin() == 2 && p.u() < 0.75)
      return PLAYER_CALL;
    return PLAYER_RAISE;

  case CALLRERAISEUNLESSHEADSUP:
    if (!vol)
      return PLAYER_CALL;
    if (h.get_nstillin() == 2)
      return PLAYER_CALL;
    return PLAYER_RAISE;

  case PLAYER_FOLD_CHECK:
    return PLAYER_FOLD_CHECK;

  case PLAYER_CALL:
    return PLAYER_CALL;

  case PLAYER_RAISE:
    return PLAYER_RAISE;

  case CALLIFPOTODDSPAIR:
    if (h.to_call()/(h.get_pot() + h.to_call()) < 1/(1 + 7.5))
      return PLAYER_CALL;
    return PLAYER_FOLD;
  }

  assert(!"Internal error");
  return 0;
}

const char* Strategy::name(int i)
{
  switch (i) {
  case PLAYER_FOLD_CHECK: return "FOLDCHECK";
  case PLAYER_RAISE: return "RAISE";
  case PLAYER_CALL: return "CALL";
  case MAKE0: return "MAKE0";
  case CALLH: return "CALLH";
  case CALL1: return "CALL1";
  case MAKE1: return "MAKE1";
  case MAKE2CALLANY: return "MAKE2CALLANY";
  case CALLANY: return "CALLANY";
  case MAKEANY: return "MAKEANY";
  case CALL1THENFOLD: return "CALL1THENFOLD";
  case RAISECALL1: return "RAISECALL1";
  case RAISECALL2: return "RAISECALL2";
  case CALLCALL1: return "CALLCALL1";
  case CALLCALL2: return "CALLCALL2";
  case RAISECALL: return "RAISECAL";
  case CALLRERAISEMAYBE: return "CALLRAISEMAYBE";
  case CALLRERAISEUNLESSHEADSUP: return "CALLRERAISEUNLESSHEADSUP";
  case CALLIFPOTODDSPAIR: return "CALLIFPOTODDSPAIR";
  case CALLRERAISECALL: return "CALLRERAISECALL";
  case CALLRERAISERERAISE: return "CALLRERAISERERAISE";
  case CALLRERAISEIFMANYOPPO: return "CALLRERAISEIFMANYOPPO";
  case RAISEFOLD: return "RAISEFOLD";
  }
  THROW2(("Unknown strategy: %i\n", i));
  return 0;
}
