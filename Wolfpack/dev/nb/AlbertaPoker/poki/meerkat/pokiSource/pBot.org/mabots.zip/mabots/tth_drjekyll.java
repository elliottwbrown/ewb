
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_drjekyll extends wrapper implements Player
{
    public tth_drjekyll() 
    { 
	super("tth:drstrangelove"); 
    }
}
