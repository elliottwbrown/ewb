
#include <math.h>

#ifdef _MSC_VER

#include <float.h>

int finite(double v)
{
  return _finite(v);
}

#else

int finite(double v)
{
  return v < HUGE_VAL && v > -HUGE_VAL;
}

#endif
