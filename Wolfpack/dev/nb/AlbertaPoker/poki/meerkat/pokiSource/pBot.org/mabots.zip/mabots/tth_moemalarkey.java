
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_moemalarkey extends wrapper implements Player
{
    public tth_moemalarkey() 
    { 
	super("tth:moemalarkey"); 
    }
}
