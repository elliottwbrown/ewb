
#include "mapoker.h"

static int debug = 0;

void Dealer::set_debug(int d)
{
  debug = d;
}

Dealer::Dealer(int nseats_)
{
  p.seed(123);

  assert(nseats_ >= 2 && nseats_ <= DLR_MAX_PLAYERS);

  dealer = 0;
  smallblind = 5;
  bigblind = 10;
  smallbet = 10;
  bigbet = 20;
  nseats = nseats_;
  players.resize(nseats);
  chips.resize(nseats);
  holes.resize(nseats);
  preset_hands.resize(nseats);
  have_preset_flop = false;
  have_preset_turn = false;
  have_preset_river = false;
  aborting = false;
}

Dealer & Dealer::add_player(Player* p, chip_t ch)
{
  for (int c=0; c<nseats; c++)
    if (!players[c]) {
      players[c] = p;
      chips[c] = ch;
      return *this;
    }

  THROW("No free seats\n");
  return *this;
}

void Dealer::set_flop(Card const flop[3])
{
  preset_flop[0] = flop[0];
  preset_flop[1] = flop[1];
  preset_flop[2] = flop[2];
  have_preset_flop = true;
}

void Dealer::set_turn(Card c)
{
  preset_turn = c;
  have_preset_turn = true;
}

void Dealer::set_river(Card c)
{
  preset_river = c;
  have_preset_river = true;
}

void Dealer::remove_known_cards()
{
  if (have_preset_flop) {
    deck.remove(preset_flop[0]);
    deck.remove(preset_flop[1]);
    deck.remove(preset_flop[2]);
  }

  if (have_preset_turn) 
    deck.remove(preset_turn);
  
  if (have_preset_river) 
    deck.remove(preset_river);
  
  for (int c=0; c<nseats; c++)
    if (preset_hands[c].known()) {
      holes[c] = Hole(preset_hands[c]);
      Card c0 = holes[c].card(0);
      Card c1 = holes[c].card(1);
      deck.remove(c0);
      deck.remove(c1);
    }
}

void Dealer::deal_hole_cards()
{
  for (int c=0; c<nseats; c++) 
    if (preset_hands[c].known()) {
      holes[c] = preset_hands[c];
    } else {
      int c1 = deck.sample(p);
      deck.remove(Card(c1));
      int c2 = deck.sample(p);
      deck.remove(Card(c2));
      holes[c] = Hole(c1, c2);
    }
}

void Dealer::do_setstructure()
{
  H.set_structure(0, 
		  smallblind, bigblind,
		  smallbet, bigbet,
		  0, 0, (nseats == 2));
}
  
void Dealer::do_predeal()
{
  vector<string> players_(nseats);
  vector<int>    starting_chips(nseats);
  vector<int>    allin(nseats);
  vector<int>    live_blinds(nseats);
  vector<int>    dead_blinds(nseats);
  vector<Hand>   hands(nseats);
  
  if (players.size() < (unsigned)nseats)
    THROW("Not enough players have joined the game");

  for (int c=0; c<nseats; c++) {
    players_[c] = string(players[c]->get_name());
    starting_chips[c] = chips[c];
    allin[c] = 0;
    // live_blinds done later
    dead_blinds[c] = 0;
    hands[c] = holes[c].to_Hand();
  }
    
  //   Not sure exactly what the rules are for headsup play
  
  if (nseats != 2) {
    live_blinds[(dealer+1) % nseats] = smallblind;
    live_blinds[(dealer+2) % nseats] = bigblind;
  } else {
    //  Headsup blind structure: dealer posts smallblind, UTG posts bigblind
    live_blinds[(dealer+1) % nseats] = bigblind;
    live_blinds[(dealer+2) % nseats] = smallblind;
  }
  
  H.set_predeal(players_, starting_chips,allin, dealer, live_blinds, dead_blinds, hands, 2);
}

//  state wants to be PREFLOP, FLOP, TURN or RIVER
//  return true if we're abouting and run() should return immediately
bool Dealer::do_round(int state)
{
  int c;
  const char* action_names[] = {"FOLD/CHECK", "CALL", "BET/RAISE"};

  while (H.get_state() == state) {
    int on = H.whose_on();

    if (debug)
      H.dump();

    int action = players[on]->get_action(H);

    assert(action >= 0 && action < PLAYER_NACTIONS);

    if (!H.get_can_raise() && action == PLAYER_RAISE)
      action = PLAYER_CALL;
    
    Holdem::Action a;

    if (action == PLAYER_FOLD_CHECK) {
      if (H.to_call() == 0) {
	a = Holdem::Action(Holdem::Action::bet);
	a.amount = 0;
	action = 1;
      } else
	a = Holdem::Action(Holdem::Action::fold);
      
    } else if (action == PLAYER_CALL) {
      a = Holdem::Action(Holdem::Action::bet);
      a.amount = H.to_call();
      
    } else if (action == PLAYER_RAISE) {
      a = Holdem::Action(Holdem::Action::bet);
      a.amount = H.to_call() + H.raise_this_round();
    }  
    
    if (debug)
      printf("seat %i %s\n", on, action_names[action]);

    for (c=0; c<nseats; c++)
      players[c]->pre_update(H, on, action);

    H.act(a);

    for (c=0; c<nseats; c++)
      players[c]->post_update(H, on, action);

    if (aborting)
      return true;
  }

  return false;
}

void Dealer::deal_cards(int n_to_deal)
{
  for (int c=ncards; c<ncards+n_to_deal; c++) {
    Card i = Card(deck.sample(p));
    deck.remove(i);
    cards[c] = i;
  }
  ncards += n_to_deal;
}

void Dealer::deal()
{
  deck.fill();
  remove_known_cards();
  deal_hole_cards();

  //  invalidate board
  ncards = 0;
}

void Dealer::run()
{
  int c;

  aborting = false;
  deal();
  do_setstructure();
  do_predeal();

  for (c=0; c<nseats; c++)
    players[c]->start_game(H, c);

  if (do_round(PREFLOP))
    return;

  if (H.get_state() == PREMATHANDEND) {
    premathandend();
    return;
  }

  assert(H.get_state() == PREFLOPEND);

  if (have_preset_flop) {
    cards[0] = preset_flop[0];
    cards[1] = preset_flop[1];
    cards[2] = preset_flop[2];
    ncards = 3;
  } else
    deal_cards(3);
  H.set_flop(cards);

  for (c=0; c<nseats; c++)
    players[c]->flop_cards(H);
  
  if (do_round(FLOP))
    return;

  if (H.get_state() == PREMATHANDEND) {
    premathandend();
    return;
  }

  assert(H.get_state() == FLOPEND);

  if (have_preset_turn) {
    cards[3] = preset_turn;
    ncards++;
  } else 
    deal_cards(1);
  H.set_turn(cards[3]);

  for (c=0; c<nseats; c++)
    players[c]->turn_card(H);
  
  if (do_round(TURN))
    return;

  if (H.get_state() == PREMATHANDEND) {
    premathandend();
    return;
  }
  
  assert(H.get_state() == TURNEND);

  if (have_preset_river) {
    cards[4] = preset_river;
    ncards++;
  } else
    deal_cards(1);
  H.set_river(cards[4]);
  
  for (c=0; c<nseats; c++)
    players[c]->river_card(H);
  
  if (do_round(RIVER))
    return;

  if (H.get_state() == PREMATHANDEND) {
    premathandend();
    return;
  }

  assert(H.get_state() == SHOWDOWN);
  
  /*  assume all players still in show */
  vector<int> v;
  H.whos_in_showdown(v);
  vector<Hand> hands(nseats);
  for (c=0; c<nseats; c++)
    if (v[c])
      hands[c] = holes[c].to_Hand();
  H.do_showdown(hands);

  process_payouts();
}

void Dealer::premathandend()
{
  /*  assume player doesn't show */
  H.act(Holdem::Action(Holdem::Action::noshow));
  assert(H.get_state() == HANDEND);
  process_payouts();
}

void Dealer::process_payouts()
{
  int c;
  
  for (c=0; c<nseats; c++)
    players[c]->end_of_game(H);

  vector<int> ch;
  H.get_net_change(ch);
  
  for (c=0; c<nseats; c++)
    chips[c] += ch[c];
}

Dealer::~Dealer()
{
}

void Dealer::dump()
{
  for (int c=0; c<nseats; c++)
    printf("\t%i", chips[c]);
  printf("\n");
}

void Dealer::dump_hand()
{
  H.dump();
}

void Dealer::set_hands(vector<Hand> hands)
{
  if (holes.size() != players.size())
    THROW2(("Passed %u hands, expected %u", holes.size(), players.size()));
  
  preset_hands = hands;
}

void Dealer::reset_hands()
{
  for (unsigned i=0; i<preset_hands.size(); i++)
    preset_hands[i].set_unknown();
}

void Dealer::remove_all_players()
{
  players.empty();
}

vector<chip_t> Dealer::get_chips()
{
  return chips;
}

void Dealer::set_chips(vector<chip_t> const & c)
{
  chips = c;
}

void Dealer::set_players(vector<Player*> const & p)
{
  players = p;
}


#ifdef DEALER_MAIN

int main(int argc, char* argv[])
{
  int c;
  int np = 10;

  setbuf(stdout, 0);

  prng_init(1);
  Dealer d(np);
 
  d.add_player(new Human, 0);
  for (c=0; c<np-1; c++)
    d.add_player(new Random_player(0.5, 0.3), 0);
  
  for (c=0; ; c++) {
    d.set_dealer(prng_sample() % d.get_nseats());
    d.run();
    d.dump_hand();
    printf("deals %i ", c);
    d.dump();
  }
}

#endif
