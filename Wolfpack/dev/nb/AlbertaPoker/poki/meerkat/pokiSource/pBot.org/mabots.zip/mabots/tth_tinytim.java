
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_tinytim extends wrapper implements Player
{
    public tth_tinytim() 
    { 
	super("tth:tinytim"); 
    }
}
