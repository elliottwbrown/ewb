// -*- c++ -*-
/*
 *  This class creates bots from <botname>:<botargs> strings.
 *  It knows about all the available bots.
 */

#ifndef BOT_MANAGER_H
#define BOT_MANAGER_H

struct MAPOKERATTR Bot_manager
{
  static Player* create(const char* botname,
			const char* botargs,
			int id);
  
  //  name is <bot-name>:<bot-args>, id is chosen automatically
  static Player* Bot_manager::create(const char* name);
};

#endif
