
// -*- c++ -*-
#ifndef HOLE_H
#define HOLE_H

#define NHOLES       (51*52/2)
#define NHOLES_CANON    169

struct Hole;
struct Hand;
struct Card_mask;

MAPOKERATTR extern Hole* construct_hole_table();
MAPOKERATTR extern Hand* construct_hand_table();

// should be private, but card_mask_table is used by Card_mask
MAPOKERATTR extern Card_mask* card_mask_table;  // map hole index to Card_mask
MAPOKERATTR extern Hole* hole_table; 
MAPOKERATTR extern Hand* hand_table; // map hole index to Hand

struct Hole_info {
  int suited;
  int paired;
  int gap;
  int lorank;
  int toprank;
};

extern Hole_info hole_info_table[NHOLES];

struct Hole
{
  Hole(const char*); // 'AA' 'KTs' etc (picks suits arbitrarily), not "Ah 7d", use Hole(Hand("Ah 7d"))
  Hole(unsigned rank1, unsigned suit1, unsigned rank2, unsigned suit2);
  Hole(int index1, int index2); // 0..52
  Hole(Card c1, Card c2)   { *this = Hole(Hand(c1,c2)); }  // FIXME hideously slow
  Hole(Hand h);
  Hole(int h_)             { h = h_; }
  Hole()                   { h = 0;  }
  Hand to_Hand() const     { if (!hand_table) hand_table = construct_hand_table(); return hand_table[h]; }
  char* to_str() const     { return to_Hand().to_str(); }
  int canonical() const;   // return 0..169 [r1][r2] is suited for r1>r2
  int index() const        { return h; }
  Card card(int i) const   { return to_Hand().card(i); } // FIXME hideously slow - stuff this in Hole_info

  bool consistent(Hole h) const { return !CardMask_ANY_SET(to_Hand().cm, h.to_Hand().cm); }

#if 1
  bool suited() const      { return hole_info_table[h].suited; }
  bool paired() const      { return hole_info_table[h].paired; }
  int gap() const          { return hole_info_table[h].gap; }

  //  gap is 0 for connectors and -1 for pairs
  bool connector() const   { return !gap(); }
  bool suited_connector() const { return suited() && connector(); }
  int toprank() const      { return hole_info_table[h].toprank; }
  int lorank() const       { return hole_info_table[h].lorank; }
#endif

#if 0
  //  bootstrap routines for hole_info
  bool suited() const      { return card(0).suit() == card(1).suit(); }
  bool paired() const      { return card(0).rank() == card(1).rank(); }
  bool suited_connector() const { return suited() && abs(card(0).rank() - card(1).rank()) == 1; }
  int gap() const          { return abs(card(0).rank() - card(1).rank()) -1; }
  bool connector() const   { return abs(card(0).rank() - card(1).rank()) == 1; }
  int toprank() const      { int r1 = card(0).rank(); int r2 = card(1).rank(); return (r1 > r2 ? r1 : r2); }
  int lorank() const       { int r1 = card(0).rank(); int r2 = card(1).rank(); return (r1 < r2 ? r1 : r2); }
#endif

  bool operator==(const Hole & h2) const { return h == h2.h; }

  static Hole from_canon(unsigned u);

  /* 0 .. NHOLES-1, the 2h 3h ... 2h As ... Ks As ordering */
  int h;
};

inline Hole::Hole(unsigned r1, unsigned s1, unsigned r2, unsigned s2)
{
  assert(r1 >= 0 && r1 < 13);
  assert(r2 >= 0 && r2 < 13);
  assert(s1 >= 0 && s1 < 4);
  assert(s2 >= 0 && s2 < 4);

  if (!hole_table)
    hole_table = construct_hole_table();

  if (s1 > s2 || (s1 == s2 && (r1 > r2))) {
    unsigned u = s1;
    s1 = s2;
    s2 = u;
    u = r1;
    r1 = r2;
    r2 = u;
  }

  unsigned idx;
  
  idx = r1;
  idx <<= 2; idx |= s1;
  idx <<= 4; idx |= r2;
  idx <<= 2; idx |= s2;
  
  *this = hole_table[idx];
}

inline Hole::Hole(Hand h)
{
  assert(h.known());

  Card card1 = h.card(0);
  Card card2 = h.card(1);
  int s1 = card1.suit();
  int s2 = card2.suit();
  int r1 = card1.rank();
  int r2 = card2.rank();
  
  *this = Hole(r1, s1, r2, s2);
}

inline Hole::Hole(int i1, int i2)
{
  assert(i1 >= 0 && i1 < 52);
  assert(i2 >= 0 && i2 < 52);

  if (i1 > i2) {
    int r = i1;
    i1 = i2;
    i2 = r;
  }

  *this = Hole(i1 % 13, i1/13, i2 % 13, i2/13);
}


#endif
