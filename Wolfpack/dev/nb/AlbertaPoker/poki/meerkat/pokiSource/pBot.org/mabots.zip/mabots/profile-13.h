// -*- c++ -*-
struct Tth_profile tth_profile_13 =
{
"harrythehorse",
{ // preflop

	{ // pair

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,6,6}, {100,5,5}, {100,4,4}, {100,2,2}, { 75,2,A}, 
/*      Blinds only: Raise */ { 50,4,7}, {100,X,X}, { 75,T,8}, { 75,8,6}, { 75,6,5}, {100,4,4}, {100,2,2}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*       Called pot: Raise */ { 50,9,J}, { 50,9,J}, {100,X,X}, { 50,T,J}, { 50,9,T}, {100,8,8}, {100,6,6}, 
/*         tocall=2:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*         tocall=2: Raise */ { 50,T,J}, {100,X,X}, {100,X,X}, { 50,J,Q}, { 50,T,J}, {100,9,9}, { 75,8,9}, 
/*         tocall=3:  Call */ {100,8,8}, {100,X,X}, {100,X,X}, {100,9,9}, {100,8,8}, {100,7,7}, {100,6,6}, 
/*         tocall=3: Raise */ { 50,J,Q}, {100,X,X}, {100,X,X}, { 50,Q,K}, {100,Q,Q}, {100,J,J}, { 75,T,J}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,6,6}, {100,5,5}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*  again: tocall=1: Raise */ { 50,J,Q}, { 50,J,Q}, { 50,Q,K}, {100,Q,Q}, { 50,J,Q}, {100,T,T}, { 75,9,T}, 
/*  again: tocall=2:  Call */ {100,2,2}, {100,5,5}, {100,6,6}, {100,5,5}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*  again: tocall=2: Raise */ { 50,Q,K}, { 50,Q,K}, { 50,K,A}, {100,K,K}, { 50,Q,K}, {100,J,J}, { 75,T,J}, 
	},

	{ // suited 0-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,9,9}, {100,8,8}, {100,7,7}, {100,5,5}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,8,T}, {100,X,X}, { 75,K,J}, { 75,Q,T}, { 75,T,9}, {100,7,7}, {100,4,4}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*       Called pot: Raise */ { 75,Q,K}, { 75,Q,K}, {100,X,X}, { 50,K,X}, { 50,Q,K}, { 50,J,Q}, {100,9,9}, 
/*         tocall=2:  Call */ {100,5,5}, {100,X,X}, {100,X,X}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, 
/*         tocall=2: Raise */ { 75,K,X}, {100,X,X}, {100,X,X}, { 25,K,X}, {100,K,K}, { 50,Q,K}, { 50,J,Q}, 
/*         tocall=3:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,Q,Q}, {100,J,J}, {100,T,T}, {100,9,9}, 
/*         tocall=3: Raise */ { 50,K,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,K,X}, {100,K,K}, {100,K,K}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=1: Raise */ { 75,K,X}, { 75,K,X}, {100,X,X}, { 50,K,X}, {100,K,K}, {100,K,K}, { 50,Q,K}, 
/*  again: tocall=2:  Call */ {100,5,5}, {100,6,6}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, { 25,K,X}, {100,X,X}, {100,X,X}, { 50,K,X}, {100,K,K}, {100,K,K}, 
	},

	{ // suited 1-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,9,9}, {100,8,8}, {100,7,7}, {100,5,5}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,8,T}, {100,X,X}, { 75,Q,J}, { 75,Q,T}, { 75,T,9}, {100,7,7}, {100,4,4}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*       Called pot: Raise */ {100,Q,Q}, {100,Q,Q}, {100,X,X}, { 25,Q,X}, { 50,Q,X}, { 50,J,Q}, { 50,9,T}, 
/*         tocall=2:  Call */ {100,6,6}, {100,X,X}, {100,X,X}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, 
/*         tocall=2: Raise */ { 50,Q,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,Q,X}, { 50,Q,X}, { 50,J,Q}, 
/*         tocall=3:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,Q,Q}, {100,J,J}, {100,T,T}, {100,9,9}, 
/*         tocall=3: Raise */ { 75,X,Q}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,Q,X}, { 50,Q,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=1: Raise */ { 50,X,Q}, { 50,Q,X}, {100,X,X}, { 75,X,Q}, { 50,Q,X}, { 75,Q,X}, {100,Q,Q}, 
/*  again: tocall=2:  Call */ {100,6,6}, {100,7,7}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,Q,X}, { 75,Q,X}, 
	},

	{ // suited 2-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,9,9}, {100,8,8}, {100,7,7}, {100,5,5}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,8,T}, {100,X,X}, { 75,X,J}, { 75,J,T}, { 75,T,9}, {100,8,8}, {100,5,5}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*       Called pot: Raise */ { 75,J,X}, { 75,J,X}, {100,X,X}, { 25,J,X}, { 25,J,X}, { 50,J,X}, { 50,9,T}, 
/*         tocall=2:  Call */ {100,7,7}, {100,X,X}, {100,X,X}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, 
/*         tocall=2: Raise */ { 25,J,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,J,X}, { 50,J,X}, 
/*         tocall=3:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,J,J}, {100,J,J}, {100,T,T}, {100,9,9}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,J,X}, { 50,J,X}, 
/*  again: tocall=2:  Call */ {100,7,7}, {100,8,8}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,J,X}, 
	},

	{ // suited 3-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,9,9}, {100,8,8}, {100,7,7}, {100,5,5}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,8,T}, {100,X,X}, {100,X,X}, { 75,X,T}, { 75,T,9}, {100,8,8}, {100,5,5}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*       Called pot: Raise */ { 50,T,X}, { 50,T,X}, {100,X,X}, {100,X,X}, { 25,T,X}, { 25,T,X}, { 50,9,T}, 
/*         tocall=2:  Call */ {100,7,7}, {100,X,X}, {100,X,X}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 10,T,X}, { 25,T,X}, 
/*         tocall=3:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,T,T}, {100,T,T}, {100,T,T}, {100,9,9}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 10,T,X}, 
/*  again: tocall=2:  Call */ {100,7,7}, {100,8,8}, {100,9,9}, {100,8,8}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited 0-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,4,4}, {100,X,X}, {100,J,J}, {100,T,T}, {100,9,9}, {100,8,8}, {100,7,7}, 
/*      Blinds only: Raise */ { 50,T,Q}, {100,X,X}, {100,K,K}, { 75,K,Q}, { 75,Q,J}, {100,T,T}, {100,8,8}, 
/*       Called pot:  Call */ {100,3,3}, {100,X,X}, {100,X,X}, {100,T,T}, {100,9,9}, {100,7,7}, {100,5,5}, 
/*       Called pot: Raise */ {100,K,K}, {100,K,K}, {100,X,X}, { 50,K,X}, { 50,K,X}, { 50,Q,K}, { 50,J,Q}, 
/*         tocall=2:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,Q,Q}, {100,J,J}, {100,T,T}, {100,9,9}, 
/*         tocall=2: Raise */ { 50,K,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,K,X}, { 50,K,X}, { 50,Q,K}, 
/*         tocall=3:  Call */ {100,Q,Q}, {100,X,X}, {100,X,X}, {100,K,K}, {100,K,K}, {100,K,K}, {100,Q,Q}, 
/*         tocall=3: Raise */ { 75,X,K}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,K,X}, { 50,K,X}, 
/*  again: tocall=1:  Call */ {100,4,4}, {100,5,5}, {100,J,J}, {100,T,T}, {100,9,9}, {100,7,7}, {100,5,5}, 
/*  again: tocall=1: Raise */ { 50,X,K}, { 50,K,X}, {100,X,X}, { 75,X,K}, { 50,K,X}, { 75,K,X}, {100,K,K}, 
/*  again: tocall=2:  Call */ {100,9,9}, {100,Q,Q}, {100,Q,Q}, {100,J,J}, {100,9,9}, {100,7,7}, {100,5,5}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,K,X}, { 75,K,X}, 
	},

	{ // unsuited 1-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,4,4}, {100,X,X}, {100,J,J}, {100,T,T}, {100,9,9}, {100,8,8}, {100,7,7}, 
/*      Blinds only: Raise */ { 50,T,Q}, {100,X,X}, { 75,X,Q}, {100,Q,Q}, { 75,Q,J}, {100,T,T}, {100,8,8}, 
/*       Called pot:  Call */ {100,3,3}, {100,X,X}, {100,X,X}, {100,T,T}, {100,9,9}, {100,7,7}, {100,5,5}, 
/*       Called pot: Raise */ { 75,Q,X}, { 75,Q,X}, {100,X,X}, { 25,Q,X}, { 25,Q,X}, { 50,Q,X}, { 50,J,Q}, 
/*         tocall=2:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,Q,Q}, {100,J,J}, {100,T,T}, {100,9,9}, 
/*         tocall=2: Raise */ { 25,Q,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,Q,X}, { 50,Q,X}, 
/*         tocall=3:  Call */ {100,Q,Q}, {100,X,X}, {100,X,X}, {100,Q,Q}, {100,Q,Q}, {100,Q,Q}, {100,Q,Q}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,4,4}, {100,5,5}, {100,J,J}, {100,T,T}, {100,9,9}, {100,7,7}, {100,5,5}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,Q,X}, { 50,Q,X}, 
/*  again: tocall=2:  Call */ {100,9,9}, {100,Q,Q}, {100,Q,Q}, {100,J,J}, {100,9,9}, {100,7,7}, {100,5,5}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,Q,X}, 
	},

	{ // unsuited 2-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,5,5}, {100,X,X}, {100,J,J}, {100,T,T}, {100,9,9}, {100,8,8}, {100,7,7}, 
/*      Blinds only: Raise */ { 50,T,J}, {100,X,X}, {100,X,X}, { 75,X,J}, {100,J,J}, {100,T,T}, {100,8,8}, 
/*       Called pot:  Call */ {100,4,4}, {100,X,X}, {100,X,X}, {100,T,T}, {100,9,9}, {100,8,8}, {100,6,6}, 
/*       Called pot: Raise */ { 50,J,X}, { 25,J,X}, {100,X,X}, {100,X,X}, { 25,J,X}, { 50,J,X}, {100,J,J}, 
/*         tocall=2:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,J,J}, {100,J,J}, {100,T,T}, {100,9,9}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 10,J,X}, { 25,J,X}, 
/*         tocall=3:  Call */ {100,J,J}, {100,X,X}, {100,X,X}, {100,X,X}, {100,J,J}, {100,J,J}, {100,J,J}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,5,5}, {100,6,6}, {100,J,J}, {100,T,T}, {100,9,9}, {100,8,8}, {100,6,6}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 95,X,J}, 
/*  again: tocall=2:  Call */ {100,9,9}, {100,J,J}, {100,X,X}, {100,J,J}, {100,9,9}, {100,8,8}, {100,6,6}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited 3-gap

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,6,6}, {100,X,X}, {100,T,T}, {100,T,T}, {100,9,9}, {100,8,8}, {100,7,7}, 
/*      Blinds only: Raise */ {100,T,T}, {100,X,X}, {100,X,X}, {100,X,X}, { 75,X,T}, {100,T,T}, {100,8,8}, 
/*       Called pot:  Call */ {100,5,5}, {100,X,X}, {100,X,X}, {100,T,T}, {100,9,9}, {100,8,8}, {100,6,6}, 
/*       Called pot: Raise */ { 75,X,T}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 25,T,X}, {100,T,T}, 
/*         tocall=2:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,X,X}, {100,T,T}, {100,T,T}, {100,9,9}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {  5,T,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,T,T}, {100,T,T}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,6,6}, {100,7,7}, {100,T,T}, {100,T,T}, {100,9,9}, {100,8,8}, {100,6,6}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,9,9}, {100,X,X}, {100,X,X}, {100,T,T}, {100,9,9}, {100,8,8}, {100,6,6}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited Ax

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,7,7}, {100,2,2}, {100,2,2}, {100,2,2}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,2,4}, {100,X,X}, {100,X,X}, {100,X,X}, { 75,9,8}, {100,2,2}, {100,2,2}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,2,2}, {100,2,2}, {100,2,2}, {100,2,2}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,9,X}, {100,4,4}, 
/*         tocall=2:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,2,2}, {100,2,2}, {100,2,2}, {100,2,2}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 90,X,8}, 
/*         tocall=3:  Call */ {100,4,4}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,8,8}, {100,4,4}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,7,7}, {100,2,2}, {100,2,2}, {100,2,2}, {100,2,2}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,2,2}, {100,8,8}, {100,7,7}, {100,2,2}, {100,2,2}, {100,2,2}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited Kx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,2,8}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 75,7,5}, {100,2,2}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,8,8}, 
/*         tocall=2:  Call */ {100,4,4}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,4,4}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited Qx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,4,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,4,6}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,6,6}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,6,6}, {100,X,X}, {100,X,X}, {100,X,X}, {100,6,6}, {100,4,4}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited Jx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,3,3}, 
/*      Blinds only: Raise */ { 50,6,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,5,X}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,3,3}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,3,3}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,4,4}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited Tx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,5,5}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,5,5}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,5,5}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited 9x

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited 8x

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // suited 7x

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited Ax

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,7,7}, {100,4,4}, {100,2,2}, 
/*      Blinds only: Raise */ { 50,2,8}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 75,7,4}, {100,2,2}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,7,7}, {100,4,4}, {100,2,2}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 10,9,X}, 
/*         tocall=2:  Call */ {100,7,7}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,2,2}, {100,2,2}, {100,X,X}, {100,X,X}, {100,7,7}, {100,4,4}, {100,2,2}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,7,7}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,7,7}, {100,2,2}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited Kx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,4,4}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,4,4}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,5,7}, 
/*       Called pot:  Call */ {100,2,2}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,5,5}, {100,5,5}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,4,4}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,5,5}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited Qx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,6,6}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,5,5}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, { 50,6,X}, 
/*       Called pot:  Call */ {100,4,4}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,6,6}, {100,6,6}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,5,5}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,6,6}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited Jx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,6,6}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,6,6}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited Tx

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited 9x

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited 8x

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},

	{ // unsuited 7x

		 //               SmB        BgB        UnG        Ear        Mid        Lat        But
/*      Blinds only:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*      Blinds only: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*       Called pot: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*         tocall=3: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=1: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2:  Call */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
/*  again: tocall=2: Raise */ {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, {100,X,X}, 
	},
}, // preflop

// nopair

{
/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 1. An inside str draw w/1 card to top end-str (Q9 865)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 2. An inside str draw w/2 card to mediocre str (65 Q98)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 3. An inside str draw w/2 cards to a nut str (98 A65 or 86 A95)
	{{{BV_P_, 3},{BV_P_, 3},{BV_b_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 4. A 2-way str draw w/1 card to a mediocre str (K6 987)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 5. A 2-way str draw w/1 card to a top-end str (K9 876)
	{{{BV_P_, 3},{BV_P_, 3},{BV_b_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 6. A 2-way str draw w/2 cards to a mediocre str (76 K98 or 42 865)
	{{{BV_P_, 3},{BV_P_, 3},{BV_b_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 7. A 2-way str draw w/2 cards to a nut str (98 K76 or QJ AT8)
	{{{BV_b_, 3},{BV_b_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 8. A 2-way str draw w/2 cards vs a 2-card flush (86 K97 w97s)
	{{{BV_b_, 3},{BV_P_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 9. A str draw not 2-way w/2 cards vs a 2-card flush (K9 876 w76s)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 10. A 2-way str draw w/2 cards vs a 3/4-card flush (98 K76 wK76s)
	{{{BV_P_, 2},{BV_P_, 2},{BV_P_, 2},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 11. A str draw, not 2-way w/2 card vs a 3/4-card flush (K9 876 w876s)
	{{{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 12. A flush draw w/1 card, w/A (A9 J76 wAJ76s)
	{{{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 13. A flush draw w/1 card, wo/A (K9 J76 wKJ76s)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 14. A flush draw w/2 cards, w/A (A9 J76 wA9J7s)
	{{{BV_B_, 3},{BV_B_, 3},{BV_r_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_b_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 15. A flush draw w/2 cards, wo/A (K9 J76 wK976s)
	{{{BV_B_, 3},{BV_b_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 16. A flush draw w/A vs a 3/4 str (A9 654)
	{{{BV_B_, 3},{BV_b_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 17. A flush draw wo/A vs a 3/4 str (75 KJT)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 18. An inside str draw w/1 card to a mediocre str (Q5 986)
	{{{BV_P_, 2},{BV_P_, 2},{BV_P_, 2},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 19. A str flush draw w/1 card (K6 987 w6987s)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 20. A str flush draw w/2 cards (76 983 w7698s)
	{{{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_b_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 21. 2 major overcards (AK, AQ, AJ or KQ)
	{{{BV_B_, 2},{BV_BN, 2},{BV_BN, 0},}, {{BV_PN, 1},{BV_bn, 1},{BV_bn, 1},}, {{BV_HU, 0},{BV_HU, 0},{BV_P_, 0},}, },

// 22. 2 minor overcards w/rags on the board (Q9 863)
	{{{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },

// 23. Ace overcard w/rags on the board (A8 963)
	{{{BV_P_, 1},{BV_P_, 0},{BV_x1, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },

// 24  2 major overcards (AK, AQ, AJ or KQ) vs 3-str or 3-flush (AJ 986 w/986s)
	{{{BV_b_, 2},{BV_BN, 1},{BV_BN, 0},}, {{BV_P_, 1},{BV_bn, 1},{BV_P_, 1},}, {{BV_P_, 0},{BV_HU, 0},{BV_HU, 0},}, },

// 25. 2 minor overcards or Ace overcard vs 3-str (K9 864)
	{{{BV_P_, 0},{BV_P_, 0},{BV_x1, 0},}, {{BV_x1, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_x1, 0},{BV_P_, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 26. Nothing (J8 T53 or J8 AK7)
	{{{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },

// 27. A pair, not top pair w/kicker lower than board (J8 QJ4)
	{{{BV_P_, 1},{BV_P_, 1},{BV_BN, 1},}, {{BV_P_, 1},{BV_P_, 0},{BV_b_, 1},}, {{BV_HU, 0},{BV_HU, 0},{BV_HU, 0},}, },

// 28. A pair, not top pair w/kicker higher than board (KJ QJ4)
	{{{BV_B_, 2},{BV_bn, 2},{BV_BN, 0},}, {{BV_bn, 0},{BV_bn, 1},{BV_bn, 1},}, {{BV_P_, 1},{BV_HU, 0},{BV_HU, 1},}, },

// 29. A pair, not top pair vs a 3-str or flush (AJ QJ9)
	{{{BV_CX, 1},{BV_P_, 1},{BV_x1, 1},}, {{BV_bn, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_P_, 0},{BV_HU, 0},{BV_HU, 1},}, },

// 30. A pair, not top pair vs a 4-str or flush (84 9876)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_HU, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 31. Top pair, Js or lower w/J or lower kicker (J8 J94)
	{{{BV_BN, 3},{BV_RN, 3},{BV_BN, 3},}, {{BV_B_, 2},{BV_bn, 2},{BV_bn, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_bn, 0},}, },

// 32. Top pair, Js or lower w/Q or higher kicker (KJ J94)
	{{{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_b_, 3},{BV_B_, 3},{BV_r_, 3},}, {{BV_bn, 2},{BV_PN, 2},{BV_BN, 2},}, },

// 33. Top pair, Qs or Ks w/J or lower kicker (Q8 Q94)
	{{{BV_BN, 3},{BV_BN, 3},{BV_RN, 3},}, {{BV_b_, 2},{BV_bn, 2},{BV_bn, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_bn, 0},}, },

// 34. Top pair, Qs or Ks w/Q or higher kicker (KQ Q93)
	{{{BV_CC, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_b_, 3},{BV_B_, 3},{BV_b_, 3},}, {{BV_bn, 2},{BV_PN, 2},{BV_bn, 2},}, },

// 35. Top pair, As w/9 or lower kicker (A8 A93)
	{{{BV_B_, 2},{BV_BN, 0},{BV_BN, 3},}, {{BV_b_, 2},{BV_b_, 2},{BV_BN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 36. Top pair, As w/T or J kicker (AJ A94)
	{{{BV_CC, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_bn, 3},{BV_B_, 3},{BV_B_, 3},}, {{BV_b_, 2},{BV_bn, 2},{BV_BN, 0},}, },

// 37. Top pair, As w/Q or K kicker (AQ A94)
	{{{BV_B_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_CC, 3},{BV_R_, 3},{BV_R_, 3},}, {{BV_bn, 3},{BV_bn, 3},{BV_BN, 3},}, },

// 38. Top pair, w/poor kicker vs 3-card str or flush (K8 KQJ)
	{{{BV_B_, 2},{BV_BN, 0},{BV_BN, 0},}, {{BV_b_, 2},{BV_bn, 0},{BV_bn, 1},}, {{BV_P_, 1},{BV_P_, 1},{BV_bn, 0},}, },

// 39. Top pair, w/better kicker vs 3-card str or flush (K9 986)
	{{{BV_S_, 3},{BV_CC, 3},{BV_S_, 3},}, {{BV_bn, 0},{BV_bn, 0},{BV_bn, 3},}, {{BV_P_, 1},{BV_P_, 1},{BV_bn, 0},}, },

// 40. Top pair vs 4-card str or flush (AJ JT97)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_HU, 0},{BV_HU, 1},{BV_P_, 1},}, {{BV_HU, 1},{BV_HU, 0},{BV_HU, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 41. Pocket overpair, As or Ks (KK Q85)
	{{{BV_S_, 3},{BV_A_, 3},{BV_A_, 3},}, {{BV_CC, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, },

// 42. Pocket overpair, Ts, Js or Qs (JJ 974)
	{{{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_b_, 3},{BV_r_, 3},{BV_r_, 3},}, {{BV_b_, 3},{BV_bn, 0},{BV_BN, 3},}, },

// 43. Pocket overpair lower than Ts (99 873)
	{{{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_b_, 3},{BV_b_, 3},{BV_B_, 3},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, },

// 44. Pocket overpair vs 3-str or flush (KK J98)
	{{{BV_S_, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_b_, 2},{BV_bn, 2},{BV_R_, 3},}, {{BV_bn, 2},{BV_bn, 2},{BV_bn, 2},}, },

// 45. Pocket overpair vs 4-str or flush (QQ 8764)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_HU, 1},{BV_b_, 1},}, {{BV_HU, 1},{BV_HU, 0},{BV_P_, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 46. Pocket underpair lower than 1 board overcard (99 K75)
	{{{BV_b_, 2},{BV_BN, 0},{BV_BN, 0},}, {{BV_bn, 2},{BV_PN, 1},{BV_bn, 0},}, {{BV_P_, 1},{BV_HU, 1},{BV_P_, 1},}, },

// 47. Pocket underpair lower than 2+ board overcards (99 KQ5)
	{{{BV_P_, 1},{BV_x1, 1},{BV_bn, 0},}, {{BV_HU, 1},{BV_x1, 0},{BV_P_, 1},}, {{BV_HU, 1},{BV_HU, 0},{BV_HU, 1},}, },

// 48. Pocket underpair vs 3-card str or flush (88 KQJ)
	{{{BV_x1, 2},{BV_P_, 1},{BV_b_, 1},}, {{BV_PN, 2},{BV_P_, 1},{BV_bn, 0},}, {{BV_HU, 1},{BV_HU, 0},{BV_P_, 1},}, },

// 49. Pocket underpair vs 4-str or flush (88 KQJ9)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_HU, 0},{BV_P_, 0},}, },

// 50. 2 pair not including top pair (J6 QJ6)
	{{{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_CC, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_b_, 3},{BV_b_, 3},{BV_B_, 3},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 51. 2 pair, top pair and other pair (J3 J63)
	{{{BV_CC, 3},{BV_S_, 3},{BV_A_, 3},}, {{BV_S_, 3},{BV_CC, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_R_, 3},}, },

// 52. 2 pair vs 3-card str or flush (J9 JT9)
	{{{BV_CC, 0},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, {{BV_bn, 0},{BV_bn, 2},{BV_bn, 2},}, },

// 53. 2 pair vs 4-card str of flush (J9 QJT9)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_PN, 0},{BV_PN, 0},{BV_bn, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, },

// 54. Set (77 QJ7)
	{{{BV_A_, 3},{BV_CR, 0},{BV_A_, 3},}, {{BV_CA, 0},{BV_A_, 3},{BV_A_, 3},}, {{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, },

// 55. Set vs 3-card str or flush (77 876)
	{{{BV_S_, 3},{BV_CC, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, {{BV_b_, 2},{BV_b_, 3},{BV_B_, 2},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 56. Set vs 4-card str or flush (77 9876)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 3},{BV_B_, 3},{BV_B_, 3},}, {{BV_P_, 2},{BV_P_, 1},{BV_PN, 0},}, },

// 57. Non-nut straight or flush (84 756)
	{{{BV_S_, 3},{BV_S_, 3},{BV_A_, 3},}, {{BV_CC, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, },

// 58. Nut straight, nut flush or any straight flush (98 765)
	{{{BV_CA, 3},{BV_A_, 3},{BV_A_, 3},}, {{BV_A_, 3},{BV_CR, 3},{BV_A_, 3},}, {{BV_CR, 3},{BV_A_, 3},{BV_A_, 3},}, },

// 59. str vs 3-card flush (76 T98 w/T98s)
	{{{BV_CC, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 2},{BV_BN, 0},{BV_RN, 0},}, {{BV_b_, 2},{BV_bn, 2},{BV_BN, 2},}, },

// 60. str vs 4-card flush (K8 9765 w/9765s)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_BN, 1},}, {{BV_PN, 1},{BV_PN, 1},{BV_bn, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
},

// onepair

{
/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 1. An inside straight draw w/2 cards (98 655 or 65 988)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 2. A 2-way straight draw w/2 cards (98 776)
	{{{BV_P_, 3},{BV_b_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 3. A straight draw w/2 cards vs a flopped 2-card flush (98 776 or T9 776)
	{{{BV_b_, 3},{BV_P_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 4. A straight draw w/2 cards vs a 3-card flush (98 7763 or T9 7763 w/763 suited)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_x1, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 5. A flush draw with an A (A9 J776 w/AJ76 suited)
	{{{BV_b_, 3},{BV_b_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 6. A flush draw without an A (Q9 J776 w/QJ76 suited)
	{{{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 7. A straight flush draw w/1 card (K6 9877)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 8. A straight flush draw w/2 cards (76 988)
	{{{BV_b_, 3},{BV_P_, 3},{BV_B_, 3},}, {{BV_P_, 3},{BV_P_, 3},{BV_P_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 9. 2 major overcards (AK AQ AJ or KQ) w/rags on the board (AJ 9962)
	{{{BV_bn, 2},{BV_bn, 0},{BV_BN, 0},}, {{BV_P_, 1},{BV_b_, 1},{BV_b_, 1},}, {{BV_HU, 0},{BV_P_, 0},{BV_P_, 0},}, },

// 10. 2 minor overcards w/rags on the board (Q9 8862)
	{{{BV_P_, 1},{BV_x1, 1},{BV_P_, 1},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 11. Ace overcard w/rags on the board (A4 8873)
	{{{BV_P_, 0},{BV_P_, 0},{BV_x1, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },

// 12. 2 major overcards (AK AQ AJ of KQ) vs 3-str or 3-flush (AJ 9986)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_b_, 1},}, {{BV_P_, 0},{BV_HU, 0},{BV_P_, 0},}, },

// 13. 2 minor overcards or Ace overcard vs 3-str (K9 8664)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_x1, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },

// 14. 2 pair, pocket J's or better, no higher odd cards on board (JJ QQ9)
	{{{BV_B_, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_bn, 0},{BV_b_, 3},{BV_B_, 3},}, {{BV_bn, 2},{BV_bn, 0},{BV_BN, 0},}, },

// 15. 2 pair, pocket T's or lower no higher odd cards on board (TT QQ9)
	{{{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, {{BV_bn, 0},{BV_bn, 0},{BV_bn, 0},}, {{BV_P_, 1},{BV_bn, 0},{BV_bn, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 16. 2 pair, any pocket pair, 1 higher odd card on board (JJ KKQ or JJ KKQ2)
	{{{BV_b_, 1},{BV_bn, 1},{BV_bn, 0},}, {{BV_bn, 1},{BV_PN, 1},{BV_bn, 1},}, {{BV_P_, 1},{BV_HU, 1},{BV_P_, 1},}, },

// 17. 2 pair, any pocket pair, 2 + higher odd cards on boad (66 QQJ7)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_HU, 0},{BV_HU, 0},{BV_bn, 0},}, {{BV_HU, 1},{BV_HU, 0},{BV_HU, 1},}, },

// 18. 2 pair, match top odd card on board, plus A or K kicker (A9 QQ9 or A9 QQ92)
	{{{BV_BN, 3},{BV_BN, 3},{BV_BN, 3},}, {{BV_b_, 2},{BV_bn, 0},{BV_bn, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_B_, 2},}, },

// 19. 2 pair, match top odd card on board, no  A or K kicker (97 QQ9 or 97 QQ94)
	{{{BV_B_, 2},{BV_BN, 0},{BV_BN, 0},}, {{BV_PN, 2},{BV_PN, 0},{BV_bn, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, },

// 20. 2 pair, match other than top odd card on board, any kicker (Q4 9974)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_HU, 0},{BV_HU, 0},{BV_P_, 1},}, {{BV_HU, 0},{BV_HU, 0},{BV_HU, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 21. Better 2 pair vs 3,4-card straight or flush (TT QQ92 or A9 QQ92 or 97 QQ94)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_b_, 2},{BV_P_, 2},{BV_B_, 2},}, {{BV_P_, 1},{BV_P_, 1},{BV_bn, 0},}, },

// 22. Lesser 2 pair vs 3,4-card straight or flush (JJ KKQ2 or 66 QQJ7 or Q4 9974)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_HU, 0},{BV_HU, 0},{BV_HU, 0},}, },

// 23. Trips w/weak kicker (7? 77Q)
	{{{BV_CA, 0},{BV_CR, 3},{BV_A_, 3},}, {{BV_S_, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_R_, 3},}, },

// 24. Trips w/strong kicker (7? 77Q)
	{{{BV_S_, 3},{BV_CR, 0},{BV_A_, 3},}, {{BV_CA, 0},{BV_S_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, },

// 25. Trips vs 3-card straight or flush (K7 9877)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, {{BV_b_, 3},{BV_b_, 3},{BV_B_, 3},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 26. Trips vs 4-card straight or flush (K7 98776)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, },

// 27. Non-nut straight or flush (84 7765)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_CC, 0},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_R_, 3},}, },

// 28. Nut straight or flush (98 7765)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, },

// 29. A straight vs a 3-card flush (98 T776 w/9765 suited)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, {{BV_bn, 0},{BV_bn, 0},{BV_BN, 0},}, },

// 30. A straight vs a 4-card flush (K8 99765 w/9765 suited)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 31. Full house, other than top full house (KQ KQQ)
	{{{BV_A_, 3},{BV_DR, 0},{BV_A_, 3},}, {{BV_CC, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_CC, 3},{BV_S_, 3},{BV_S_, 3},}, },

// 32. Top full house or better (KK KQQ or K9 KK9 or 44 443)
	{{{BV_P_, 3},{BV_b_, 3},{BV_b_, 3},}, {{BV_CA, 0},{BV_DR, 0},{BV_A_, 3},}, {{BV_A_, 3},{BV_DR, 3},{BV_A_, 3},}, },

// 33. A straight draw w/1 card (K8 6554 or K9 8776)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 34. A straight draw w/1 card vs a 3-card flush (K8 6554 or K9 8776)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 35. Nothing in the pocket (J8 993)
	{{{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
},

// twopair

{
/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 1. A 2-way straight draw or a non-nut flush draw (98 7676)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 2. A flush draw with an A (A9 7676)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 2},{BV_P_, 2},{BV_b_, 2},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 3. A straight flush draw (76 9898)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 2},{BV_P_, 2},{BV_b_, 3},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 4. Ace w/kicker higher than lower pair (A8 7755 or AJ 9933)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_B_, 2},}, {{BV_HU, 1},{BV_P_, 1},{BV_B_, 2},}, },

// 5. Ace w/kicker lower than lower pair (A6 QQ77)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_b_, 2},}, {{BV_CX, 1},{BV_HU, 0},{BV_BN, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 6. King w/kicker higher than lower pair (KJ AA77 or KJ 9966)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 0},{BV_HU, 0},{BV_x1, 0},}, {{BV_P_, 0},{BV_x1, 0},{BV_P_, 0},}, },

// 7. Pocket overpair (JJ 9966) or match board overcard (KQ Q9966)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_bn, 0},{BV_bn, 0},{BV_BN, 3},}, {{BV_P_, 1},{BV_P_, 1},{BV_bn, 0},}, },

// 8. Pocket middle pair (88 9966) or match board middle card (QJ KK66Q)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_B_, 2},}, {{BV_P_, 1},{BV_P_, 1},{BV_B_, 1},}, },

// 9. Pocket underpair (55 9966)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 0},{BV_x1, 0},{BV_X1, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_X1, 0},}, },

// 10. A straight or flush (QJ AKTAK)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_HU, 1},{BV_HU, 1},{BV_P_, 1},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 11. Full house, other than top full (QJ QQKK)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_BN, 0},{BV_BN, 0},{BV_RN, 0},}, {{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, },

// 12. Top full house (QJ QQ99)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_A_, 3},{BV_DR, 3},{BV_A_, 3},}, {{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, },

// 13. Over full house (KK QQ99K)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_CR, 0},{BV_DR, 3},{BV_A_, 3},}, },

// 14. Four of a kind of better (44 4455)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_CA, 0},{BV_DR, 0},{BV_A_, 3},}, {{BV_CR, 3},{BV_DR, 0},{BV_A_, 3},}, },

// 15. Nothing (J8 9966 or K3 9966)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
},

// trips

{
/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 1. A 2-way straight draw or a non-nut flush draw (98 7677)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 2. A flush draw with an A (A9 7677)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 3. A straight flush draw (76 9899)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, },

// 4. Big cards: AK, AQ, AJ, AT or KQ both higher than odd card(s) (AQ JKKK3)
	{{{BV_BN, 3},{BV_BN, 3},{BV_BN, 3},}, {{BV_b_, 2},{BV_P_, 1},{BV_bn, 0},}, {{BV_P_, 0},{BV_HU, 0},{BV_HU, 0},}, },

// 5. Ace overcard (A9 JJJ2 or A2 KKK9)
	{{{BV_P_, 1},{BV_P_, 1},{BV_PN, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 1},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 6. 2 cards, 9 high or better, both higher than odd card(s) (QJ KKK8)
	{{{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_P_, 1},{BV_P_, 1},{BV_P_, 1},}, {{BV_P_, 0},{BV_P_, 0},{BV_X1, 0},}, },

// 7. A straight or flush (QJ AKTAA)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_HU, 0},{BV_HU, 0},{BV_HU, 0},}, },

// 8. Full house w/pocket Q's or better, no higher odd card(s) on board
	{{{BV_CR, 3},{BV_A_, 3},{BV_A_, 3},}, {{BV_A_, 3},{BV_A_, 3},{BV_A_, 3},}, {{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, },

// 9. Full house w/pocket 9's thru J's, no higher odd card(s) on board (99 JJJ8)
	{{{BV_S_, 3},{BV_CC, 3},{BV_S_, 3},}, {{BV_S_, 3},{BV_S_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, },

// 10. Full house w/pocket 2's thru 8's, no higher odd cards on board (66 7775)
	{{{BV_S_, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, {{BV_B_, 3},{BV_B_, 3},{BV_B_, 3},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
// 11. Full house w/any pocket but higher odd card(s) on board (QQ 777K)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_BN, 2},{BV_BN, 0},{BV_BN, 0},}, {{BV_b_, 2},{BV_b_, 2},{BV_bn, 2},}, },

// 12. Full house w/match of high odd card on the board (KQ 777Q or KQ 777Q6)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_S_, 3},{BV_R_, 3},{BV_S_, 3},}, {{BV_B_, 3},{BV_R_, 3},{BV_R_, 3},}, },

// 13. Full house w/match of low odd card on the board (K6 7776Q)
	{{{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_UN, 0},{BV_UN, 0},{BV_UN, 0},}, {{BV_PN, 2},{BV_PN, 2},{BV_BN, 2},}, },

// 14. Over full house, four of a kind or better (JJ J999 A9 J999)
	{{{BV_P_, 3},{BV_CC, 3},{BV_b_, 3},}, {{BV_CR, 0},{BV_DR, 0},{BV_S_, 3},}, {{BV_A_, 3},{BV_DR, 3},{BV_A_, 3},}, },

// 15. Nothing (J8 999)
	{{{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, {{BV_P_, 0},{BV_P_, 0},{BV_P_, 0},}, },


/*
             flop       flop       flop           turn       turn       turn          river      river      river    
              1st        Mid       Last            1st        Mid       Last            1st        Mid       Last    
*/
},

// general
0,
0,
0,
0,
0,
0,
0,
{T, 8, U, },
{U, 8, 2, },
{2, 2, U, },
{2, 2, 2, },
{U, 6, 2, },
{8, T, Q, },
};
