
#include <string.h>

char *rindex(const char *s_, int c)
{
  char* s = (char*) s_;
  char* t;

  if (!*s)
    return NULL;
  
  //  NB: strelen(s) >= 1
  for (t = s + strlen(s)-1; t >= s; t--)
    if (*t == c)
      return t;
  
  return NULL;
}

char *index(const char *s_, int c)
{
  char* s = (char*) s_;
  char* t;

  for (t = s; *t; t++)
    if (*t == c)
      return t;

  return NULL;
}
