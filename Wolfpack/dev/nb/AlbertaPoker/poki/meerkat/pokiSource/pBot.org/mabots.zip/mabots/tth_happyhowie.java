
import java.lang.*;
import poker.*;
import poker.util.*;

public class tth_happyhowie extends wrapper implements Player
{
    public tth_happyhowie() 
    { 
	super("tth:happyhowie"); 
    }
}
