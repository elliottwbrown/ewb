/*
 *  Wrap up a C++ Player interface in Meerkat's API.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */

import java.lang.*;
import poker.*;
import poker.util.*;

public class wrapper
{
    int ref;
    GameInfo gi;
    Card c1;
    Card c2;
    Preferences prefs;

    /*
     *  0 = slient
     *  1 = show TTH bot logic
     *  2 = show java side debug
     *  3 = show C++ side debug
     */
    int verbose;
    String name;
    boolean ignore_next_showdown_event;
    int nblinds;
    int nplayers;
    int ID;
    int lblinds[];
    int[] schips;
    boolean use_allin_rules;

    private void debug(String s)
    {
	if (verbose >= 2)
	    System.out.println(s);
    }
  
    public wrapper(String name)
    {
	this.name = name;
	ref = malib.new_bot(name);
	ignore_next_showdown_event = false;
	verbose = 0;
    }

    public void finalize()
    {
	malib.delete_bot(ref);
    }
  
    public void init(Preferences prefs)
    {
        this.prefs = prefs;
	verbose = prefs.getIntPreference("VERBOSE");

	/*
	 *  The C++ side shares the verbose variable between all the
	 *  bot.  I just put in the verbose setting so you can silence
	 *  the bots.  
	 */
	if (verbose > 0)
	  malib.set_verbose(ref, verbose);
	debug(name+" init");
    }

    public Preferences getPreferences() 
    {
       return prefs;
    }

    /*
     *  We get sent our hole cards before blinds are posted.
     */
    public synchronized void newGame(GameInfo gi, Card c1, Card c2, int ID)
    {
	this.c1 = c1;
	this.c2 = c2;
	this.gi = gi;
	this.ID = ID;
	debug("newGame gameID "+gi.getID()+" "+c1.toString()+" ("+c1.getIndex()+") "
			   +c2.toString()+" ("+c2.getIndex()+")");

	nblinds = 0; // when we hit 2, we call do_new_game()
	nplayers = gi.getNumPlayers();
	lblinds = new int[nplayers];
	schips = new int[nplayers]; 
	
	for (int i=0; i<nplayers; i++)
	  schips[i] = (int)gi.getPlayerInfo(i).getBankRoll();

        /*
         *  gi.useAllInRules() returns false even when its true,
	 *  so assume always use allin rules.
	 */
        use_allin_rules = true; // gi.useAllInRules());
    }

    //  This is called after blinds are posted and and we've seen our hole cards.
    public void do_new_game()
    {
	int sbl = gi.getSmallBlindSize();
	int bbl = gi.getSmallBet();
	int sbet = gi.getSmallBet();
	int bbet = gi.getBigBet();
	boolean hu = gi.useReverseBlinds();

	if (hu) {
	    debug(name+" using reverse blinds");
	    if (gi.getNumPlayers() != 2) {
		debug(name+" !!!!! using reverse blinds but nplayers != 2");
	  }
	}

	String[] players = new String[nplayers];

	/*
	 *  PPA lets people post partial blinds (i.e. go allin while
	 *  posting a blind).  If BB is partial, there are a couple of
	 *  points to note:
	 *
	 *  1) If everyone except the SB folds, SB
	 *  can call for whatever the BB actually posted.
	 *
	 *  2) if UTG wants to call in a 3+ handed game, he needs to
	 *  put in the full BB, even though BBer only posted a partial blind.
	 *
	 *  (The GUI also uses a call button with the incorrect amount
	 *  if we happen to be SB.)
	 *
	 *  I can't really handle (2), so I'll pretend the blinds are
	 *  always posted in full since my holdem class assumes that
	 *  'call' means 'match the most chips put in by anyone else
	 *  so far', but I'll note correctly if blinders are now allin.
	 *
	 *  This would appear to break case 1, but there we have
	 *  only 2 players and at least one is all in, so there is no
	 *  possibility of confusion on later rounds since the board
	 *  will just be dealt without further action.  
	 */
	boolean[] allin = new boolean[nplayers];
	int[] dblinds = new int[nplayers]; // assume zero
	int[] fake_lblinds = new int[nplayers];

	int button = gi.getButton();

	//  Assume 2 live blinds in the usual locations
	if (!gi.useReverseBlinds()) {
	  fake_lblinds[(1+button) % nplayers] = sbl;
	  fake_lblinds[(2+button) % nplayers] = bbl;
	} else {
	  fake_lblinds[(1+button) % nplayers] = bbl;
	  fake_lblinds[(2+button) % nplayers] = sbl;
	}

	for (int i=0; i<nplayers; i++) {
	  players[i] = gi.getPlayerName(i);

	  /*
	   *  NB: If BB has 9$ and needs 10$ to post BB, and allin
	   *  rules are in effect, 9$ hits the table, but
	   *  gi.getPlayerInfo(i).getBankRoll() returns -1.
	   *
	   *  gi.getPlayerInfo(i).allIn() always returns false (?)
	   */
	  allin[i] = use_allin_rules && (schips[i] <= lblinds[i]);
	  
	  /*
	   *  Adjust schips since we'll assume he posted the fake blinds
	   *  and need him to be assumed all-in when his chips hit 0.
	   */
	  schips[i] += fake_lblinds[i] - lblinds[i];
	  
	  debug("lblinds["+i+"]="+lblinds[i]
			     +" schips["+i+"] = "+schips[i]);
	  
	  if (allin[i])
	    debug(players[i]+" is all in on blinds");
	}

	malib.do_new_game(ref, sbl, bbl, sbet, bbet, hu, 
			  players, schips, allin, button, fake_lblinds, dblinds, 
			  ID, c1.getIndex(), c2.getIndex());
    }

    public synchronized int action()
    {
      	debug(name+" action");
	int i = malib.get_action(ref);
	if (i == 0)
	    return Holdem.FOLD;
	else if (i == 1)
	    return Holdem.CALL;
	return Holdem.RAISE;
    }

    public void actionEvent(int pos, int u_action, int amount)
    {
      	debug(name+" actionEvent "+pos+" "+u_action+" "+amount);

	int action = -1;

	/*
	 *  Meerkat sends blinds events after we see our hole cards.
	 *  We need to note the blinds so we can identify players who
	 *  are put allin on the blinds as gi.getPlayerInfo(.).allIn()
	 *  appears to be broken.  
	 */
	if (u_action == Holdem.U_FOLD)
	    action = 0;
	else if (u_action == Holdem.U_CHECK || u_action == Holdem.U_CALL)
	    action = 1;
	else if (u_action == Holdem.U_BET || u_action == Holdem.U_RAISE)
	    action = 2;
	else if (u_action == Holdem.U_ALLIN)
	    action = 3;
	else if (u_action == Holdem.U_SBLIND || u_action == Holdem.U_BBLIND) {
  	    lblinds[pos] = amount;
	    nblinds++;
	    if (nblinds == 2)
		do_new_game();
	}

	if (action != -1)
	    malib.do_action_event(ref, pos, action, amount, use_allin_rules);
    }
    
    public void showdownEvent(int pos, Card c1, Card c2)
    {
      	debug(name+" showdownEvent "+pos+" "+c1.toString()+" ("+c1.getIndex()+") "+c2.toString()
      			   +" ("+c2.getIndex()+")");

	if (!ignore_next_showdown_event)
	  malib.do_showdown_event(ref, pos, c1.getIndex(), c2.getIndex());
	else
	  ignore_next_showdown_event = false;
    }
    
    public void stageEvent(int stage)
    {
      	debug(name+" stageEvent "+stage);

	int[] cards = gi.getBoard().getCardArray();

	for (int i=1; i<=gi.getBoard().size(); i++)
	  debug("Card "+i+" "+gi.getBoard().getCard(i)+" ("+gi.getBoard().getCard(i).getIndex()+")");

	if (stage == Holdem.FLOP) {
	    malib.set_flop(ref, cards[1], cards[2], cards[3]);

	} else if (stage == Holdem.TURN) {
	    malib.set_turn_river(ref, false, cards[4]);

	} else if (stage == Holdem.RIVER) {
	    malib.set_turn_river(ref, true, cards[5]);
	}
    }
    
    public void winEvent(int pos, int amount, String hand)
    {
      	debug(name+" winEvent "+pos+" "+amount+" "+hand);
    }
    
    public void gameStartEvent(GameInfo gi)
    {
      	debug(name+" gameStartEvent");
	ignore_next_showdown_event = true;
    }

    public void gameOverEvent()
    {
      	debug(name+" gameOverEvent");
	malib.do_game_over_event(ref);
    }

};
