// -*- c++ -*-
/*
 *  Header file for the mapoker library.
 *
 *  Copyright (C) 2004 Marv (marv742@netscape.net)
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 *  02111-1307, USA.  
 */
#ifndef MAPOKER_H
#define MAPOKER_H

#ifdef _MSC_VER
#include "msvc.h"
#endif

#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <errno.h>
#include <stdio.h>
#include <math.h>
#ifndef NOHASHMAP
#include <hash_map>
#endif
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <list>
#include <map>
#include <set>
#include <assert.h>
#include <ctype.h>

#ifdef unix
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#define MKDIR(path,mode) mkdir((path),(mode))
#define MAPOKERATTR
#endif

#ifdef __MINGW32__
#include "mingw.h"
#endif

//  pokersource library
#include "poker.h"

#ifndef uint64
#define uint64 unsigned long long
#endif

#include "mapoker_misc.h"
#include "card.h"
#include "hand.h"
#include "holdem.h"
#include "prng.h"
#include "hole.h"
#include "types.h"
#include "misc.h"
#include "player.h"
#include "card_mask.h"

#ifndef BUILD_MAPOKER
#include "extra_bots.h"
#endif

#include "bot_manager.h"
#include "utils.h"
#include "tth_misc.h"
#include "seedable.h"

#include "tth_misc.h"
#include "tth_types.h"
#include "tth_profiles.h"
#include "tth.h"
#include "strategy.h"

#include "reporter.h"

#endif
